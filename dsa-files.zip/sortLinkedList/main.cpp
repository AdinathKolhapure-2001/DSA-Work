#include <iostream>

using namespace std;


struct Node {
    int data;
    Node* next;
    Node() {
        data = 0;
        next = NULL;
    }
    Node(int data) {
        this -> data = data;
        this -> next = NULL;
    }
};

class linkedList {
    public:
    ~linkedList();
    Node* addFirst(Node*, int);
    Node* merge(Node*, Node*);
    Node* mergeSort(Node*);
    Node* insertionSort(Node*);
    void showlist(Node*);
};

linkedList :: ~linkedList() {
    
}

Node* linkedList :: addFirst(Node* head, int data) {
    Node* newNode = new Node(data);
    if(head == NULL) head = newNode;
    else {
        newNode -> next = head;
        head = newNode;
    }
    return head;
}

void linkedList :: showlist(Node* head) {
    if(head == NULL) {
        cout << "\nLinked lisrt is empty" << endl;
        return;
    }
    Node* temp = head;
    while(temp != NULL) {
        cout << temp -> data << " --> ";
        temp = temp -> next;
    }
    cout << "NULL" << endl;
}


Node* linkedList :: merge(Node* head1, Node* head2) {   // 1, 4, 5, 7, 8 --> N
    Node* dummy = new Node();                           // 2, 9, 10, 14 --> N
    Node* temp = dummy;
    while(head1 && head2) {
        if(head1 -> data <= head2 -> data) {
            temp -> next = head1;
            head1 = head1 -> next;
        }
        else {
            temp -> next = head2;
            head2 = head2 -> next;
        }
        temp = temp -> next;
    }
    if(head1) temp -> next = head1;
    else if(head2) temp -> next = head2;
    return dummy -> next;
}
                                                            //       p        s           f
Node* linkedList :: mergeSort(Node* head) {                 // 3 --> 1 --> N  
    if(head == NULL || head -> next == NULL) return head;   // h 
    Node *slow = head, *fast = head, *prev = NULL;          // 3 --> N   1 --> N
    while(fast && fast -> next) {                           // 3 --> N
        prev = slow;                                        // 4 --> N   2 --> N
        slow = slow -> next;                                // 4 --> N
        fast = fast -> next -> next;
    }
    prev -> next = NULL;
    head = mergeSort(head);
    slow = mergeSort(slow);
    return merge(head, slow);

}
// h  
// 1 --> 2 --> 3 --> 4 --> N     // 4 2 
// p           s     c            
// 
// s 


// 1 --> 3 --> 4 --> N  2 --> N

// p    t1     h      t

// 1 --> 2 --> 3 --> 4 --> N


Node* linkedList :: insertionSort(Node* head) {
    if(!head || !head -> next) return head;
    Node* curr = head, *temp = NULL, *prev = NULL;
    while(curr -> next) {
        if(curr -> data > curr -> next -> data) {
            temp = head;
            prev = NULL;
            while(temp && temp -> data < curr -> next -> data) {
                prev = temp;
                temp = temp -> next;
            }
            if(temp && prev) {
                prev -> next = curr -> next;
                prev = temp;
                temp = curr -> next;
                curr -> next = temp -> next;
                temp -> next = prev;
            }
            else if(temp && !prev) {
                temp = curr -> next -> next;
                curr -> next -> next = head;
                head = curr -> next;
                curr -> next = temp;
            }
        }
        else curr = curr -> next;

    }
    return head;
}



int main()
{
    Node* head = NULL;
    linkedList list;
    
    head = list.addFirst(head, 1);
    head = list.addFirst(head, 8);
    head = list.addFirst(head, 4);
    head = list.addFirst(head, 2);
    head = list.addFirst(head, 7);
    head = list.addFirst(head, 5);
    head = list.addFirst(head, 3);
    head = list.addFirst(head, 9);
    head = list.addFirst(head, 6);
    
    // 3 --> 1 --> 4 --> 2
    
    list.showlist(head);
    
    // head = list.mergeSort(head);
    
    head = list.insertionSort(head);
    
    list.showlist(head);
    
    return 0;
}


