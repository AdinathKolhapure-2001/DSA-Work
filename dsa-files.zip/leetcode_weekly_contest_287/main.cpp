#include <bits/stdc++.h>

using namespace std;

// leetcode 2224
int convertTime(string current, string correct) {
        
        int currentH = stoi(current.substr(0,2));
        int currentM = stoi(current.substr(3,2));
        int correctH = stoi(correct.substr(0,2));
        int correctM = stoi(correct.substr(3,2));
        
        int x = currentH*60+currentM;
        int y = correctH*60+correctM;
        int a = floor((y-x)/60);
        int b = (y-x)%60;
        int c = floor(b/15);
        int d = b%15;

        int cnt = a + c +  floor(d/5) + d%5;
        
        
        return cnt;
        
    }

int main()
{
    string current = "00:00", correct = "23:59"; 
    
    cout << convertTime(current, correct);

    return 0;
}