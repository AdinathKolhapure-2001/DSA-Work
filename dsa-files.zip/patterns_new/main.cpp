#include <iostream>

using namespace std;

int main()
{
    // Rectangle 
    // for(int i=0; i<5; i++) {
    //     for(int j=0; j<4; j++) {
    //         cout << "* ";
    //     }
    //     cout << "\n";
    // }
    
    // Hollow Rectangle 
    // for(int i=0; i<5; i++) {
    //     for(int j=0; j<4; j++) {
    //         if(i==0 || j==0 || i==4 || j==3)
    //         cout << "* ";
    //         else cout << "  ";
    //     }
    //     cout << "\n";
    // }
    
    // Inverted pyramid
    // for(int i=5; i>0; i--) {
    //     for(int j=i; j>0; j--) {
    //         cout << "* ";
    //     }
    //     cout << "\n";
    // }
    
    // Half pyramid
    // for(int i=0; i<5; i++) {
    //     for(int j=0; j<5; j++) {
    //         if(j<4-i)
    //         cout << "  ";
    //         else cout << "* ";
    //     }
    //     cout << "\n";
    // }
    
    
    //half number pyramid
    // for(int i=1; i<=5; i++) {
    //     for(int j=0; j<i; j++) {
    //         cout << i << " ";
    //     }
    //     cout << "\n";
    // }
    
    
    // Floyd's triangle
    // int cnt = 1;
    // for(int i=1; i<=5; i++) {
    //     for(int j=0; j<i; j++) {
    //         cout << cnt++ << " ";
    //     }
    //     cout << "\n";
    // }
    
    
    // Butterfly pattern
    // for(int i=0; i<4; i++) {
    //     for(int j=0; j<=i; j++) {
    //         cout << "* ";
    //     }
    //     int spaces=8-2*(i+1);
    //     for(int i=0; i<spaces; i++) {
    //         cout << "  ";
    //     }
    //     for(int j=0; j<=i; j++) {
    //         cout << "* ";
    //     }
    //     cout << "\n";
    // }
    // for(int i=3; i>=0; i--) {
    //     for(int j=0; j<=i; j++) {
    //         cout << "* ";
    //     }
    //     int spaces=8-2*(i+1);
    //     for(int i=0; i<spaces; i++) {
    //         cout << "  ";
    //     }
    //     for(int j=0; j<=i; j++) {
    //         cout << "* ";
    //     }
    //     cout << "\n";
    // }
    
    // Inverted pattern
    // for(int i=5; i>=1; i--) {
    //     for(int j=1; j<=i; j++) {
    //         cout << j << " ";
    //     }
    //     cout << "\n";
    // }
    
    
    // 0-1 pattern 
    // for(int i=1; i<=5; i++) {
    //     for(int j=1; j<=i; j++) {
    //         if((i+j)&1) cout << "0 ";
    //         else cout << "1 ";
    //     }
    //     cout << "\n";
    // }
    
    
    // Rombus
    // for(int i=1; i<=5; i++) {
    //     for(int k=0; k<5-i; k++) {
    //         cout << "  ";
    //     }
    //     for(int j=0; j<5; j++) {
    //         cout << "* ";
    //     }
    //     cout << "\n";
    // }
    
    
    // NUmber pattern
    // for(int i=1; i<=5; i++) {
    //     for(int k=0; k<5-i; k++) {
    //         cout << " ";
    //     }
    //     for(int j=1; j<=i; j++) {
    //         cout << j << " ";
    //     }
    //     cout << "\n";
    // }
    
    
    // palindromic pattern
    // for(int i=1; i<=5; i++) {
    //     for(int j=1; j<=5-i; j++) cout << "  ";
    //     for(int k= i; k>=1; k--) cout << k << " ";
    //     for(int l=2; l<=i; l++) cout << l << " ";
    //     cout << "\n";
    // }
    
    
    // star pattern 
    // for(int i=1; i<=4; i++) {
    //     for(int j=1; j<=4-i; j++) {
    //         cout << "  ";
    //     }
    //     for(int k=1; k<=2*i-1; k++) {
    //         cout << "* ";
    //     }
    //     cout << "\n";
    // }
    // for(int i=4; i>=1; i--) {
    //     for(int j=1; j<=4-i; j++) {
    //         cout << "  ";
    //     }
    //     for(int k=1; k<=2*i-1; k++) {
    //         cout << "* ";
    //     }
    //     cout << "\n";
    // }
    
    
    // zig-zag pattern
    // for(int i=1; i<=3; i++) {
    //     for(int j=1; j<=9; j++) {
    //         if((i+j)%4==0 || (i==2 && j%4==0)) {
    //             cout << "* ";
    //         }
    //         else cout << "  ";
    //     }
    //     cout << "\n";
    // }
    
    
    
    return 0;
}