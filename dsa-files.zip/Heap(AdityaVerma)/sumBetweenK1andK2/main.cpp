#include <bits/stdc++.h>

using namespace std;

// https://www.youtube.com/watch?v=3ioQQQrnw4Q&list=PL_z_8CaSLPWdtY9W22VjnPxG30CXNZpI9&index=12&ab_channel=AdityaVerma

// Given an array of integers and two numbers k1 and k2. 
// Find the sum of all elements between given two k1’th and k2’th smallest elements of the array. 
// It may  be assumed that all elements of array are distinct.

// Example :
// Input : arr[] = {20, 8, 22, 4, 12, 10, 14},  k1 = 3,  k2 = 6  
// Output : 26          
//          3rd smallest element is 10. 6th smallest element 
//          is 20. Sum of all element between k1 & k2 is
//          12 + 14 = 26 


// One simple solution can be sort the array first then by using accumulate function sum 
// the numbers between index k1-1 and k2-1

// By using max heap
// Create a function which will return the kth minimum number 
// pass the k1 and k2 to the function and save the values k1thSmallest and k2thSmallest
// Now traverse the array and sum those numbers which lies between k1thSmallest and k2thSmallest


int kthSmallest(vector<int> nums, int k) {
    priority_queue<int> pq;
    for(int num : nums) {
        pq.push(num);
        if(pq.size() > k)
            pq.pop();
    }
    return pq.top();
}

int sumBetweenK1andK2(vector<int> nums, int k1, int k2) {
    int sum = 0;
    int k1thSmallest = kthSmallest(nums, k1);
    int k2thSmallest = kthSmallest(nums, k2);
    for(int num : nums) {
        if(num > k1thSmallest && num < k2thSmallest)
            sum += num;
    }
    return sum;
}

int main()
{
    vector<int> nums = {20, 8, 22, 4, 12, 10, 14};
    int k1 = 3, k2 = 6;
    
    int sum = sumBetweenK1andK2(nums, k1, k2);
    
    cout << sum;

    return 0;
}
