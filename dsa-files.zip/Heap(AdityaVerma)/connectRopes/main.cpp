#include <bits/stdc++.h>

using namespace std;

// https://www.youtube.com/watch?v=_k_c9nqzKN0&list=PL_z_8CaSLPWdtY9W22VjnPxG30CXNZpI9&index=10&ab_channel=AdityaVerma

// There are given n ropes of different lengths, we need to connect these ropes into one rope. 
// The cost to connect two ropes is equal to sum of their lengths. We need to connect the ropes 
// with minimum cost.

// For example if we are given 4 ropes of lengths 4, 3, 2 and 6. We can connect the ropes in following ways.
// 1) First connect ropes of lengths 2 and 3. Now we have three ropes of lengths 4, 6 and 5.
// 2) Now connect ropes of lengths 4 and 5. Now we have two ropes of lengths 6 and 9.
// 3) Finally connect the two ropes and all ropes have connected.

// Total cost for connecting all ropes is 5 + 9 + 15 = 29. This is the optimized cost for connecting ropes. 
// Other ways of connecting ropes would always have same or more cost. For example, if we connect 4 and 6 
// first (we get three strings of 3, 2 and 10), then connect 10 and 3 (we get two strings of 13 and 2). 
// Finally we connect 13 and 2. Total cost in this way is 10 + 13 + 15 = 38

// At any time add two minimum ropes to get minimum cost 
// Use min heap bacause we want minimum values 
// pop two values which will be two minimum add it into the cost and also push it into the heap


int connectRopes(vector<int> ropes) {
    priority_queue<int, vector<int>, greater<int>> pq;
    int cost = 0;
    for(int rope : ropes) {
        pq.push(rope);
    }
    while(pq.size() > 1) {
        int r1 = pq.top();
        pq.pop();
        int r2 = pq.top();
        pq.pop();
        cost += r1 + r2;
        pq.push(r1 + r2);
    }
    return cost;
}

int main()
{
    vector<int> ropes = {4, 3, 2, 6};
    int minCost = connectRopes(ropes);
    cout << minCost;

    return 0;
}