#include <bits/stdc++.h>

using namespace std;

// https://www.youtube.com/watch?v=hLR5aMzYGGk&list=PL_z_8CaSLPWdtY9W22VjnPxG30CXNZpI9&index=7&ab_channel=AdityaVerma

// Print the elements of an array in the increasing frequency if 2 numbers have same frequency 
// then print the one which came first.

// Example:
// Input : arr[] = {2, 5, 2, 8, 5, 6, 8, 8}
// Output : arr[] = {8, 8, 8, 2, 2, 5, 5, 6} 


#define pii pair<int, int>

class cmp {
    public:
    bool operator()(const pii &p1, const pii &p2) {
        return p1.first == p2.first ? p1.second > p2.second : p1.first < p2.first;
    }
};

vector<int> frequencySort1(vector<int> nums) {
    int n = nums.size();
    unordered_map<int, int> mp;
    priority_queue<pii, vector<pii>, cmp> pq;
    vector<int> res(n);
    for(int num : nums) mp[num]++;
    for(auto &[num, freq] : mp) {
        pq.push({freq, num});
    }
    for(int i = 0; i < n;) {
        int j = pq.top().first;
        while(j--)
            res[i++] = pq.top().second;
        pq.pop();
    }
    return res;
}

int main()
{
    vector<int> nums = {2, 4, 1, 1, 5, 2, 3, 3, 1, 6};
    
    nums = frequencySort1(nums);
    
    for(int num : nums) 
        cout << num << " ";

    return 0;
}

