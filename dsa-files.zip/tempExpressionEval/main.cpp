#include <iostream>
#include <stack>

using namespace std;


int calculate(int x, int y, char op)
{
    switch(op)
    {
        case '+':
            return x + y;   // 101
            break;
        
        case '-':
            return x - y;
            break;
        
        case '*':
            return x * y;
            break;
            
        case '/':
            return x / y;
    }
    return -1;
}

int prefixEvaluation(string expr)
{
    // Scan the Expression form right to left                   // 
    // if you encounter an oprand then push into the stack
    // if you encounter an operator pop two elements from the stack 
    // res = first poped element <operator> second poped element    --> 6 / 3 = 2         
    // push(res)
    
    // final result = pop 
    
    stack<char> s;
    int x, y, res;
    
    for(int i = expr.length() - 1; i >= 0; i--)     // + 2 3
    {
        if(expr[i] == ' ')
        {
            continue;
        }
        else if(isdigit(expr[i]))       // Convert ascci to digit 
        {
            s.push(expr[i] - '0');        // 5
        }
        else
        {
            x = s.top();    // 2
            s.pop();
            y = s.top();   // 3
            s.pop();
            
            res = calculate(x, y, expr[i]);
            
            s.push(res);
        }
    }
    
    res = s.top();
    s.pop();
    return res;
    
}



int postfixEvaluation(string expr)
{
    // Scan the Expression form left to right                   // 
    // if you encounter an oprand then push into the stack
    // if you encounter an operator pop two elements from the stack 
    // res =  second poped element <operator> first poped element    --> 6 / 3 = 2         
    // push(res)
    
    // final result = pop 
    
    stack<char> s;
    int x, y, res;
    
    for(int i = 0; i < expr.length(); i++)     // 2 - 3 != 3 - 2 and 2 / 3 != 3 / 2
    {                                         // 2 3 - == 2 - 3
        if(expr[i] == ' ')                  // 2 3  
        {                                   // x = 3, y = 2 , y - x;
            continue;
        }
        else if(isdigit(expr[i]))       // Convert ascci to digit 
        {
            s.push(expr[i] - '0');        // 5
        }
        else
        {
            x = s.top();    // 2
            s.pop();
            y = s.top();   // 3
            s.pop();
            
            res = calculate(y, x, expr[i]);
            
            s.push(res);
        }
    }
    
    res = s.top();
    s.pop();
    return res;
    
}




int main()
{
    // We are going to deal with binary operators
    // binary operators: +, -, /, *, ^, %
    // Uniary operators: ++, --, !
    // ternary operator: conditon ? true : false
    
    // oprand --> can be a single number or a complex Expression
    
    // Infix Expression  -->  oprand <operator> oprand --> 2 + (3 * 4)
    
    // Prefix Expression  --> Polish Notations -->   <operator> oprand oprand   --> +2*34
    
    // Postfix Expression: --> Reverse Polish Notations -->  oprand oprand <operator>  --> 234*+
    
    
    // Infix Expression --> [{(a * (b / c)) + (d * e)} - f]  
    
    // Prefix Expression -->    - + * a / b c * d e f
    
    // Postfix Expression --> a b c / * d e * + f - 
    
    
    // a * (b + c) - (d / e)
    // - * a + b c /de
    //  a b c + * d e / - 
    
    
    // Infix : 2 * (3 + 4) - (6 / 3) =  14 - 2  = 12
    
    // Prefix : - * 2 + 3 4 / 6 3           // <operator> oprand oprand
    
    // postfix : 2 3 4 + * 6 3 / -
    
    
    
    // {5 *(2 - 3)} + (8 / 2)   = -1
    
    // + * 5 - 2 3 / 8 2  
    
    // 5 2 3 - * 8 2 / +
    
    
    // (( A * (B + D)/E) - F * (G + H / K)))
    
    // WARNIING : 
    
    //  Infix : ((2 * (2 + 3) / 5)) - 2 * (3 + 5 / 5)  = 2 - 8   =   -6
    
    // Prefix : - / * 2 + 2 3 5 2 * 2 + 3 / 5 5     -->  - * 2 / + 2 3 5 2 * 2 + 3 / 5 5    --> check this --> ans = 0
    
    // Postfix : 2 2 3 + * 5 / 2 3 5 5 / + * -   -->    2 2 3 + 5 / * 2 3 5 5 / + * -       --> this is correct --> ans  = -6
    
    
    // postfix : 2 2 3 + * 5 / 2 3 5 5 / + * - | Prefix : - * 2 / + 2 3 5 * 2 + 3 / 5 5
    
    // 8 0  
    
    // -6 
    
    
    
    
    // Prefix Evaluation
    // Scan the Expression form right to left                   // 
    // if you encounter an oprand then push into the stack
    // if you encounter an operator pop two elements from the stack 
    // res = first poped element <operator> second poped element    --> 6 / 3 = 2         
    // push(res)
    
    // final result = pop 
    

    
    
    
    string preExpr, postExpr;
    
    cout << "Enter the Prefix Expression: ";
    
    getline(cin, preExpr);
    
    cout << "Enter the Postfix Expression: ";
    
    getline(cin, postExpr);
    
    int result1 = prefixEvaluation(preExpr);
    
    int result2 = postfixEvaluation(postExpr);
    
    cout << "Prefix Evaluation is = " << result1 << endl;
    
    cout << "Postfix Evaluation is = " << result2 << endl;
    
    
    
    
    
    // string temp = "2 + (3 * 4)";
    
    // // cout << temp[0] << endl;
    // // // '0' = 48, '1' = 49, '2' = 50, ' ' = 32, '+' = 43, '3' = 51

    // // printf("%d", temp[5]);
  
    // cout << "sum of ascii : " << temp[0] + temp[5] << endl;
    
    // 9 + 11   // 2 9  --> Note : You can not pass two digit char 
    
    
    
    // Postfix algorithm 
    // Scan the Expression form left to right                   // 
    // if you encounter an oprand then push into the stack
    // if you encounter an operator pop two elements from the stack 
    // res = first poped element <operator> second poped element    --> 6 / 3 = 2         
    // push(res)
    
    // final result = pop 
    
    
    return 0;
}
 



