#include <iostream>

using namespace std;

int search(int arr[], int target, int low, int high) {
    if(low > high) {
        return -1;
    }
    int mid = (low + high) >> 1;
    if(target == arr[mid]) {
        return mid;
    }
    if(target > arr[mid]) {
        return search(arr, target, mid + 1, high);
    }
    return search(arr, target, low, mid - 1);
}

int main()
{
    int arr[] = {2, 4, 6, 8, 15, 43, 76, 85, 123};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    int target = 6;
    
    cout << search(arr, target, 0, size - 1);

    return 0;
}