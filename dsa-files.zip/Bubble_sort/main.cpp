/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

void Bubble_sort(int arr[],int size)
{   int flag;
    for(int i = 0; i<size-1; i++)
    {   flag = 0;
        for(int j = 0; j<size-i-1;j++)
        {
            if(arr[j]>arr[j+1])
            {
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
                flag = 1;
            }
        }
        if(flag == 0)
            break;
    }
}

void print_array(int arr[],int size)
{
    for(int i = 0;i<size; i++)
    {
        cout<<arr[i]<<" ";
    }
}

int main()
{
    int arr[] = {5,6,89,4,3,1,7,9,54};
    int size = sizeof(arr)/sizeof(arr[0]);
    Bubble_sort(arr,size);
    cout<<"Sorted array:"<<endl;
    print_array(arr,size);
    return 0;
}

