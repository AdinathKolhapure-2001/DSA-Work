#include <bits/stdc++.h>

using namespace std;


int a[5]= {1}; //{0, 0, 0, 0, 0}

int main()
{
    
    cout << "\nInside main" << endl;
    array<int, 5> arr; //{?, ?, ?, ?, ?}
    arr.fill(1);    // fill's all the positions
    
    for(int i = 0; i < 5; i++)
    {
        cout << arr.at(i) << " "; // Either we can access through index or using 'at' function
    }
    
    
    cout << "\nOutside main" << endl;
    for(int i = 0; i < 5; i++)
    {
        cout << a[i] << " ";
    }
    
    
    // Iterators
    
    // begin()  --> points to the first element to the container
    // end()   --> points to a memory location just after last element
    // rbegin()    --> points to the last element to the container
    // rend()  --> points to a memory location just before first element
    
    cout << "\nEnter the array elements: " << endl;
    for(int i = 0; i < 5; i++)
    {
        cin >> arr[i];
    }
    
    array<int, 5>::iterator itr;
    itr = arr.begin();
    
    cout << "First element(arr.begin()): " << *itr << endl;
    
    itr = arr.end();
    
    cout << "arr.end(): " << *itr << endl;
    
    cout << "Last element(arr.end() - 1): " << *(itr - 1) << endl;
    
    array<int, 5>::reverse_iterator itr1;
    
    itr1 = arr.rbegin();
    
    cout << "Last element(arr.rbegin()): " << *itr1 << endl;
    
    itr1 = arr.rend();
    
    cout << "arr.rend(): " << *itr1 << endl;
    
    cout << "First element(arr.rend() - 1): " << *(itr1 - 1) << endl;
    
    // Printing the array in forward direction using Iterators
    cout << "Array in forward direction: " << endl;
    for(auto itr = arr.begin(); itr != arr.end(); itr++)
    {
        cout << *itr << " ";
    }
    
    cout << "\n";
    
    // Printing the array in reverse order using Iterators
    cout << "Array in reverse order: " << endl;
    for(auto itr = arr.rbegin(); itr != arr.rend(); itr++)
    {
        cout << *itr << " ";
    }
    
    cout << "\n";
    
    // size of an array                                 // Alternatives
    cout << "Array size: " << arr.size() << endl;       // sizeof(arr) / sizeof(arr[0])
    
    // first element of the Array
    cout << "First element: " << arr.front() << endl;   // arr.at(0), arr[0]
    
    // last element of the array
    cout << "Last element: " << arr.back() << endl;     // arr.at(arr.size() - 1), arr[arr.size() - 1]
    
     
    
    
    
    return 0;
}