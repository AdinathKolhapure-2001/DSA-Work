#include <iostream>

using namespace std;

void bubbleSort(int arr[], int n) // n = 6 
{
    int count = 0; 
    bool flag;
    for(int i = 0; i <= n - 2; i++)    // 5     i = 5
    {
        flag = true;
        for(int j = 0; j <= n - i - 2; j++)   // j = 1     j <= 0       5 + 4 + 3 + 2 + 1 = 15
        {
             
            if(arr[j] > arr[j + 1])             // int arr[] = {1, 2, 3, 4, 5, 6};
            {                                   // flag = true
                swap(arr[j], arr[j + 1]);       // count = 14, count if !flag = 15
                flag = false;
            }
                
            count++;        // 
        }
        
        if(flag == true)
        {
            break;
        }
    }
    
    cout << "Count = " << count << endl;
}

int main()
{
    
// itr --> 1
    // itr --> 1 -->  | 5 | 2 | 4 | 1 | 0 | 3|
    // arr[0] > arr[1] --> swap(arr[0], arr[1])
    // itr --> 2 -->  | 2 | 5 | 4 | 1 | 0 | 3|
    // arr[1] > arr[2] --> swap(arr[1], arr[2])
    // itr --> 3 -->  | 2 | 4 | 5 | 1 | 0 | 3|
    // arr[2] > arr[3] --> swap(arr[2], arr[3])
    // itr --> 4 -->  | 2 | 4 | 1 | 5 | 0 | 3|
    // arr[3] > arr[4] --> swap(arr[3], arr[4])
    // itr --> 5 -->  | 2 | 4 | 1 | 0 | 5 | 3|
    // arr[4] > arr[5] --> swap(arr[4], arr[5])
    // | 2 | 4 | 1 | 0 | 3 | 5 |        i = 0;  j <= n - i - 2
    //                                  i = 1;  j <= n - 1 - 2
    //                                  i = 2;  j <= n - 2 - 2
// itr --> 2
    // itr --> 1 -->  | 2 | 4 | 1 | 0 | 3 | 5 |
    // itr --> 2 -->  | 2 | 4 | 1 | 0 | 3 | 5 |
    // arr[1] > arr[2] --> swap(arr[1], arr[2])
    // itr --> 3 -->  | 2 | 1 | 4 | 0 | 3 | 5 |
    // arr[2] > arr[3] --> swap(arr[2], arr[3])
    // itr --> 4 -->  | 2 | 1 | 0 | 4 | 3 | 5 |
    // arr[3] > arr[4] --> swap(arr[3], arr[4])
    // | 2 | 1 | 0 | 3 | 4 | 5 |
    
    
    // final arr = | 0 | 1 | 2 | 3 | 4 | 5 |
    
    // arr = | 5 | 2 | 4 | 1 | 0 | 3|
    
    // n = 6
    
    // for i -> 0 to n - 2                      i = 0, 1, 2, 3 ,4  --> 0 : 5, 1 : 4, 2 : 3, 3 : 2, 4 : 1
    // {
    //       for j -> 0 to n - i - 2    j = 0, 1, 2, 3, 4
    //      {
    //            if arr[j] > arr[j + 1] --> swap(arr[j], arr[j+1])
    //      }
    // }
    
    int arr[] = {6, 5, 4, 3, 2, 1};  // size = 6  practical : itr = 15   theory : O(n^2) 
    int size = sizeof(arr) / sizeof(arr[0]);  
    
    bubbleSort(arr, size);
    
    cout << "After sorting: " << endl;
    
    for(int num : arr)
    {
        cout << num << " | ";
    }
    
    
    /// It is stable and inplace algorithm
    
    // Before sorting
    //           f        l
    // arr = {4, 2, 1, 6, 2};
    
    // After sorting
    // arr = {1, 2, 2, 4, 6}
    //           f  l
    return 0;
}

