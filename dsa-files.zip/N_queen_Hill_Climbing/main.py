import random
import copy

def C2n(n):
    'returns C(2,n)'
    return n * (n-1) / 2


class CheckeredPageState:
    'defines a state. each column has only one queen in each state'

    def __init__(self, checkeredPage):
        self.checkeredPage = checkeredPage
        self.dimension = len(self.checkeredPage)
        self.setDic()
        self.setHeuristic()

    def setDic(self):
        'sets 3 dictionaries. for example: dicRows[i] = k means that the ith row has k queens in it. O(dimension^2)'
        dicRows = {}
        dicDiagonal1 = {}
        dicDiagonal2 = {}
        for i in range(self.dimension):
            dicRows[i] = 0
            for j in range(self.dimension):
                dicDiagonal1[i-j] = 0
                dicDiagonal2[i+j] = 0
        for i in range(self.dimension):
            for j in range(self.dimension):
                if self.checkeredPage[i][j]:
                    dicRows[i] += 1
                    dicDiagonal1[i-j] += 1
                    dicDiagonal2[j+i] += 1
        self.dicRows = dicRows
        self.dicDiagonal1 = dicDiagonal1
        self.dicDiagonal2 = dicDiagonal2

    def setHeuristic(self):
        'sets heuristic of a state.heuristic of a state is the number of pairs of queens that are attacking each other. O(dimension) '
        h = 0
        for key in self.dicRows:
            if self.dicRows[key] > 1:
                h += C2n(self.dicRows[key])
        for key in self.dicDiagonal1:
            if self.dicDiagonal1[key] > 1:
                h += C2n(self.dicDiagonal1[key])
        for key in self.dicDiagonal2:
            if self.dicDiagonal2[key] > 1:
                h += C2n(self.dicDiagonal2[key])
        self.h = h

    def getRandom(self):
        'between successors of a state which have the lowest heuristic, returns a random one. O(dimension^4)'
        neighbors = []
        huristic = float("inf")
        for j in range(self.dimension):
            for i in range(self.dimension):
                if self.checkeredPage[i][j] == 1:
                    ikeep = i
                    break
            for i in range(self.dimension):
                if self.checkeredPage[i][j] == 0:
                    newCheck = copy.deepcopy(self.checkeredPage)
                    newCheck[i][j] = 1
                    newCheck[ikeep][j] = 0
                    neighbor = CheckeredPageState(newCheck)
                    if neighbor.h <= huristic:
                        neighbors = []
                        huristic = neighbor.h
                        neighbors.append(neighbor)
        return(random.choice(neighbors))

    
    def printPage(self):
        'prints the checkered page of the current state O(n^2)'
        for row in self.checkeredPage:
            for col in row:
                print(col,' ', end = '')
            print()


def HillCLimbing(checkeredPageInitial):
    'gets the initial checkered page and performs the hill climbing algorithm'
    current = CheckeredPageState(checkeredPageInitial)
    while 1:
        neighbor = current.getRandom()
        if neighbor.h >= current.h:         
            if current.h == 0:
                return True, current
            else:
                return False, current
        current = neighbor                  
        
    
def getRandomCheckeredPage(dimension):
    'returns a random checkered page in which each column has exactly one queen in it'
    checkeredPage = [[0 for i in range(dimension)] for j in range(dimension)]
    randNumbers = random.sample(range(0, dimension), dimension)
    for j in range(dimension):
        checkeredPage[randNumbers[j]][j] = 1
    return checkeredPage




if __name__ == '__main__':
    dimension = 8
    randomCheck = getRandomCheckeredPage(dimension)
    foundSolution, finalSolution  = HillCLimbing(randomCheck)
    finalSolution.printPage()
    print("current state h:", finalSolution.h)
    if foundSolution:
        print("The hill climbing algorithm found a solution")
    else:
        print("The hill climbing algorithm got stuck in local maximum")
    
    



