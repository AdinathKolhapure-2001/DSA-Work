import java.util.Scanner;

class numberArray
{
    private int evenCount, oddCount, primeCount;
    
    public void Count(int arr[],int size)
    {
        for(int i=0; i<size; i++)
        {
            if(arr[i]%2==0)
            {
                evenCount++;
            }
            else
            {
                oddCount++;
            }
            
        }
    }
    
    
    public void primeCount(int arr[], int size)
    {
        int m, flag;
        
        for(int i=0; i<size; i++)
        {
            flag=0;
            if(arr[i]<=1)
            {
                continue;
            }
            m=arr[i]/2;
            
            for(int j=2; j<=m; j++)
            {
                if(arr[i]%j==0)
                {
                    flag=1;
                    break;
                }
             
            }
            if(flag==0)
            {
                primeCount++;
            }
        
        }
        
        System.out.println("\nPrime count: "+primeCount);
    }
    
    public void display()
    {
        System.out.println("\nEven count: "+evenCount);
        System.out.println("\nOdd count: "+oddCount);
    }
    
    
}

public class Main
{
    public static Scanner scan = new Scanner(System.in);
    
	public static void main(String[] args) {
		
		
		int size;
		
		numberArray obj = new numberArray();
		
		System.out.println("\nEnter the size of an array: ");
		size=scan.nextInt();
		
		int arr[] = new int[size];
		
		for(int i = 0; i<size; i++)
		{
		    arr[i] = scan.nextInt();
		    
		}
		
		obj.Count(arr,size);
		obj.display();
		obj.primeCount(arr,size);
	}
}
