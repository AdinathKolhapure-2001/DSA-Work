-- CREATE TABLE employees (
--     employee_id int,
--     first_name varchar(50),
--     last_name varchar(20),
--     hourly_pay decimal(5, 2),
--     hire_date date
--   );

-- Altering the table

-- alter table employees
-- add phone_number varchar(20);

-- alter table employees
-- rename column phone_number to email;

-- ALTER TABLE employees
-- drop column email;

-- alter table employees
-- add phone_number varchar(20);


-- Insertion of data into the table

-- insert into employees
-- values (1, "Eugene", "Krabs", 25.50, '2023-01-02'),
--       (2, "Squidward", "Tantacles", 15.00, "2023-01-03"),
--       (3, "Spongebob", "Squarepants", 12.50, "2023-01-04"),
--       (4, "Patric", "Star", 12.50, "2023-01-05"),
--       (5, "Sandy", "Cheeks", 17.25, "2023-01-06");
       
       
-- insert into employees (employee_id, first_name, last_name)
-- values (6, "Sheldon", "Plankton");


-- Selecting data from the table

-- select * from employees;


-- select first_name, last_name 
-- from employees;

-- select * 
-- from employees
-- where employee_id = 1;

-- select * 
-- from employees 
-- where first_name = "Spongebob";

-- select * 
-- from employees
-- where hourly_pay >= 15;
  
-- select * 
-- from employees
-- where hire_date <= "2023-01-03";
  
-- select * 
-- from employees 
-- where employee_id != 1;

-- select * 
-- from employees
-- where hire_date is null;


-- update data from table

-- update employees
-- set hourly_pay = 10.50,
--     hire_date = "2023-01-07";
-- where employee_id = 6;

-- update employees
-- set hire_date = null
-- where employee_id = 6;

-- update employees 
-- set hourly_pay = 10.25;

-- select * from employees;

-- delete dat from table

-- delete from employees;  -- deletes all the data from table

-- delete from employees
-- where employee_id = 6;

-- select * from employees;


-- autocomit, comit and rollback

-- By default autocomit is set to on, it saves changes automatically
-- When we use comit we save the canges manualy, to undo the changes we can use rollback
  
  
-- to get current date use current_date() function
-- to get current time use current_time() function
-- to get current date time use now() function 
   
   
 -- Unique constraint
 
-- CREATE table products (
--     product_id int,
--     product_name varchar(25) unique,
--     price decimal(4, 2)
-- );

-- alter table products
-- add constraint unique(product_name);
  
  
-- insert into products
-- values (100, "hamburger", 3.99),
--       (101, "fries", 1.89),
--       (102, "soda", 1.00),
--       (103, "ice cream", 1.49);

  
-- select * from products;
  
  
-- not null constraint
  
-- CREATE table products (
--     product_id int,
--     product_name varchar(25),
--     price decimal(4, 2) not null
-- );
  
  
-- alter table products
-- modify price decimal(4, 2) not null
  
-- insert into products
-- values (100, "hamburger", 3.99),
--       (101, "fries", 1.89),
--       (102, "soda", 1.00),
--       (103, "ice cream", 1.49),
--       (104, "cookie", null);    -- error
      
      
      
      
-- check constraint


-- CREATE TABLE employees (
--     employee_id int,
--     first_name varchar(50),
--     last_name varchar(50),
--     hourly_pay decimal(5, 2),
--     hire_date date,
--     constraint chk_hourly_pay check(hourly_pay >= 10.00)
--   );     
      

-- alter TABLE employees
-- add constraint chk_hourly_pay check(hourly_pay >= 10.00)
      
 
-- insert into employees
-- values (1, "Eugene", "Krabs", 25.50, '2023-01-02'),
--       (2, "Squidward", "Tantacles", 15.00, "2023-01-03"),
--       (3, "Spongebob", "Squarepants", 12.50, "2023-01-04"),
--       (4, "Patric", "Star", 12.50, "2023-01-05"),
--       (5, "Sandy", "Cheeks", 17.25, "2023-01-06");
      
      
-- insert into employees
-- values (6, "Sheldon", "Plankton", 10.00, "2023-01-07");

-- drop check

-- alter TABLE employees
-- drop check chk_hourly_pay;

-- select * from employees;     
      
      
      
      
-- default constraint

-- CREATE table products (
--     product_id int,
--     product_name varchar(25),
--     price decimal(4, 2) default 0
-- );
      
-- alter table products
-- alter price set default 0;

-- insert into products
-- values (100, "hamburger", 3.99),
--       (101, "fries", 1.89),
--       (102, "soda", 1.00),
--       (103, "ice cream", 1.49);
      
-- insert into products (product_id, product_name)
-- values  (104, "straw"),
--         (105, "napkin"), 
--         (106, "fork"),
--         (107, "spoon");
      
-- select * from products;


-- CREATE table transactions (
--     transaction_id int,
--     amount decimal(5, 2),
--     transaction_date datetime default now()
-- );


-- insert into transactions (transaction_id, amount)
-- values (2, 1.85);

-- select * from transactions;




-- primary key constraint

-- CREATE table transactions (
-- transaction_id int primary key,
-- amount decimal(5, 2)
-- );


-- alter table transactions
-- add constraint 
-- primary key(transaction_id);


-- insert into transactions
-- values (1000, 4.99),
--         (1001, 3.45),
--         (1002, 4.12),
--         (1003, 5.12);

-- select * from transactions;














