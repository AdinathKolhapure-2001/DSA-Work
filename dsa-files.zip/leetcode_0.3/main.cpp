#include <bits/stdc++.h>

using namespace std;

// leetcode 2047 :
    
    bool valid(string& s) {
        int hyphen = 0, N = s.length();
        for(int i = 0; i < N; i++) {
            if(isdigit(s[i])) return false;
            else if(isalpha(s[i])) continue;
            else if(s[i] == '-') {
                if(++hyphen > 1) return false;
                else if(i <= 0 || i >= N-1 || !isalpha(s[i-1]) || !isalpha(s[i+1])) return false;
            }
            else if(i != N-1) return false;
        }
        return true;
    }
    
    int countValidWords(string& sentence) {
        istringstream s(sentence);
        string word;
        int cnt = 0;
        while(s>>word) cnt+=valid(word);
        return cnt;
    }



int main()
{
    // find the max words in a sentence:
    // string sentences[] = {"alice and bob love leetcode", "i think so too", "this is great thanks very very much"};
    // string word;
    // int maxWords = 0;
    // for(string str:sentences) {
    //     int cnt = 0;
    //     istringstream s(str);
    //     while (s >> word) cnt++;
    //     maxWords = max(maxWords,cnt);
    // }
    // cout << maxWords;
    
    string sentence = "he bought 2 pencils, 3 erasers, and 1 pencil-sharpener.";
    
    cout << countValidWords(sentence);

    return 0;
}