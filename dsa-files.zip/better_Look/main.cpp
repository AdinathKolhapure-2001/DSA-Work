#include <iostream>
#include <algorithm>
using namespace std;

void requestQueue(int arr[], int size)
{
    for(int i = 0; i < size; i++)
    {
        cout << "\nEnter the track number: ";
        cin >> arr[i];
    }
}


int better_Look(int arr[], int size, int head_position)
{
    int m = 0;  // requests less than head position 
    int n = 0;  // requests greater than head position 
    
    for(int i = 0; i < size; i++)       
    {
        if(arr[i] <= head_position)
        {
            m++;
        }
        else
        {
            n++;
        }
    }
    
    sort(arr, arr + size);
    
    int seekTime;
    
    if(m < n)       // move head towards higher tracks
    {
        seekTime = (arr[size - 1] - head_position) + (arr[size - 1] - arr[0]);
    }
    else            // move head towards lower tracks
    {
        seekTime = (head_position - arr[0]) + (arr[size - 1] - arr[0]);
    }
    
    return seekTime;
}

// Examples: 
// 176, 79, 34, 60, 92, 11, 41, 114
// head = 50
// seek time = 291

// 98, 183, 41, 122, 14, 124, 65, 67
// head = 53
// seek time = 299

// 98, 137, 122, 183, 14, 133, 65, 78
// head = 54
// seek time = 298

int main()
{
    int n, head_position, seekTime;
    
    cout << "\nEnter the size: ";
    cin >> n;
    
    int arr[n];
    
    
    requestQueue(arr, n);
    
    cout << "\nEnter the head position: ";
    cin >> head_position;
    
    seekTime = better_Look(arr, n, head_position);
    
    cout << "\nSeek Time = " << seekTime << endl;

    return 0;
}

