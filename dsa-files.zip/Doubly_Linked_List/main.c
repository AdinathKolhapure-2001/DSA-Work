/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>


struct node {
    int data;
    struct node* next;
    struct node* prev;
};

struct node* createNode(int data) {
    struct node* newNode = (struct node*)malloc(sizeof(struct node));
    newNode -> data = data;
    newNode -> next = NULL;
    newNode -> prev = NULL;
    
    return newNode;
}


struct node* addNodeAtEnd(struct node* head, int data) {
    struct node* newNode = createNode(data);
    
    if(head == NULL) {
        head = newNode;
    }
    else {
        struct node* temp = head;
        
        while(temp -> next != NULL) {
            temp = temp -> next;
        }
        temp -> next = newNode;
        newNode -> prev = temp;
    }
    
    return head;
}


struct node* addNodeAtFront(struct node* head, int data) {
    struct node* newNode = createNode(data);
    
    if(head == NULL) {
        head = newNode;
    }
    else {
        newNode -> next = head;
        head -> prev = newNode;
        head = newNode;
    }
    
    return head;
}


void forwardPrint(struct node* temp) {
    if(temp == NULL) {
        printf("\nLinked list is empty\n");
        return;
    }
    
    printf("\nLinked list in Forward direction: \n");
    
    while(temp != NULL) {
        printf("%d --> ", temp -> data);
        temp = temp -> next;
    }
}

void reversePrint(struct node* temp) {
    if(temp == NULL) {
        printf("\nLinked list is empty\n");
        return;
    }
    
    printf("\nLinked list in backward direction: \n");
    
    while(temp -> next != NULL) {
        temp = temp -> next;
    }
    
    while(temp != NULL) {
        printf("%d --> ", temp -> data);
        temp = temp -> prev;
    }
}

int main()
{
    struct node* head = NULL;
    
    int ch, data;
    
    while(true) {
        
        printf("\n------------------------------------------ Menu -------------------------------------------");
        printf("\n1. Add node at the front \n2. Add node at the end \n3. Forward print \n4. Reverse print \n5. Exit\n");
        
        printf("\nEnter your choice: ");
        scanf("%d",&ch);
        
        switch(ch) {
            
            case 1:
                printf("\nEnter the data: ");
                scanf("%d", &data);
                head = addNodeAtFront(head, data);
                printf("\nNode with data = %d added to the front of the linked successfully", data);
                break;
                
            case 2:
                printf("\nEnter the data: ");
                scanf("%d", &data);
                head = addNodeAtEnd(head, data);
                printf("\nNode with data = %d added to the end of the linked successfully", data);
                break;
                
            case 3:
                forwardPrint(head);
                break;
                
            case 4:
                reversePrint(head);
                break;
                
            case 5:
                exit(0);
                
            default:
                printf("\nPlease enter valid choice");
        }
    }
    
    

    return 0;
}
