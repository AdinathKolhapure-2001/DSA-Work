#include <iostream>
#include <unistd.h>
using namespace std;

struct queue 
{
    private:
        int front;
        int rear;
        int size;
        int* arr;
    public: 
        queue(int);
        ~queue();
        void enqueue(int);
        void dequeue();
        int Front();
        int back();
        bool empty();
        bool full();
        void print();
};

queue :: queue(int size)
{
    this -> size = size;
    arr = new int[size];
    front = rear = -1;
}


queue :: ~ queue()
{
    delete[] arr;
}

void queue :: enqueue(int x)
{
    // check for full queue
    // check for empty queue
    // else case will be for partially filled
    
    if(full())
    {
        cout << "\nQueue is full" << endl;
        return;
    }
    else if(empty())
    {
        front++;
        rear++;
    }
    else
    {
        rear++; // (rear + 1 ) % size
    }
    arr[rear] = x;
}


void queue :: dequeue()
{
    // check for empty queue --> raise an error
    // if front == rear --> front = rear = -1 --> queue empty condition
    // front++;
    int temp;
    if(empty())
    {
        cout << "\nQueue is empty" << endl;
        return;
    }
    if(front == rear)
    {
        temp = arr[front];
        front = rear = -1;
    }
    else
    {
        temp = arr[front];
        front++;        // (front + 1) % size
    }
    cout << "\nDequeued element is " << temp << endl;
}


int queue :: Front()
{
    if(empty())
        return -1;
    return arr[front];
}


int queue :: back()
{
    if(empty())
        return -1;
    return arr[rear];
}


bool queue :: empty()
{
    return front == -1 && rear == -1;
}

bool queue :: full()
{
    return rear == size - 1;        // (rear + 1) == front
}


void queue :: print()
{
    if(empty())
    {
        cout << "\nQueue is empty" << endl;
        return;
    }
    for(int i = front; i <= rear; i++)
    {
        cout << arr[i] << " | ";
    }
    cout << "\n";
}

int main()
{
    // queue is a container with restriction, addtion of element should be done from one end(rear end)
    // and removal of element should be done from another end (front end)
    
    // Enqueue --> inserting the elements   --> O(1)
    // Dequeue --> removing the elements    --> O(1)
    // Front --> to check the front element
    // Back --> to check the last eelement
    // empty --> to check the queue is empty
    // fulll --> to check the queue is full
    // print --> for(int i = f; i <= R; i++)
    
    // n = 5;
    
    // Enqueue  --> 1> empty, 2> filled, 3> partially filled 
    // 
    //       f --> -1  | 10 | 20 | 30 | 40 |  |  <-- R
    //                  f               R
    
    // Dequeue --> 
    //          // empty    
    //              f --> -1  |  |  |  |  |  |  <-- R
    //                    Rf
     
    // arr[front], arr[rear]
    
    // empty --> f == -1 && R == -1 --> true  
    
    // full --> R == size - 1;
    
    int size, x, ch;
    
    cout << "Enter the size of the queue: ";
    
    cin >> size;
    
    queue q(size);
    
    while(true)
    {
        cout << "\n---------------------------------- Menu ----------------------------------" << endl;
        cout << "\n1. Enqueue\n2. Dequeue\n3. Front\n4. Back\n5. Print\n6. Exit" << endl;
        
        cout << "\nEnter your choice: ";
        cin >> ch;
        
        switch(ch)
        {
            case 1:
                cout << "\nEnter the element: ";
                cin >> x;
                q.enqueue(x);
                break;
                
            case 2:
                q.dequeue();
                break;
                
            case 3:
                x = q.Front();
                if(x != -1)
                {
                    cout << "\nFront element is  " << x << endl;
                }
                else
                {
                    cout << "\nQueue is empty" << endl;
                }
                break;
                
            case 4:
                x = q.back();
                if(x != -1)
                {
                    cout << "\nBack element is  " << x << endl;
                }
                else
                {
                    cout << "\nQueue is empty" << endl;
                }
                break;
                
            case 5:
                q.print();
                break;
                
            case 6:
                cout << "\nTerminating the program...." << endl;
                sleep(1);
                exit(0);
                
            default:
                cout << "\nEnter a valid choice" << endl;
        }
    }
    // enqueue --> O(1)
    // dequeue --> O(1)
    // size = 5 
    // | 20 | 30 | 40 | 50 | 50 |      // remove an elements --> O(n)
    //  f               R             // add an elements
    
    // 
    
    
    // queue full --> (rear + 1) % size == front;
    
    
    return 0;
}

