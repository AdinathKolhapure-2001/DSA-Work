#include <bits/stdc++.h>

using namespace std;

// problem link: https://www.geeksforgeeks.org/find-element-array-sum-left-array-equal-sum-right-array/
// Given, an array of size n. Find an element that divides the array into two sub-arrays with equal sums.
// Examples: 

// Input: 1 4 2 5
// Output: 2
// Explanation: If 2 is the partition, 
// subarrays are : {1, 4} and {5}

// Input: 2 3 4 1 4 5
// Output: 1
// Explanation: If 1 is the partition, 
//  Subarrays are : {2, 3, 4} and {4, 5}
 
// Input: 1 2 3
// Output: - 1
// Explanation: No sub-arrays possible. return -1

// Method 1 (Simple) 
// Consider every element starting from the second element. Compute the sum of elements on its left and 
// the sum of elements on its right. If these two sums are the same, return the element.
// Time complexity: O(n*n)
// space complexity: O(1)

int findElement1(vector<int> &nums) {
    int n = nums.size();
    for(int i = 1; i < n; i++) {
        int leftSum = 0;
        for(int j = i - 1; j >= 0; j--) {
            leftSum += nums[j];
        }
        int rightSum = 0;
        for(int k = i + 1; k < n; k++) {
            rightSum += nums[k];
        }
        if(leftSum == rightSum) {
            return nums[i];
        }
    }
    return -1;
}


// Method 2 (Using Prefix and Suffix Arrays): 

// We form a prefix and suffix sum arrays

// Given array: 1 4 2 5
// Prefix Sum:  1  5 7 12
// Suffix Sum:  12 11 7 5

// Now, we will traverse both prefix and Suffix array.
// The index at which they yield equal result,
// is the index where the array is partitioned 
// with equal sum.
// Time complexity: O(n)
// Space complexity: O(n)


int findElement2(vector<int> &nums) {
    int n = nums.size();
    vector<int> prefixSum(n);
    prefixSum[0] = nums[0];
    for(int i = 1; i < n; i++) {
        prefixSum[i] = prefixSum[i - 1] + nums[i];
    }
    vector<int> suffixSum(n);
    suffixSum[n - 1] = nums[n - 1];
    for(int i = n - 2; i >= 0; i--) {
        suffixSum[i] = suffixSum[i + 1] + nums[i];
    }
    
    for(int i = 1; i < n - 1; i++) {
        if(prefixSum[i] == suffixSum[i]) {
            return nums[i];
        }
    }
    return -1;
    
}



// Method 3 (Space efficient) 
// We calculate the sum of the whole array except the first element in right_sum, 
// considering it to be the partitioning element. Now, we traverse the array from left to right, 
// subtracting an element from right_sum and adding an element to left_sum. At the point where 
// right_sum equals left_sum, we get the partition.
// Time complexity: O(n)
// Space complexity: O(1)

int findElement3(vector<int> &nums) {
    int n = nums.size();
    int right_sum = 0;
    for(int i = 1; i < n; i++) {
        right_sum += nums[i];
    }
    int left_sum = 0;
    for(int i = 0, j = 1; j < n - 1; i++, j++) {
        right_sum -= nums[j];
        left_sum += nums[i];
        if(left_sum == right_sum) {
            return nums[i + 1];
        }
    }
    return -1;
}


int main()
{
    vector<int> nums = {2, 3, 4, 1, 4, 5};
    // int equilibriumPoint = findElement1(nums);
    // int equilibriumPoint = findElement2(nums);
    int equilibriumPoint = findElement3(nums);
    cout << "Equilibrium Point: " << equilibriumPoint << endl;

    return 0;
}

