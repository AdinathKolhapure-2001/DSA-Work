#include <bits/stdc++.h>

using namespace std;

// Trapping Rain Water
// Problem link: https://practice.geeksforgeeks.org/problems/trapping-rain-water-1587115621/1
// Given an array arr[] of N non-negative integers representing the height of blocks. If width of each block is 1, compute how much water can be trapped between the blocks during the rainy season. 
 
// Example 1:

// Input:
// N = 6
// arr[] = {3,0,0,2,0,4}
// Output: 10

// Example 2:

// Input:
// N = 4
// arr[] = {7,4,0,9}
// Output:
// 10
// Explanation:
// Water trapped by above 
// block of height 4 is 3 units and above 
// block of height 0 is 7 units. So, the 
// total unit of water trapped is 10 units.

// Example 3:

// Input:
// N = 3
// arr[] = {6,9,9}
// Output:
// 0
// Explanation:
// No water will be trapped.

// Anuj Bhaiya solution link: https://youtu.be/UZG3-vZlFM4
// Approach: use two array to store the max number from left and max number from right
// Now traverse both the arrays and calculate the trapped water by using following formula
// trappedWater = min(leftMax[i], rightMax[i]) - nums[i]
// add all the trapped water and return 

// Time complexity: O(n)
// Space complexity: O(n)

int maxWater1(vector<int>& nums) {
    int n = nums.size();
    int waterStored = 0, m1 = INT_MIN, m2 = INT_MIN;
    vector<int> leftMax(n);
    vector<int> rightMax(n);
    for(int i = 0, j = n - 1; i < n; i++, j--) {
        m1 = max(m1, nums[i]);
        leftMax[i] = m1;
        m2 = max(m2, nums[j]);
        rightMax[j] = m2;
    }
    
    for(int i = 0; i < n; i++) {
        waterStored += min(leftMax[i], rightMax[i]) - nums[i];
    }
    return waterStored;
}


// Better Approach:
// We dont need to store the left max and right max in the array 
// By doing that we can reduce the Space complexity to O(1)
// Algorithm:
// initialize l = 0 and r = n - 1
// leftMax = 0, rightMax = 0, waterStored = 0
// Traverse the array from front and back 
// while(l < r)
    // if arr[l] <= arr[r] then 
    //      if arr[l] > leftMax then 
    //          leftMax = arr[l]
    //      else 
    //          waterStored += leftMax - arr[l]
    //      l++
    // else
    //      if(arr[r] > rightMax)
    //          rightMax = arr[r]
    //      else
    //          waterStored += rightMax - arr[r]
    //      r--
//return waterStored

// Time complexity: O(n)
// Space complexity: O(1)

int maxWater2(vector<int>& nums) {
    int n = nums.size(), l = 0, r = n - 1;
    int waterStored = 0, leftMax = 0, rightMax = 0;
    while(l < r) {
        if(nums[l] <= nums[r]) {
            if(nums[l] > leftMax) {
                leftMax = nums[l];
            }
            else {
                waterStored += leftMax - nums[l];
            }
            l++;
        }
        else {
            if(nums[r] > rightMax) {
                rightMax = nums[r];
            }
            else {
                waterStored += rightMax - nums[r];
            }
            r--;
        }
    }
    return waterStored;
}



int main()
{
    vector<int> nums = {0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};
    int waterStored = maxWater2(nums);
    cout << waterStored << endl;

    return 0;
}
