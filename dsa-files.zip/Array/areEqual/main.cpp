#include <bits/stdc++.h>

using namespace std;

// Check if two arrays are equal or not
// Problem Link: https://www.geeksforgeeks.org/check-if-two-arrays-are-equal-or-not/
// Given two arrays, arr1 and arr2 of equal length N, the task is to find if the given arrays are equal or not. 

// Two arrays are said to be equal if:

// both of them contain the same set of elements, 
// arrangements (or permutations) of elements might/might not be same.
// If there are repetitions, then counts of repeated elements must also be the same for two arrays to be equal.
// Examples: 

// Input: arr1[] = {1, 2, 5, 4, 0}, arr2[] = {2, 4, 5, 0, 1}
// Output: Yes

// Input: arr1[] = {1, 2, 5, 4, 0, 2, 1}, arr2[] = {2, 4, 5, 0, 1, 1, 2} 
// Output: Yes

//  Input: arr1[] = {1, 7, 1}, arr2[] = {7, 7, 1}
// Output: No


// Approach 1 (Sorting): Follow the steps below to solve the problem using this approach:

// Sort both the arrays
// Then linearly compare elements of both the arrays
// If all are equal then return true, else return false
// Time Complexity: O(N log N) 
// Auxiliary Space: O(1)

bool areEqual1(vector<int>& nums1, vector<int>& nums2) {
    int n = nums1.size();
    sort(nums1.begin(), nums1.end());
    sort(nums2.begin(), nums2.end());
    for(int i = 0; i < n; i++) {
        if(nums1[i] != nums2[i]) {
            return false;
        }
    }
    return true;
}


// Approach 2 (hashing): An Efficient Solution to this approach is to use Hashing. 

// Store count of all elements of arr1[] in a hash table. Then traverse arr2[] and check if the count of every element in arr2[] matches with the count of elements of arr1[].

// Follow the steps mentioned below to implement the approach:

// First check if length of arr1 is not equal to the length of arr2 then return false
// Then traverse over first array and store the count of every element in the hash map
// Then traverse over second array and decrease the count of its elements in the hash map. If that element is not present or the count of that element is 
// zero in the hash map, then return false, else decrease the count of that element
// Return true at the end, as both the arrays are equal by now
// Time Complexity: O(N) 
// Auxiliary Space: O(N)

bool areEqual2(vector<int>& nums1, vector<int>& nums2) {
    int n = nums1.size();
    map<int, int> mp;
    for(int i = 0; i < n; i++) {
        mp[nums1[i]]++;
        mp[nums2[i]]--;
    }
    for(auto itr = mp.begin(); itr != mp.end(); itr++) {
        if(itr -> second) {
            return false;
        }
    }
    return true;
}

int main()
{
    vector<int> nums1 = {1, 2, 5, 4, 0, 2, 1}, nums2 = {2, 4, 5, 0, 1, 1, 2};
    bool check = areEqual2(nums1, nums2);
    if(check) {
        cout << "Yes" << endl;
    }
    else {
        cout << "No" << endl;
    }

    return 0;
}