#include <bits/stdc++.h>

using namespace std;

// Missing number in array
// Problem link: https://practice.geeksforgeeks.org/problems/missing-number-in-array1416/1
// Given an array of size N-1 such that it only contains distinct integers in the range of 1 to N. 
// Find the missing element.
// Example 1:

// Input:
// N = 5
// A[] = {1,2,3,5}
// Output: 4
// Example 2:

// Input:
// N = 10
// A[] = {6,1,2,8,3,4,7,10,5}
// Output: 9

// Expected Time Complexity: O(N)
// Expected Auxiliary Space: O(1)

// Method 1:
// Calculate the sum of the first N natural numbers as sumtotal= N*(N+1)/2.
// Traverse the array from start to end.
// Find the sum of all the array elements.
// Print the missing number as SumTotal – sum of array

int MissingNumber(vector<int>& array, int n) {
        int totalSum = n * (n + 1) / 2;
        int arraySum = 0;
        for(auto& num : array) {
            arraySum += num;
        }
        return totalSum - arraySum;
    }

int main()
{
    

    return 0;
}