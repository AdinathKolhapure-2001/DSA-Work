#include <bits/stdc++.h>

using namespace std;

// Problem link: https://www.geeksforgeeks.org/leaders-in-an-array/
// Write a program to print all the LEADERS in the array. An element is leader if it is greater than all the 
// elements to its right side. And the rightmost element is always a leader. For example in the array {16, 17, 4, 3, 5, 2}, 
// leaders are 17, 5 and 2. 

// Method 1:
// Use two loops. The outer loop runs from 0 to size – 1 and one by one picks all elements from left to right. 
// The inner loop compares the picked element to all the elements to its right side. If the picked element 
// is greater than all the elements to its right side, then the picked element is the leader.
// Time Complexity: O(n*n)

// Auxiliary Space: O(1)

vector<int> findLeaders1(vector<int> &nums) {
    int n = nums.size();
    vector<int> leaders;
    for(int i = 0; i < n; i++) {
        int j;
        for(j = i + 1; j < n; j++) {
            if(nums[i] <= nums[j]) {
                break;
            }
        }
        if(j == n) {
                leaders.push_back(nums[i]);
            }
    }
    return leaders;
}


// Method 2 (Scan from right) 
// Scan all the elements from right to left in an array and keep track of maximum till now. 
// // When maximum changes its value, print it.
// Time Complexity: O(n)
// Auxiliary Space: O(1)

vector<int> findLeaders2(vector<int> &nums) {
    int n = nums.size();
    vector<int> leaders;
    int max = INT_MIN;
    for(int i = n - 1; i >= 0; i--) {
        if(nums[i] >= max) {
            leaders.push_back(nums[i]);
            max = nums[i];
        }
    }
    return leaders;
}


// Method 3: 
// In method 2, we get time complexity O(n), but the output we get is not in the same order as the elements 
// appear in our input array, so to get out output in the same order as in the input array, we can use stack data structure.
// Time complexity: O(n)

// Auxiliary space: O(n)

stack<int> findLeaders3(vector<int> &nums) {
    int n = nums.size();
    stack<int> leaders;
    int max = INT_MIN;
    for(int i = n - 1; i >= 0; i--) {
        if(nums[i] >= max) {
            leaders.push(nums[i]);
            max = nums[i];
        }
    }
    return leaders;
}

int main()
{
    vector<int> nums = {16, 17, 4, 3, 5, 2};
    // vector<int> leaders = findLeaders1(nums);
    // vector<int> leaders = findLeaders2(nums);
    // for(auto leader : leaders) {
    //     cout << leader << " ";
    // }
    stack<int> leaders = findLeaders3(nums);
    while(!leaders.empty()) {
        cout << leaders.top() << " ";
        leaders.pop();
    }

    return 0;
}
