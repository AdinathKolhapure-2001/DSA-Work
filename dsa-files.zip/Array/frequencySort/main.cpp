#include <bits/stdc++.h>

using namespace std;

// Problem link: https://www.geeksforgeeks.org/sort-elements-by-frequency/
// Sort elements by frequency | Set 1
// Print the elements of an array in the decreasing frequency if 2 numbers 
// have same frequency then print the one which came first. 

// Examples:  
// Input:  arr[] = {2, 5, 2, 8, 5, 6, 8, 8}
// Output: arr[] = {8, 8, 8, 2, 2, 5, 5, 6}

// Input: arr[] = {2, 5, 2, 6, -1, 9999999, 5, 8, 8, 8}
// Output: arr[] = {8, 8, 8, 2, 2, 5, 5, 6, -1, 9999999}

// Approach :
// Make map that store's the element as the key and the pair of frequency and starting index as a value 
// sort the given array based on a condition 
// If the frequency of two elements is same then check the starting index place the element first who came first
// if the frequency are different then check for the element with higher frequency and place that element first 


vector<int> frequencySort(vector<int>& nums) {
    int n = nums.size();
    unordered_map<int, pair<int, int>> count; // unordered_map<key, pair<freq, idx>
    for (int i = 0; i < n; i++) {
        if(count.find(nums[i]) != count.end())
            count[nums[i]].first++;
        else 
            count[nums[i]] = {1, i};
    }
    // for(auto &itr : count) {
    //     cout << itr.first << "{ " << itr.second.first << ", " << itr.second.second << " }" << endl; 
    // }
    sort(nums.begin(), nums.end(), [&](int a, int b) {
        return count[a].first == count[b].first ? count[a].second < count[b].second : count[a].first > count[b].first;
    });
    return nums;
    }

int main()
{
    vector<int> nums = {2, 5, 2, 6, -1, 9999999, 5, 8, 8, 8};
    vector<int> sorted = frequencySort(nums);
    for(auto &num : sorted) {
        cout << num << " ";
    }



    return 0;
}
