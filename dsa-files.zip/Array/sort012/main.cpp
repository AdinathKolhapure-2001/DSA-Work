#include <bits/stdc++.h>

using namespace std;

// Problem link: https://www.geeksforgeeks.org/sort-an-array-of-0s-1s-and-2s/
// Given an array A[] consisting only 0s, 1s and 2s. The task is to write a function that sorts the given array. 
// The functions should put all 0s first, then all 1s and all 2s in last.
// Examples:

// Input: {0, 1, 2, 0, 1, 2}
// Output: {0, 0, 1, 1, 2, 2}

// Input: {0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1}
// Output: {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2}


// Method 1:
// a[1..Lo-1] zeroes (red)
// a[Lo..Mid-1] ones (white)
// a[Mid..Hi] unknown
// a[Hi+1..N] twos (blue)
// Algorithm: 
// 1. Keep three indices low = 1, mid = 1 and high = N and there are four ranges, 1 to low (the range containing 0), 
// low to mid (the range containing 1), mid to high (the range containing unknown elements) and high to N (the range containing 2).
// 2. Traverse the array from start to end and mid is less than high. (Loop counter is i)
// 3. If the element is 0 then swap the element with the element at index low and update low = low + 1 and mid = mid + 1
// 4. If the element is 1 then update mid = mid + 1
// 5. If the element is 2 then swap the element with the element at index high and update high = high – 1 and update i = i – 1. As the swapped element is not processed
// Time comlexity: O(n)
// Space complexity: O(1)

void sort012(vector<int> &nums) {
    int n = nums.size();
    int low = 0, mid = 0, high = n - 1;
    while(mid <= high) {
        switch(nums[mid]) {
            case 0:
            swap(nums[mid++], nums[low++]);
            break;
            case 1:
            mid++;
            break;
            case 2:
            swap(nums[mid], nums[high--]);
        }
    }
}


// Method 2:
// Approach: Count the number of 0s, 1s and 2s in the given array. 
// Then store all the 0s in the beginning followed by all the 1s then all the 2s.

// Algorithm: 
// 1. Keep three counter c0 to count 0s, c1 to count 1s and c2 to count 2s
// 2. Traverse through the array and increase the count of c0 if the element is 0,increase 
// the count of c1 if the element is 1 and increase the count of c2 if the element is 2
// 3. Now again traverse the array and replace first c0 elements with 0, next c1 elements with 1 and next c2 elements with 2.

void sort012_2(vector<int> &nums) {
    int n = nums.size();
    int cnt0 = 0, cnt1 = 0, cnt2 = 0;
    for(auto &num : nums) {
        if(num == 0) cnt0++;
        else if(num == 1) cnt1++;
        else cnt2++;
    }
    int i = 0;
    while(cnt0) {
        nums[i++] = 0;
        cnt0--;
    }
    while(cnt1) {
        nums[i++] = 1;
        cnt1--;
    }
    while(cnt2) {
        nums[i++] = 2;
        cnt2--;
    }
    
    
}

int main()
{
    vector<int> nums = {0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1};
    // sort012(nums);
    sort012_2(nums);
    for(auto &num : nums) {
        cout << num << " ";
    }

    return 0;
}