#include <bits/stdc++.h>

using namespace std;

// Problem link: https://www.geeksforgeeks.org/reverse-an-array-in-groups-of-given-size/
// Given an array, reverse every sub-array formed by consecutive k elements.

// Examples: 

// Input: 
// arr = [1, 2, 3, 4, 5, 6, 7, 8, 9] 
// k = 3 
// Output: 
// [3, 2, 1, 6, 5, 4, 9, 8, 7]

// Input: 
// arr = [1, 2, 3, 4, 5, 6, 7, 8] 
// k = 5 
// Output: 
// [5, 4, 3, 2, 1, 8, 7, 6]

// Input: 
// arr = [1, 2, 3, 4, 5, 6] 
// k = 1 
// Output: 
// [1, 2, 3, 4, 5, 6]

// Input: 
// arr = [1, 2, 3, 4, 5, 6, 7, 8] 
// k = 10 
// Output: 
// [8, 7, 6, 5, 4, 3, 2, 1] 


// Approach: Consider every sub-array of size k starting from the beginning of the array and reverse it. 
// We need to handle some special cases. If k is not multiple of n where n is the size of the array, for 
// the last group we will have less than k elements left, we need to reverse all remaining elements. If k = 1, 
// the array should remain unchanged. If k >= n, we reverse all elements present in the array.
// Time complexity: O(n). 
// Auxiliary space: O(1).

void reverseGroup(vector<int> &nums, int k) {
    int n = nums.size(), left, right;
    for(int i = 0; i < n; i+=k) {
        left = i;
        right = min(i + k - 1, n - 1);
        while(left < right) {
            swap(nums[left++], nums[right--]);
        }
    }
}



int main()
{
    vector<int> nums = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int k = 10;
    reverseGroup(nums, k);
    for(auto &num : nums) {
        cout << num << " ";
    } 
    

    return 0;
}