#include <bits/stdc++.h>

using namespace std;

// 215. Kth Largest Element in an Array
// Problem link: https://leetcode.com/problems/kth-largest-element-in-an-array/
// Given an integer array nums and an integer k, return the kth largest element in the array.

// Note that it is the kth largest element in the sorted order, not the kth distinct element.

// You must solve it in O(n) time complexity.

 

// Example 1:

// Input: nums = [3,2,1,5,6,4], k = 2
// Output: 5
// Example 2:

// Input: nums = [3,2,3,1,2,4,5,5,6], k = 4
// Output: 4
 

// Constraints:

// 1 <= k <= nums.length <= 105
// -104 <= nums[i] <= 104

// Approach : We can use an ordered map and map each element with its frequency. And as we know that 
// an ordered map would store the data in a sorted manner, we keep on adding the frequency of each 
// element from the end till it does not become greater than or equal to k so that we reach the k’th element from the end
// i.e. the k’th largest element.

int findKthLargest(vector<int>& nums, int k) {
        map<int, int> mp;
        for(auto& num : nums) {
            mp[num]++;
        }
        int freq = 0;
        for(auto itr = mp.rbegin(); itr != mp.rend(); itr++) {
            freq += itr -> second;
            if(freq >= k) {
                return itr -> first;
            }
        }
        return -1;
    }

int main()
{
    vector<int> nums = {3,2,3,1,2,4,5,5,6};
    int k = 4;
    cout << findKthLargest(nums, k);

    return 0;
}