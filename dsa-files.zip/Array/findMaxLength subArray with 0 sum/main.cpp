#include <bits/stdc++.h>

using namespace std;

// Problem Link: https://www.geeksforgeeks.org/find-the-largest-subarray-with-0-sum/

// Find the length of largest subarray with 0 sum
// Given an array arr[] of length N, find the length of the longest sub-array with a sum equal to 0.

// Examples: 

// Input: arr[] = {15, -2, 2, -8, 1, 7, 10, 23}
// Output: 5
// Explanation: The longest sub-array with elements summing up-to 0 is {-2, 2, -8, 1, 7}

// Input: arr[] = {1, 2, 3}
// Output: 0
// Explanation: There is no subarray with 0 sum

// Input:  arr[] = {1, 0, 3}
// Output:  1
// Explanation: The longest sub-array with elements summing up-to 0 is {0}


// Naive Approach: Follow the steps below to solve the problem using this approach:

// Consider all sub-arrays one by one and check the sum of every sub-array.
// If the sum of the current subarray is equal to zero then update the maximum length accordingly
// Below is the implementation of the above approach:
// Time Complexity: O(N2)
// Auxiliary Space: O(1)


int findMaxLength1(vector<int> &nums) {
    int n = nums.size();
    int maxLength = 0, s;
    for(int i = 0; i < n; i++) {
        s = nums[i];
        for(int j = i + 1; j < n; j++) {
            s += nums[j];
            if(s == 0) {
                maxLength = max(maxLength, (j-i)+1);
            }
        }
    }
    return maxLength;
    
}



// Efficient Approach 1 (Hash map):  Follow the below idea to solve the problem using this approach: 

// Create a variable sum and while traversing the input array, for every index add the value of the 
// element into the sum variable and then store the sum-index pair in a hash-map. So, if the same 
// value appears twice in the array, it will be guaranteed that the particular array will be a zero-sum sub-array. 

// Follow the steps mentioned below to implement the approach:

// Create a variable (sum), length (max_len), and a hash map (hm) to store the sum-index pair as a key-value pair.
// Traverse the input array and For every index, update the value of sum = sum + array[i].
// Check every index, if the current sum is present in the hash map or not.
// If present, update the value of max_len to a maximum difference of two indices (current index and index in the hash-map) and max_len.
// Else, put the value (sum) in the hash map, with the index as a key-value pair.
// Print the maximum length (max_len).

// Time Complexity: O(N)
// Auxiliary Space: O(N)


int findMaxLength2(vector<int> &nums) {
    int n = nums.size();
    int maxLength = 0, s = 0;
    unordered_map<int, int> mp;
    for(int i = 0; i < n; i++) {
        s += nums[i];
        if(s == 0) {
            maxLength = max(maxLength, i+1);
        }
        else if(mp.find(s) != mp.end()) {
            maxLength = max(maxLength, i - mp[s]);
        }
        else {
            mp[s] = i;
        }
    }
    return maxLength;
    
}



int main()
{
    vector<int> nums = {15, -2, 2, -8, 1, 7, 10, 23};
    int maxLength = findMaxLength2(nums);
    cout << maxLength;

    return 0;
}