#include <bits/stdc++.h>

using namespace std;
// Convert array into Zig-Zag fashion
// Problem Link: https://practice.geeksforgeeks.org/problems/convert-array-into-zig-zag-fashion1638/1
// Given an array Arr (distinct elements) of size N. Rearrange the elements of array in zig-zag fashion. 
// The converted array should be in form a < b > c < d > e < f. The relative order of elements is same in the 
// output i.e you have to iterate on the original array only.

// Example 1:

// Input:
// N = 7
// Arr[] = {4, 3, 7, 8, 6, 2, 1}
// Output: 3 7 4 8 2 6 1
// Explanation: 3 < 7 > 4 < 8 > 2 < 6 > 1
// Example 2:

// Input:
// N = 4
// Arr[] = {1, 4, 3, 2}
// Output: 1 4 2 3
// Explanation: 1 < 4 > 2 < 3
// Your Task:
// You don't need to read input or print anything. Your task is to complete the function zigZag() which takes the array of integers arr and n as parameters and returns void. You need to modify the array itself.
// NOTE: In the mentioned complexity, only a unique solution will exist.

// Expected Time Complexity: O(N)
// Expected Auxiliary Space: O(1)

// Constraints:
// 1 <= N <= 105
// 0 <= Arri <= 106

// Method 1: 
// The idea is to use a modified one pass of bubble sort.

// Maintain a flag for representing which order(i.e. < or >) currently we need.
// If the current two elements are not in that order then swap those elements otherwise not.
// Time complexity: O(n) 
// Auxiliary Space: O(1)

void convertZigZag(vector<int>& nums) {
    int n = nums.size();
    bool less = true;
    for(int i = 0, j = 1; j < n; i++, j++) {
        if((less && nums[i] > nums[j]) || (!less && nums[i] < nums[j])) {
            swap(nums[i], nums[j]);
        }
        less = !less;
    }
}

// Method 2:
// Since the relation needed is a<b>c<d>e<f, it means the odd position elements have to be greater than its adjacent 
// i.e. the even position elements. Simply traverse the array at the odd positions and check if it is greater than 
// its adjacent elements, if it is not then swap them.

void convertZigZag_2(vector<int>& nums) {
    int n = nums.size();
    for(int i = 1; i < n; i+=2) {
        if(nums[i - 1] > nums[i]) {
            swap(nums[i - 1], nums[i]);
        }
        if(i + 1 < n && nums[i + 1] > nums[i]) { 
            swap(nums[i + 1], nums[i]);
        }
    }
}

int main()
{
    vector<int> nums = {4, 3, 7, 8, 6, 2, 1};   // 3 7 4 8 2 6 1 
    // convertZigZag(nums);
    convertZigZag_2(nums);
    for(auto& num : nums) {
        cout << num << " ";
    }

    return 0;
}