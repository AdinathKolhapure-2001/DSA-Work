#include <bits/stdc++.h>

using namespace std;

// Problem Link : https://www.geeksforgeeks.org/sliding-window-maximum-maximum-of-all-subarrays-of-size-k/

// Sliding Window Maximum (Maximum of all subarrays of size k)
// Given an array and an integer K, find the maximum for each and every contiguous subarray of size k.

// Examples : 


// Input: arr[] = {1, 2, 3, 1, 4, 5, 2, 3, 6}, K = 3 
// Output: 3 3 4 5 5 5 6
// Explanation: 
// Maximum of 1, 2, 3 is 3
// Maximum of 2, 3, 1 is 3
// Maximum of 3, 1, 4 is 4
// Maximum of 1, 4, 5 is 5
// Maximum of 4, 5, 2 is 5 
// Maximum of 5, 2, 3 is 5
// Maximum of 2, 3, 6 is 6

// Input: arr[] = {8, 5, 10, 7, 9, 4, 15, 12, 90, 13}, K = 4 
// Output: 10 10 10 15 15 90 90
// Explanation:
// Maximum of first 4 elements is 10, similarly for next 4 
// elements (i.e from index 1 to 4) is 10, So the sequence 
// generated is 10 10 10 15 15 90 90


// Approach: 
// The idea is very basic run a nested loop, the outer loop which will mark the 
// starting point of the subarray of length k, the inner loop will run from the 
// starting index to index+k, k elements from starting index and print the maximum 
// element among these k elements. 

// Algorithm: 

// 1. Create a nested loop, the outer loop from starting index to n – k th elements. 
// The inner loop will run for k iterations.
// 2. Create a variable to store the maximum of k elements traversed by the inner loop.
// 3. Find the maximum of k elements traversed by the inner loop.
// 4. Print the maximum element in every iteration of outer loop
// ime Complexity: O(N * K). 
// The outer loop runs n-k+1 times and the inner loop runs k times for every iteration of outer loop. 
// So time complexity is O((n-k+1)*k) which can also be written as O(N * K).
// Space Complexity: O(1). 
// No extra space is required.

vector<int> max_of_subarrays1(vector<int> &nums, int k) {
        vector<int> ans;
        int maxElement, n = nums.size();
        for(int i = 0; i <= n - k; i++) {
            maxElement = nums[i];
            for(int j = i + 1; j < i + k; j++) {
                maxElement = max(maxElement, nums[j]);
            }
            ans.push_back(maxElement);
        }
        return ans;
    }


// Method 2 :
// Algorithm:  

// Create a deque to store k elements.
// 1. Run a loop and insert first k elements in the deque. Before inserting the element, 
// check if the element at the back of the queue is smaller than the current element, 
// if it is so remove the element from the back of the deque, until all elements left in 
// the deque are greater than the current element. Then insert the current element, at the back of the deque.
// 2. Now, run a loop from k to end of the array.
// 3. Print the front element of the deque.
// 4. Remove the element from the front of the queue if they are out of the current window.
// 5. Insert the next element in the deque. Before inserting the element, check if the element 
// at the back of the queue is smaller than the current element, if it is so remove the element 
// from the back of the deque, until all elements left in the deque are greater than the current element. 
// Then insert the current element, at the back of the deque.
// 6. Print the maximum element of the last window.

// Time Complexity: O(n). 
// It seems more than O(n) at first look. It can be observed that every element of array is added and removed 
// at most once. So there are total 2n operations.
// Auxiliary Space: O(k). 
// Elements stored in the dequeue take O(k) space.

vector<int> max_of_subarrays2(vector<int> &nums, int k) {
        deque<int> dq;
        vector<int> ans;
        int i, n = nums.size();
        for(i = 0; i < k; i++) {
            while(!dq.empty() && nums[dq.back()] <= nums[i]) dq.pop_back();
            dq.push_back(i);
        }
        ans.push_back(nums[dq.front()]);
        for(; i < n; i++) {
            if(!dq.empty() && dq.front() <= i - k) dq.pop_front();
            while(!dq.empty() && nums[dq.back()] <= nums[i]) dq.pop_back();
            dq.push_back(i);
            ans.push_back(nums[dq.front()]);
        }
        return ans;
    }

int main()
{
    vector<int> nums = {8, 5, 10, 7, 9, 4, 15, 12, 90, 13};
    int k = 4;
    
    vector<int> ans = max_of_subarrays1(nums, k);
    
    for(const auto &num : ans) 
        cout << num << " ";
    
    return 0;
}