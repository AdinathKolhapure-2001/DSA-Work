#include <bits/stdc++.h>

using namespace std;

// Rearrange an array in maximum minimum form
// // Problem link: https://www.geeksforgeeks.org/rearrange-array-maximum-minimum-form/
// Given a sorted array of positive integers, rearrange the array alternately i.e first element should be maximum value, 
// second minimum value, third second max, fourth second min and so on. 

// Input: arr[] = {1, 2, 3, 4, 5, 6, 7} 
// Output: arr[] = {7, 1, 6, 2, 5, 3, 4}

// Input: arr[] = {1, 2, 3, 4, 5, 6} 
// Output: arr[] = {6, 1, 5, 2, 4, 3} 

// Method 1:
// The idea is to use an auxiliary array. We maintain two pointers one to leftmost or smallest element and other to 
// rightmost or largest element. We move both pointers toward each other and alternatively copy elements at these 
// pointers to an auxiliary array. Finally, we copy the auxiliary array back to the original array.
// Tme complexity: O(n)
// Space complexity: O(n)

vector<int> rearrange(vector<int> nums) {
    int n = nums.size();
    vector<int> res(n);
    for(int i = 0, j = n - 1, k = 0; i <= j; i++, j--) {
        res[k++] = nums[j];
        if(k < n)
            res[k++] = nums[i];
    }
    return res;
}

int main()
{
    vector<int> nums = {1, 2, 3, 4, 5, 6, 7};
    vector<int> res = rearrange(nums);
    for(auto& num : res) {
        cout << num << " ";
    }

    return 0;
}