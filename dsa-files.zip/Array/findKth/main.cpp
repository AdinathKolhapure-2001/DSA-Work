#include <bits/stdc++.h>

using namespace std;

// K-th Element of Two Sorted Arrays
// Problem link: https://www.geeksforgeeks.org/k-th-element-two-sorted-arrays/
// Given two sorted arrays of size m and n respectively, you are tasked with finding the element that would be at the k’th position of the final sorted array.

// Examples: 

// Input : Array 1 - 2 3 6 7 9
//         Array 2 - 1 4 8 10
//         k = 5
// Output : 6
// Explanation: The final sorted array would be -
// 1, 2, 3, 4, 6, 7, 8, 9, 10
// The 5th element of this array is 6.

// Input : Array 1 - 100 112 256 349 770
//         Array 2 - 72 86 113 119 265 445 892
//         k = 7
// Output : 256
// Explanation: Final sorted array is -
// 72, 86, 100, 112, 113, 119, 256, 265, 349, 445, 770, 892
// 7th element of this array is 256.


// Basic Approach 
// Since we are given two sorted arrays, we can use the merging technique to get the final merged array. 
// From this, we simply go to the k’th index. 

// Time Complexity: O(n) 
// Auxiliary Space : O(m + n) 

int findKth1(vector<int>& nums1, vector<int>& nums2, int k_req) {
    int m = nums1.size(), n = nums2.size();
    vector<int> v(m + n);
    int i, j, k;
    for(i = 0, j = 0, k = 0; i < m && j < n; k++) {
        if(nums1[i] < nums2[j]) {
            v[k] = nums1[i++];
        }
        else {
            v[k] = nums2[j++];
        }
    }
    while(i < m) {
        v[k++] = nums1[i++];
    }
    while(j < n) {
        v[k++] = nums2[j++];
    }
    return v[k_req - 1];
}


// Space Optimized Version of above approach: We can avoid the use of extra array.
// Time Complexity: O(k) 
// Auxiliary Space: O(1)

int findKth2(vector<int>& nums1, vector<int>& nums2, int k_req) {
    int m = nums1.size(), n = nums2.size();
    int i, j, k;
    for(i = 0, j = 0, k = 0; i < m && j < n;) {
        if(nums1[i] < nums2[j]) {
            k++;
            if(k == k_req) {
                return nums1[i];
            }
            i++;
        }
        else {
            k++;
            if(k == k_req) {
                return nums2[j];
            }
            j++;
        }
    }
    while(i < m) {
        k++;
        if(k == k_req) {
            return nums1[i];
        }
        i++;
    }
    while(j < n) {
        k++;
        if(k == k_req) {
            return nums2[j];
        }
        j++;
    }
    return -1;
}

int main()
{
    vector<int> nums1 = {2, 3, 6, 7, 9}, nums2 = {1, 4, 8, 10};
    int k_req = 5;
    int kthElement = findKth2(nums1, nums2, k_req);
    cout << kthElement << endl;
    
    return 0;
}
