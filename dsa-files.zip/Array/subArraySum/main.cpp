#include <bits/stdc++.h>

using namespace std;

// Problem link: https://www.geeksforgeeks.org/find-subarray-with-given-sum/
// Find subarray with given sum
// Simple Approach: A simple solution is to consider all subarrays one by one and check the sum of every subarray. 
// Following program implements the simple solution. 
// Run two loops: the outer loop picks a starting point I and the inner loop tries all subarrays starting from i.

// Algorithm:  

// Traverse the array from start to end.
// From every index start another loop from i to the end of array to get all subarray starting from i, keep a variable sum to calculate the sum.
// For every index in inner loop update sum = sum + array[j]
// If the sum is equal to the given sum then print the subarray.

// Time Complexity: O(n^2) in worst case. 
// Nested loop is used to traverse the array so the time complexity is O(n^2)
// Space Complexity: O(1). 
// As constant extra space is required.

pair<int, int> subArraySum1(vector<int> nums, int sum) {
    int n = nums.size(), currSum;
    pair<int, int> res = {-1, -1};
    for(int i = 0; i < n; i++) {
        currSum = nums[i];
        for(int j = i + 1; j <= n; j++) {
            if(currSum == sum) {
                res = {i, j-1};
                return res;
            }
            if(currSum > sum || j == n)
                break;
            currSum += nums[j];
        }
    }
    return res;
}


// Efficient Approach: 
// There is an idea if all the elements of the array are positive. 
// If a subarray has sum greater than the given sum then there is no possibility that adding elements 
// to the current subarray the sum will be x (given sum). Idea is to use a similar approach to a sliding window. 
// Start with an empty subarray, add elements to the subarray until the sum is less than x. If the sum is 
// greater than x, remove elements from the start of the current subarray.
// Algorithm:  

// Create two variables, l=0, sum = 0
// Traverse the array from start to end.
// Update the variable sum by adding current element, sum = sum + array[i]
// If the sum is greater than the given sum, update the variable sum as sum = sum – array[l], and update l as, l++.
// If the sum is equal to given sum, print the subarray and break the loop.

vector<int> subArraySum2(vector<int> nums, int sum) {
    int n = nums.size(), currSum = nums[0], start = 0;
    vector<int> res = {-1};
    for(int i = 1; i <= n; i++) {
        while(currSum > sum && start < i - 1) {
            currSum -= nums[start++];
        }
        if(currSum == sum) {
            res = {start + 1, i};
            break;
        }
        else if(i < n)
            currSum += nums[i];
    }
    return res;
}


int main()
{
    vector<int> nums = {1, 4, 0, 0, 3, 10, 5};
    int sum = 7;
    vector<int> res = subArraySum2(nums, sum);
    for(auto num : res) {
        cout << num << " ";
    }

    return 0;
}