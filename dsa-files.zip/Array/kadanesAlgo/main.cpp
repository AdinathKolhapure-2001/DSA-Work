#include <bits/stdc++.h>

using namespace std;

// Problem link: https://www.geeksforgeeks.org/largest-sum-contiguous-subarray/

// Largest Sum Contiguous Subarray
// Write an efficient program to find the sum of the contiguous subarray within a one-dimensional 
// array of numbers that has the largest sum. 

// Kadane’s Algorithm:

// Initialize:
//     max_so_far = INT_MIN
//     max_ending_here = 0

// Loop for each element of the array
//   (a) max_ending_here = max_ending_here + a[i]
//   (b) if(max_so_far < max_ending_here)
//             max_so_far = max_ending_here
//   (c) if(max_ending_here < 0)
//             max_ending_here = 0
// return max_so_far

// Explanation: 
// The simple idea of Kadane’s algorithm is to look for all positive contiguous segments of 
// the array (max_ending_here is used for this). And keep track of the maximum sum contiguous 
// segment among all positive segments (max_so_far is used for this). Each time we get a positive-sum 
// compare it with max_so_far and update max_so_far if it is greater than max_so_far 
// Time Complexity: O(n)
// Auxiliary Space: O(1)

// Note: The above algorithm only works if and only if at least one positive number should be 
// present otherwise it does not work i.e if an Array contains all negative numbers it doesn’t work.

int maxSubArraySum(vector<int>& nums) {
    int n = nums.size();
    int start = 0, end = 0, s = 0;
    int maxSum = 0;
    int maxTill = 0;
    for(int i = 0; i < n; i++) {
        maxTill += nums[i];
        if(maxTill > maxSum) {
            maxSum = maxTill;
            start = s;
            end = i;
        }
        if(maxTill < 0) {
            maxTill = 0;
            s = i + 1;
        }
    }
    cout << start << " " << end << endl;
    return maxSum;
}

int main()
{
    vector<int> nums = {-2, -3, 4, -1, -2, 1, 5, -3};
    int maxSum = maxSubArraySum(nums);
    cout << maxSum << endl;

    return 0;
}