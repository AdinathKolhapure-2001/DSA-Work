#include <bits/stdc++.h>

using namespace std;

// Problem link: https://www.geeksforgeeks.org/counting-inversions/

// Count Inversions in an array | Set 1 (Using Merge Sort)

// Inversion Count for an array indicates – how far (or close) the array is from being sorted. 
// If the array is already sorted, then the inversion count is 0, but if the array is sorted in 
// the reverse order, the inversion count is the maximum. 

// Formally speaking, two elements a[i] and a[j] form an inversion if a[i] > a[j] and i < j

// Example: 

// Input: arr[] = {8, 4, 2, 1}
// Output: 6

// Explanation: Given array has six inversions:
// (8, 4), (4, 2), (8, 2), (8, 1), (4, 1), (2, 1).


// Input: arr[] = {3, 1, 2}
// Output: 2

// Explanation: Given array has two inversions:
// (3, 1), (3, 2) 

// METHOD 1 (Simple)  

// Approach: Traverse through the array, and for every index, find the number of smaller 
// elements on its right side of the array. This can be done using a nested loop. Sum up 
// the counts for all index in the array and print the sum.
// Algorithm: 
// Traverse through the array from start to end
// For every element, find the count of elements smaller than the current number up to that index using another loop.
// Sum up the count of inversion for every index.
// // Print the count of inversions. 
// Time Complexity: O(n^2), Two nested loops are needed to traverse the array from start to end, so the Time complexity is O(n^2)
// Space Complexity:O(1), No extra space is required.

int getInvCount1(vector<int>& nums) {
    int n = nums.size(), invCount = 0;
    for(int i = 0; i < n - 1; i++) {
        for(int j = i + 1; j < n; j++) {
            if(nums[j] < nums[i])
                invCount++;
        }
    }
    return invCount;
}


// METHOD 2(Enhance Merge Sort) 
// Algorithm: 
// 1. The idea is similar to merge sort, divide the array into two equal or almost equal 
// halves in each step until the base case is reached.
// 2. Create a function merge that counts the number of inversions when two halves of the 
// array are merged, create two indices i and j, i is the index for the first half, and j 
// is an index of the second half. if a[i] is greater than a[j], then there are (mid – i) inversions. 
// because left and right subarrays are sorted, so all the remaining elements in left-subarray 
// (a[i+1], a[i+2] … a[mid]) will be greater than a[j].
// 3. Create a recursive function to divide the array into halves and find the answer by summing 
// the number of inversions is the first half, the number of inversion in the second half and the 
// number of inversions by merging the two.
// 4. The base case of recursion is when there is only one element in the given half.

// Time Complexity: O(n log n), The algorithm used is divide and conquer, So in each level, 
// one full array traversal is needed, and there are log n levels, so the time complexity is O(n log n).
// Space Complexity: O(n), Temporary array.

int merge(vector<int>& nums, int low, int mid, int high) {
    int invCount = 0;
    int n = high - low + 1;
    vector<int> temp(n);
    int i = low, j = mid + 1, k = 0;
    while(i <= mid && j <= high) {
        if(nums[i] <= nums[j])
            temp[k++] = nums[i++];
        else {
            temp[k++] = nums[j++];
            invCount += (mid - i + 1);
        }
    }
    while(i <= mid) 
        temp[k++] = nums[i++];
    while(j <= high)
        temp[k++] = nums[j++];
    for(int i = low, j = 0; i <= high; i++, j++) {
        nums[i] = temp[j];
    }
    return invCount;
}

int mergeSort(vector<int>& nums, int low, int high) {
    int mid, invCount = 0;
    if(low < high) {
        mid = low + (high - low) / 2;
        invCount += mergeSort(nums, low, mid);
        invCount += mergeSort(nums, mid + 1, high);
        invCount += merge(nums, low, mid, high);
    }
    return invCount;
}

int getInvCount2(vector<int>& nums) {
    return mergeSort(nums, 0, nums.size() - 1);
}

int main()
{
    vector<int> nums = {2, 4, 1, 3, 5};
    // int invCount = getInvCount1(nums);
    int invCount = getInvCount2(nums);
    cout << invCount;
    
    return 0;
}