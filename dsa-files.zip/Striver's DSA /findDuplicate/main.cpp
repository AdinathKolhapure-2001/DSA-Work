#include <bits/stdc++.h>

using namespace std;

// 287. Find the Duplicate Number

// link : https://leetcode.com/problems/find-the-duplicate-number/

// solution link : https://www.youtube.com/watch?v=32Ll35mhWg0&list=PLgUwDviBIf0rPG3Ictpu74YWBQ1CaBkm2&index=1&ab_channel=takeUforward

// Given an array of integers nums containing n + 1 integers where each integer is in the range [1, n] inclusive.

// There is only one repeated number in nums, return this repeated number.

// You must solve the problem without modifying the array nums and uses only constant extra space.

 

// Example 1:

// Input: nums = [1,3,4,2,2]
// Output: 2
// Example 2:

// Input: nums = [3,1,3,4,2]
// Output: 3
 

// Constraints:

// 1 <= n <= 105
// nums.length == n + 1
// 1 <= nums[i] <= n
// All the integers in nums appear only once except for precisely one integer which appears two or more times.
 

// Follow up:

// How can we prove that at least one duplicate number must exist in nums?
// Can you solve the problem in linear runtime complexity?


// Approach 1: Brute force 
// algorithm : 
// initialize idx variable to 0 
// sort the given array and check the consecutive numbers 
// return the number which is repeating 

// Time complexity : O(nlogn)
// space complexity : O(1)

int findDuplicate1(vector<int> &nums) {
    int n = nums.size(), duplicate;
    sort(nums.begin(), nums.end());
    for(int i = 0; i < n - 1; i++) {
        if(nums[i] == nums[i + 1]) {
            duplicate = nums[i];
            break;
        }
    }
    return duplicate;
}


// Approach 2: Use either frequency vector or hashmap 
// algorithm : 
// create a frequency vector of size n
// traverse teh array and count the frequency of every element 
// travers the array again from 1 index (as 0 is not present) and
// return the index whose frequency is more than 1

// Time complexity : O(n)
// space complexity : O(n)

int findDuplicate2(vector<int> &nums) {
    int n = nums.size(), duplicate;
    vector<int> freq(n, 0);
    for(int i = 0; i < n; i++) {
        freq[nums[i]]++;
    }
    for(int i = 1; i < n; i++) {
        if(freq[i] > 1) {
            duplicate = i;
            break;
        }
    }
    return duplicate;
}


// Approach 3: Using cycle sort 
// algorithm : 
// sort the array using cycle sort 
// the first number wich is not at its correct place will be the duplicate number 
// return the duplicate number 

// Time complexity : O(n)
// space complexity : O(1)

int findDuplicate3(vector<int> &nums) {
    int n = nums.size(), i = 0, duplicate;
    while(i < n) {  
        if(nums[i] != i + 1 && nums[i] != nums[nums[i] - 1]) {
            swap(nums[i], nums[nums[i] - 1]);
        }
        else {
            i++;
        }
    }
    for(int i = 0; i < n; i++) {
        if(nums[i] != i + 1) {
            duplicate = nums[i];
            break;
        }
    }
    // for(auto num : nums) 
    //     cout << num << " ";
    // cout << "\n";
    return duplicate;
}


// Approach 4: using binary search on range 1 -> n 
// algorithm :
// declare low = 1, high = n and mid
// find the mid
// count the number of elements that are less or equal to mid
// if the count is less or equal to mid then move low to mid + 1 
// if count is greater than mid then move high to mid - 1
// return low

// time complexity : O(nlogn), n for counting numbers less than or equal to mid and logn for binary search
// space complexity : O(1)

// intuition behind this algorithm : 
// lets say the number k is repeating more than once the range would be like 1, 2, .... k - 1, k, k + 1, ....., n - 1, n 
// we will find the mid off this range if the k is greater than mid it will lie on right side of the range 
// therefore the count of numbers that are less or equal to mid would be less or eqaul to mid 
// if the count of numbers that are less or equal to mid is greater than mid it means there are some additional numbers present
// on the left of mid that are repeating hence move high to mid - 1 to search on left side of mid 

int findDuplicate4(vector<int> &nums) {
    int n = nums.size(), low = 1, high = n - 1, mid;
    while(low <= high) {
        mid = (low + high) >> 1;
        int cnt = 0;
        for(int num : nums) {
            if(num <= mid) {
                cnt++;
            }
        }
        if(cnt <= mid) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }
    return low;
}



// Approach 5 : Linked list cycle method

// algorithm : 
// declare slow and fast pointers to 0 
// move slow by one position and fast by two position 
// when they becomes equal break from the loop 
// initialize slow to 0 and move slow and fast by one 
// where they collied that will be the repeating number

// Time complexity : O(n)
// space complexity : O(1)

int findDuplicate5(vector<int> &nums) {
    int slow = nums[0], fast = nums[0];
    do {
        slow = nums[slow];
        fast = nums[nums[fast]];
    }
    while(slow != fast);
    slow = nums[0];
    while(slow != fast) {
        slow = nums[slow];
        fast = nums[fast];
    }
    return slow;
}

int main()
{
    vector<int> nums = {2, 5, 9, 6, 9, 3, 8, 9, 7, 1};
    
    int duplicate;
    
    // duplicate = findDuplicate1(nums);
    // duplicate = findDuplicate2(nums);
    // duplicate = findDuplicate3(nums);
    // duplicate = findDuplicate4(nums);
    duplicate = findDuplicate5(nums);
    
    cout << duplicate;

    
    return 0;
}
