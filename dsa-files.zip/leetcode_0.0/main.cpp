#include<bits/stdc++.h>

using namespace std;

// leetcode 1108:
string defangIPaddr(string address) {
        int n = address.length();
        string newString = "";
        for(int i = 0; i < n; i++) {
            if(address[i] == '.') {
                newString += "[.]";
            }
            else {
                newString += address[i];
            }
        }
        return newString;
    }

// leetcode 1672:
int maximumWealth(vector<vector<int>>& accounts) {
        int maxWealth = 0;
        int currWealth;
        for(const auto& itr1 : accounts) {
            currWealth = 0;
            for(const auto& itr2 : itr1) {
                currWealth += itr2;
            }
            maxWealth = max(maxWealth, currWealth);
        } 
        return maxWealth;
    }
    
// leetcode 1470:
vector<int> shuffle(vector<int>& nums, int n) {
        int size = 2 * n, j = 0;
        vector<int> output(size);
       
        for(int i = 0; i < size; i += 2) {
            output[i] = nums[j];
            output[i + 1] = nums[j + n];
            j++;
        }
        return output;
    }
    
// leetcode 1431:
 vector<bool> kidsWithCandies(vector<int>& candies, int extraCandies) {
        int maxCandies = *max_element(candies.begin(), candies.end());
        int n = candies.size();
        vector<bool> result(n);
        for(int i = 0; i < n; i++) {
            if(candies[i] + extraCandies >= maxCandies) {
                result[i] = true;
            }
            else {
                result[i] = false;
            }
        }
        return result;
    }
    

// leetcode 771:
int numJewelsInStones(string jewels, string stones) {
        int m = jewels.length();
        int n = stones.length();
        int numberOfJewels = 0;
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                if(jewels[i] == stones[j]) {
                    numberOfJewels++;
                }
            }
        }
        return numberOfJewels;
    }
    


int main()
{
    // string address =  "255.100.50.0";
    
    // cout << defangIPaddr(address);
    
    // vector<vector<int>> accounts = {{2,8,7},{7,1,3},{1,9,5}};
    
    // cout << maximumWealth(accounts);
    
    // vector<int> nums = {1,2,3,4,4,3,2,1}; int n = 4;
    
    // nums = shuffle(nums, n);
    
    // for(int i : nums) cout << i << " ";

    
    // vector<int> candies = {4,2,1,1,2}; int extraCandies = 1;
    
    // vector<bool> result = kidsWithCandies(candies, extraCandies);
    
    // for(bool i : result) cout << i << " ";
    
    
    
    // string jewels = "aA", stones = "aAAbbbb";
    // cout << numJewelsInStones(jewels, stones);
    
    
    
    
    return 0;
}
