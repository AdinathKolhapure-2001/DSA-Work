#include <bits/stdc++.h> 
using namespace std;

// Leetcode 2090. K Radius Subarray Averages

// This is brute force approach, it will give TLE

// vector<int> getAverages(vector<int>& nums, int k) {
//     vector<int> avgs;
//     int sum;
//     for(int i = 0; i < nums.size(); i++)
//     {
//         if(((i - k) >= 0) && ((i + k < nums.size())))
//         {
//             sum = 0;
//             for(int j = i - k; j <= i + k; j++)
//             {
//                 sum += nums[j];
//             }
//             avgs.push_back(sum / (2*k + 1));
//         }
//         else
//         {
//             avgs.push_back(-1);
//             cout << "avgs[" << i << "] = " << avgs[i] << endl;
//         }
//     }
    
//     return avgs;
// }

// Two optimise solutions

// Sliding window technique

// vector<int> getAverages(vector<int>& A, int k) {
//     long N = A.size(), len = 2 * k + 1, sum = 0; // `len` is the length of the window
//     vector<int> ans(N, -1);
//     if (N < len) return ans; // If the array is too short to cover a window, return all -1s
//     for (int i = 0; i < N; ++i) {   // 8
//         sum += A[i]; // push A[i] into the window   // 3 + 9 + 1 + 8 + 5 + 2 + 6
//         if (i - len >= 0) sum -= A[i - len]; // pop A[i-len], if any, out of window
//         if (i >= len - 1) ans[i - k] = sum / len; // the center of this window is at `i-k`
//     }
//     return ans;
//     }


// Prefix sum approach

// vector<int> getAverages(vector<int>& A, int k) {
//     int N = A.size(), len = 2 * k + 1;
//     vector<int> ans(N, -1);
//     if (N < len) return ans; // If the array is too short to cover a window, return all -1s
//     vector<long> sum(N + 1);
//     for (int i = 0; i < N; ++i) sum[i + 1] = sum[i] + A[i]; // 0 7 11 14 23 24 32 37 39 45 
//     for (int i = k; i + k < N; ++i) ans[i] = (sum[i + k + 1] - sum[i - k]) / len;
//     return ans;
// }
    
    
int main()
{

    vector<int> nums = {7,4,3,9,1,8,5,2,6};
    int k = 3;

    vector<int> avgs = getAverages(nums, k);

    for(int i : avgs)  
    {
        cout << i << " "; 
    }
    
    
}
