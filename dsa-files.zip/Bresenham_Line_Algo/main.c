#include <stdio.h>
#include <stdlib.h>


void Bres_Line(int x1,int y1, int x2, int y2)
{
    int dx,dy;
    int xa,ya,xb,yb;

    dx=x2-x1;
    dy=y2-y1;



    if (dx>0)
    {
        xa=x1;
        ya=y1;
        xb=x2;
    }
    else
    {
        xa=x2;
        ya=y2;
        xb=x1;
    }

    int d=2*abs(dy)-abs(dx);
    int increment1=2*abs(dy);
    int increment2=2*abs(dy)-2*abs(dx);

    printf("xa\tya\td\n");
    printf("%d\t%d\t%d\n",xa,ya,d);

    while (xb>xa)
    {
        if (d<0)
        {
            xa=xa+1;
            d=d+increment1;
        }
        else
        {
            xa=xa+1;
            if((dx>0&&dy>0)||(dx<0&&dy<0))
            {
                ya=ya+1;
            }
            else
            {
                ya=ya-1;
            }
            d=d+increment2;
        }
        printf("%d\t%d\t%d\n",xa,ya,d);
    }

}
int main()
{
    int xa,ya,xb,yb;

    printf("\nEnter the First Point:");
    scanf("%d%d",&xa,&ya);

    printf("\nEnter the Second Point:");
    scanf("%d%d",&xb,&yb);

    int dx=xb-xa;
    int dy=yb-ya;

    if(abs(dx)>abs(dy))
    {
        Bres_Line(xa,ya,xb,yb);
    }
    else
    {
        Bres_Line(ya,xa,yb,xb);
    }
    return 0;
}
