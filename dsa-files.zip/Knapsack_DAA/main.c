
/* knapsack problem (greedy algorithm) -->
Select such objects whose sum of weight equal to capacity
of knapsack and profit should be maximum */


#include <stdio.h>


struct knapsack                     // Structure
{
    float weight;
    float profit;
    float ratio;
};

static float capacity;              // Static variables
static float Total_profit;

void accept(struct knapsack s[], int n)             // function to accept the weight and the profit of the object
{
     for(int i = 0; i<n; i++)
    {
        printf("\nEnter the weight of object %d: ",i+1);
        scanf("%f",&s[i].weight);
        printf("\nEnter the profit of object %d: ",i+1);
        scanf("%f",&s[i].profit);
    }
}


void cal_ratio(struct knapsack s[],int n)           // function to calculate the profit to weight ratio of each object
{
    for(int i = 0; i<n; i++)
    {
        s[i].ratio = s[i].profit/s[i].weight;
    }
}


void sort_ratio(struct knapsack s[],int n)          // function to sort(in descending order) the objects according to their ratio
{
    int flag;
    for(int i = 0; i<n-1; i++)
    {   flag = 0;
        for(int j = 0; j<n-i-1;j++)
        {
            if(s[j].ratio<s[j+1].ratio)
            {
                struct knapsack temp = s[j];
                s[j] = s[j+1];
                s[j+1] = temp;
                flag = 1;
            }
        }
        if(flag == 0)
            break;
    }
}


void display(struct knapsack s[], int i)                // function to display values
{
    printf("\n%.2f\t%.2f\t%.2f\t%.2f",s[i].weight,s[i].profit,s[i].ratio,capacity);
}


void Knap_sack(struct knapsack s[],int n)           // knapsack function to maximize the profit
{
    for(int i = 0; i<n; i++)
    {
        if(capacity <= 0)
        {
            break;
        }
        if(capacity < s[i].weight)              // fractional knapsack case
        {
            float temp = ((capacity/s[i].weight)*s[i].profit);
            Total_profit += temp;
            printf("\n%.2f\t%.2f\t%.2f\t%.2f",capacity,temp,s[i].ratio,0.00);
            capacity -= capacity;
            break;
        }
        display(s,i);
        capacity -= s[i].weight;
        Total_profit += s[i].profit;
    }
    printf("\n\nTotal profit is: %.2f",Total_profit);
}


int main()
{
    
    int n;
    printf("\nEnter the capacity: ");
    scanf("%f",&capacity);
    
    printf("\nEnter the number of objects: ");
    scanf("%d",&n);
    
    struct knapsack s[n];
    
    accept(s,n);
    
    cal_ratio(s,n);
    
    sort_ratio(s,n);
    
    printf("\nKnapsack contains:\n");
    printf("\nWeight\tProfit\tRatio\tCapacity");

    Knap_sack(s,n);


    return 0;
}


