#include <bits/stdc++.h>

using namespace std;


bool isSafe(vector<vector<int>>& arr, int x, int y, int n) {
    for(int row = 0; row < x; row++) {  // check column wise
        if(arr[row][y] == 1) {
            return false;
        }
    }
    
    int row = x;
    int col = y;
    
    while(row >= 0 && col >= 0) {   // upper left digonal
        if(arr[row][col] == 1) {
            return false;
        }
        row--;
        col--;
    }
    
    row = x;
    col = y;
    
    while(row >= 0 && col < n) {    // upper right digonal
        if(arr[row][col] == 1) {
            return false;
        }
        row--;
        col++;
    }
    
    return true;
}


bool nQueen(vector<vector<int>>& arr, int x, int n) {
    if(x >= n) {        // all queens are placed
        return true;
    }
    
    for(int col = 0; col < n; col++) {  // check whether queen is safe in x row and in every column
        if(isSafe(arr, x, col, n)) {
            arr[x][col] = 1;
            
            if(nQueen(arr, x + 1, n)) {
                return true;
            }
            arr[x][col] = 0;    // backtracking
        }
    }
    return false;
}

int main()
{
    int row = 4, col = 4;
    vector<vector<int>> arr (row, vector<int> (col, 0));
    
    
    if(nQueen(arr, 0, row)){
        for(int i = 0; i < row; i++) {
            for(int j = 0; j < col; j++) {
                cout << arr[i][j] << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
