#include <bits/stdc++.h>

using namespace std;

// GFG --> Encrypt the string - 2:
string Hexadecimal(int n)
{
    string ans;
    while(n)
    {
        int temp = n%16;
        n/=16;
        if(temp>=10)
        {
          ans += (char)('a'+temp-10);
        }
        else
        {
          ans += (char)('0'+temp);
        }
    }
    return ans;
}

    string encryptString(string S) {
        // code here
        string output = "";
        unordered_map<char, int> mp;
        vector<char> v;
        for(char c : S) {
            mp[c]++;
            if(find(v.begin(), v.end(), c) == v.end()) {
                v.push_back(c);
            }
        }
        int count;
        char c;
        for(int i = v.size() - 1; i >=0; i--) {
            count = mp[v[i]];
            output = output + Hexadecimal(count) + v[i];
        }
        return output;
    }

int main()
{
    
    
    string s = "aaaaaaaaaaa";
    cout << encryptString(s);
    
    return 0;
}
