#include <iostream>
#include <climits>


using namespace std;


void selectionSort(int left[], int size) 
{                 
    int imin;
    
    for(int j = 0; j < size; j++)           
    {
        imin = j;
        for(int i = j + 1; i < size; i++) 
        {
            if(left[imin] > left[i]) 
            {
                imin = i;
            }
        }
        
        if(j != imin)
        {
            swap(left[j], left[imin]);
        }
        
        
    }
    
}

int main()
{
    
    int left[] = {5, 1, 4, 3, 10, 8, 3};
    int size = sizeof(left) / sizeof(left[0]);
    
    selectionSort(left, size);
    
    cout << "After sorting: " << endl;
    
    for(int i : left)
    {
        cout << i << " ";
    }
    

    return 0;
}
