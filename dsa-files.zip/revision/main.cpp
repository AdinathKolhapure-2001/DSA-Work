#include <iostream>

using namespace std;

int main()
{
    // min swaps --> selection sort 
    
    // array    vs  linked list 
    
    // static        dynamic 
    // indexed       by links
    // contigous     random 
    // less           more 
    
    //  sl
    // node -->  | data  | pointer | 
    
    // temp = head; // head / list / start
    //             // next/link 
    //             // data / val    temp == temp != NULL
    // while(temp != NULL) {       (!temp)  == (temp == NULL)
    //     cout << temp-> data;
    //     temp = temp -> next;
    // }
    
    // singly linked list
    // search --> O(n)
    // inesrt at begin --> O(1)
    // inesrt at end --> O(n)
    // inesrt at end if end node is given --> O(1)
    // delete the front --> O(1)
    // delete the end --> O(n)
    // delete the end if end given --> O(n)
    
    // singly doubly linked list
    // search --> O(n)
    // inesrt at begin --> O(1)
    // inesrt at end --> O(n)
    // inesrt at end if end node is given --> O(1)
    // delete the front --> O(1)
    // delete the end --> O(n)
    // delete the node if node given --> O(1)
    
    
    // singly circular linked list
    // search --> O(n)
    // inesrt at begin --> O(n)
    // inesrt at end --> O(n)
    // inesrt at end if end node is given --> O(1)
    // delete the front --> O(n)
    // delete the end --> O(n)
    // delete the node if node given --> O(n)
    
    
    // NULL -> next / data --> NULL pointer dereference 
    
    // finding the middle   -->  slow and fast pointer approch
    
    //         T                   F         -->   F
    // while(fast != NULL &&  fast -> next != NULL)
    //                   s             f
    // 1 --> 2 --> 4 --> 8 --> 10 --> 52
    
    
    
    // detect and remove the cycle --> slow, fast pointer approch. If slow == fast --> cycle present
    // start a pointer from the head and one from slow-> next move both pointers simultaniouly by one step 
    // when this two pointer meets that will be the intersetion point have one pointer to the prev of slow 
    // when this two pointer meet set the pre-> next= NULL, So the cycle will be removed
    

    // find the intersetion of two linked lists
    
    // h1 --> 1 2 3 4 5            
//              |
// h2 -->   7 8 |

// while(h1 != h2) {
//     if(h1==NULL) h1 = h2;
//     else h1 = h1 -> next;
//     if(h2==NULL) h2 = h1;
//     else h2 = h2 -> next;
// }
// return h1;
    
    
    // find the kth element from the end
    // merge two sorted ll
    // folding a ll 
    // Check if the linked List is Palindrome
    
    
    return 0;
}

