#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;


class BSTNode
{
    int data;
    BSTNode *left;
    BSTNode *right;
    
    public:
    
    ~BSTNode()  // Destructor
    {
        
    }
    
    
    BSTNode *GetNewNode(int);
    BSTNode *Insert(BSTNode *,int);
    bool Search(BSTNode *, int);
    void InorderTraversal(BSTNode *);
    void PreorderTraversal(BSTNode *);
    void PostorderTraversal(BSTNode *);
    void LevelOrderTraversal(BSTNode *);
    void FindMin(BSTNode *);
    void FindMax(BSTNode *);
    int FindHeight(BSTNode *);
    
    
};


BSTNode * BSTNode::GetNewNode(int data)
{
    BSTNode *newNode = new BSTNode();
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    
    return newNode;
}

BSTNode * BSTNode::Insert(BSTNode *root, int data)
{
    
    if(root == NULL)
    {
        root = GetNewNode(data);
    }
    else if(data <= root->data)
    {
        root->left = Insert(root->left,data);
    }
    else
    {
        root->right = Insert(root->right,data);
    }
    
    return root;
}


bool BSTNode::Search(BSTNode *root, int data)
{
    if(root == NULL)
    {
        return false;
    }
    if(root->data == data)
    {
        return true;
    }
    else if(data <= root->data)
    {
        return Search(root->left,data);
    }
    else
    {
        return Search(root->right,data);
    }
    
}


void BSTNode::PreorderTraversal(BSTNode *root)
{
    if(root == NULL)
    {
        return ;
    }
    cout<<"| "<<root->data<<" | -->";
    PreorderTraversal(root->left);
    PreorderTraversal(root->right);
}



void BSTNode::InorderTraversal(BSTNode *root)
{
    if(root == NULL)
    {
        return;
    }
    
    InorderTraversal(root->left);
    cout<<"| "<<root->data<<" | -->";
    InorderTraversal(root->right);
    
}


void BSTNode::PostorderTraversal(BSTNode *root)
{
    if(root == NULL)
    {
        return;
    }
    
    InorderTraversal(root->left);
    InorderTraversal(root->right);
    cout<<"| "<<root->data<<" | -->";

}


void BSTNode::LevelOrderTraversal(BSTNode *root)
{
    if(root == NULL)
    {
        cout<<"\nBST is Empty"<<endl;
        return;
    }
    
    queue <BSTNode *> q;
    q.push(root);
    
    while(!q.empty())
    {
        BSTNode *curr = q.front();
        
        cout<<"| "<<curr->data<<" | --> ";
        
        if(curr->left)
        {
            q.push(curr->left);
        }
        if(curr->right)
        {
            q.push(curr->right);
        }
        
        q.pop();
    }
    
    
}


void BSTNode::FindMin(BSTNode *root)
{
    if(!root->left)
    {
        cout<<"| "<<root->data<<" |"<<endl;
        return ;
    }
    FindMin(root->left);
}


void BSTNode::FindMax(BSTNode *root)
{
    if(!root->right)
    {
        cout<<"| "<<root->data<<" |"<<endl;
        return;
    }
    FindMax(root->right);
}


int BSTNode::FindHeight(BSTNode *root)
{
    if(root == NULL)
    {
        return -1;
    }
    
    return max(FindHeight(root->left),FindHeight(root->right))+1;
}



int main()
{
    BSTNode *root = NULL;
    
    BSTNode BST_Obj;
    
    int Element;
   
    root = BST_Obj.Insert(root,50);
    root = BST_Obj.Insert(root,40);
    root = BST_Obj.Insert(root,30);
    root = BST_Obj.Insert(root,60);
    root = BST_Obj.Insert(root,45);
    root = BST_Obj.Insert(root,70);
    
    cout<<"\nPreorder Traversal: "<<endl;
    BST_Obj.PreorderTraversal(root);
    
    cout<<"\nInorder Traversal: "<<endl;
    BST_Obj.InorderTraversal(root);
    
    cout<<"\nPostorder Traversal: "<<endl;
    BST_Obj.PostorderTraversal(root);
    
    cout<<"\nLevel order Traversal: "<<endl;
    BST_Obj.LevelOrderTraversal(root);
    
    cout<<"\nMinimum element is: ";
    BST_Obj.FindMin(root);
    
    cout<<"\nMaximum element is: ";
    BST_Obj.FindMax(root);
    
    int Height = BST_Obj.FindHeight(root);
    cout<<"\nHeight of BST is: "<<Height<<endl;
    
    cout<<"\nEnter the number to search: ";
    cin>>Element;
    
    if(BST_Obj.Search(root,Element))
    {
        cout<<"\nElement found"<<endl;
    }
    else
    {
        cout<<"\nElement not found"<<endl;
    }
    
    
    
    return 0;
}