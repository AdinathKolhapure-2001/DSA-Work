#include <iostream>
using namespace std;


int linearSearch(int arr[],int size)
{
    int target;
    
    cout<<"Enter the element you want to search: ";
    cin>>target;
    
    for(int i=0;i<size;i++)
    {
        if(arr[i]==target)
        {
            return i;
        }
    }
    return -1;
    
}

int binarySearch(int arr[],int size)
{
    int start=0,mid,end=size-1,target;
    
    
    cout<<"Enter the element you want to search: ";
    cin>>target;
    
    while(start<end)
    {
        mid=(start+end)/2;
        
        if(arr[mid]==target)
        {
            return mid;
        }
        else if(arr[mid]>target)
        {
            end=mid-1;
        }
        else
        {
            start=mid+1;
        }
    }
    return -1;
    
}

void display(int result)
{
    if(!(result+1))
    {
        cout<<"\nElement is not present in array"<<endl;
    }
    else
    {
        cout<<"\nElement is present at "<<result+1<<" position"<<endl;
    }
}

int main()
{
    int size,linearSearchResult,binarySearchResult,i,ch,flag=0;
    int MAX=100;
    int arr[MAX];
    
    while(ch!=5)
    {   cout<<"\n----------------------------------Menu----------------------------------"<<endl;
        cout<<"1.Create an array"<<endl;
        cout<<"2.Display array elements"<<endl;
        cout<<"3.Linear Search"<<endl;
        cout<<"4.Binary Search"<<endl;
        cout<<"5.Terminate program"<<endl;
        
        cout<<"\nEnter your choice: ";
        cin>>ch;
        
        switch(ch)
        {
            case 1:
            
            cout<<"Enter the size of an array: ";
            cin>>size;
            arr[size];
            
            cout<<"\nWARNING: For binary search please enter array in ascending order"<<endl;
            
            for(i=0;i<size;i++)
            {
                cout<<"Enter the element: ";
                cin>>arr[i];
            }
            flag=1;
            
            break;
            
            case 2:
            
            if(flag)
            {
                cout<<"Array elements are:"<<endl;
            
                for(i=0;i<size;i++)
                {
                    cout<<arr[i]<<"|";
                }
            }
            else
            {
                cout<<"WARNING: Please create an array"<<endl;
            }
            
            
            break;
            
            case 3:
            
            if(flag)
            {
                linearSearchResult=linearSearch(arr,size);  // linear search function call
            
                display(linearSearchResult);               // display function call 
            }
            else
            {
                cout<<"WARNING: Please create an array"<<endl;
            }
            
            break;
            
            case 4:
            
            if(flag)
            {
                binarySearchResult=binarySearch(arr,size);  // binary search function call 
                
                display(binarySearchResult);
            }
            else
            {
                cout<<"WARNING: Please create an array"<<endl;
            }
            
            break;
            
            case 5:
            
            exit(0);
            
            break;
            
            default:
            cout<<"Enter valid choice"<<endl;
            
        }
    }
    
    
    
    
    
    return 0;
}

