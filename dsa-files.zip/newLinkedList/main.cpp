#include <iostream>

using namespace std;


struct Node {
    int data;
    Node* next;
    public:
    Node(int data) {
        this -> data = data;
        this -> next = NULL;
    }
};

class linkedList {
    public:
    
    static Node* insert(Node* head, int data) {
        Node* newNode = new Node(data);
        if(head == NULL) {
            head = newNode;
        }
        else {
            Node* temp = head;
            while(temp -> next != NULL) {
                temp = temp -> next;
            }
            temp -> next = newNode;
        }
        return head;
    }
    
    
    static Node* deleteNthNode(Node* head, int n) {
        Node* temp = head;
        if(n == 1) {
            head = head -> next;
            delete temp;
        }
        else {
            for(int i = 0; i < n - 2; i++) {
            temp = temp -> next;
            }
            Node* temp1 = temp -> next;
            temp -> next = temp -> next -> next;
            delete temp1;
        }
        
        return head;

    }
    
    static void Print(Node* head) {
        while(head != NULL) {
            cout << head -> data << " --> ";
            head = head -> next;
        }
        cout << " NULL " << endl;
    }
    
    static Node* reverse(Node* head){
        Node* prev = NULL, *curr = head, *Next;
        while(curr != NULL) {
            Next = curr -> next;
            curr -> next = prev;
            prev = curr;
            curr = Next;
        }
        return prev;
        
    }
    
    static Node* recurrsiveReverse(Node* head) {
        if(head -> next == NULL) {
            return head;
        }
        Node* newHead = recurrsiveReverse(head -> next);
        head -> next -> next = head;
        head -> next = NULL;
        return newHead;
    }
    
    static void reversePrint(Node* head) {
        if(head == NULL) {
            return;
        }
        reversePrint(head -> next);
        cout << head -> data << " --> ";
    }
    
};

int main()
{
    Node* head = NULL;
    
    head = linkedList :: insert(head, 2);
    linkedList :: insert(head, 4);
    linkedList :: insert(head, 6);
    linkedList :: insert(head, 5);
    
    linkedList :: Print(head);
    
    head = linkedList :: reverse(head);
    
    linkedList :: Print(head);
    
    head = linkedList :: recurrsiveReverse(head);
    
    linkedList :: Print(head);
    
    // linkedList :: reversePrint(head);
    
    head = linkedList :: deleteNthNode(head, 2);
    
    linkedList :: Print(head);
    
    
    return 0;
}