#include <iostream>

using namespace std;

int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    cout << "Pivot = " << pivot << endl;
    int pIndex = low;
    for(int i = low; i < high; i++) {
        if(arr[i] <= pivot) {
            swap(arr[i], arr[pIndex++]);
        }
    }
    swap(arr[pIndex], arr[high]);
    cout << "Pindex = " << pIndex << endl;
    return pIndex;
}


// best and avrage = O(nlogn)
// worst case = O(n^2)

void quickSort(int arr[], int low, int high) {
    if(low >= high) return;
    int pIndex = partition(arr, low, high); // O(n)
    quickSort(arr, low, pIndex - 1); // O(n-1)       // best or average --> get the middle index as the pIndex
    quickSort(arr, pIndex + 1, high); // O(1)      // O(nlogn)
}
// O(n^2)

// If you are getrting either smallest or largest as the pivot  // T(n) = 2 * T(n / 2) + c*n  --> O(nlogn)
                                                                // T(n) = T(n - 1) + c.n   --> O(n^2)
int main()
{
    int arr[] = {2, 5, 4, 1, 3};    // 
    //           1
    // {1, 5, 4, 3, 2}
    int n = sizeof(arr) / sizeof(arr[0]);
    
    quickSort(arr, 0, n - 1);
    
    for(int num : arr) cout << num << " ";

    return 0;
}

