#include <bits/stdc++.h>

using namespace std;

// leetcode 125: valid palindrome
// bool isPalindrome(string s) {
//         string newStr = "";
//         for(char c : s) {
//             if(isalnum(c))
//                 newStr += tolower(c);
//         }
//         string oldStr = newStr;
//         reverse(newStr.begin(), newStr.end());
//         return oldStr == newStr;
//     }
    
 
// leetcode 680:  valid palindrome 2
// https://www.geeksforgeeks.org/substring-in-cpp/

// bool validPalindrome(string s) {             // This is giving TLE
//         int n = s.length();
//         string subStr;
//         for(int i = 0; i < n; i++) {                                // i = 3
//             subStr = s.substr(0, i) + s.substr(i + 1, n - i - 1);   // "" + bca, a + ca, ab + a, abc + ""
//             cout << subStr << endl;
//             if(isPalindrome(subStr)) {
//                 return true;
//             }
//         }
//         return false;
//     }

// Alternative solution:

   /* Check is s[i...j] is palindrome. */
bool isPalindrome(string s, int i, int j) {
        
        while (i < j) {
            if (s[i++] != s[j--]) {
                return false;
            }
        }
        
        return true;
    }
    
bool validPalindrome(string s) {
        int i = 0, j = s.length() - 1;
        
        while (i < j) {
            if (s[i] != s[j]) {
                return isPalindrome(s, i + 1, j) || isPalindrome(s, i, j - 1);
            }
            i++;
            j--;
        }

        return true;
    }
    
    
int main()
{
    // string s = "r1ace, ca1r!";
    
    // isPalindrome(s) ? cout << "true" : cout << "false";
    
    string s = "abcecda";
    
    validPalindrome(s) ? cout << "true" : cout << "false";

    return 0;
}
