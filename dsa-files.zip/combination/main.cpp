#include <iostream>

using namespace std;


int comb_rec(int n, int r)
{
    if(n == 0 && r == 0)
    {
        return 1;
    }
    else if(n == r)
    {
        return 1;
    }
    else if(r == 0)
    {
        return 1;
    }
    
    return comb_rec(n - 1, r - 1) + comb_rec(n - 1, r);
}


int comb_itr(int n, int r)
{
    int C[n][n];
    
    for(int i = 0; i <= n; i++)
    {
        for(int j = 0; j <= i; j++)
        {
            if(i == 0 && j == 0)
            {
                C[i][j] = 1;
            }
            else if(i == j)
            {
                C[i][j] =  1;
            }
            else if(j == 0)
            {
                C[i][j] = 1;
            }
            else
            {
                C[i][j] = C[i - 1][j - 1] + C[i - 1][j];
            }
        }
    }
    
    return C[n][r];
}


int main()
{
    
    cout << comb_rec(5, 2) << endl;
    
    cout << comb_itr(5, 2) << endl;
    
    return 0;
}

