#include <bits/stdc++.h>

using namespace std;

// leetcode 6033:   --> Accepted
string DecimalToBinary(int num) {
    string str;
        for (int i = 31; i >= 0; i--) {
        int k = num >> i;
        if (k & 1)
            str += "1";
        else
            str += "0";
        }
        return str;
    }
    
    int minBitFlips(int start, int goal) {
        string startBin = DecimalToBinary(start);
        reverse(startBin.begin(), startBin.end());
        string goalBin = DecimalToBinary(goal);
        reverse(goalBin.begin(), goalBin.end());
            
        int N = startBin.length(), flip = 0;
        for(int i = 0; i < N; i++) {
            if(startBin[i] != goalBin[i]) flip++;
        }
        return flip;
    }
    

// leetcode 6034:   --> Accepted

int triangularSum(vector<int>& nums) {
        int M,N;
        N = M = nums.size();
        for(int i = 0; i < N; i++) {
            M--;
            for(int j = 0; j < M; j++)
                nums[j] = (nums[j] + nums[j+1]) % 10;
        }
        return nums[0];
    }
    
    
    
// leetcode 6035: --> TLE
int numberOfWays(string s) {
        int N = s.length(), cnt = 0;
        for(int i = 0; i < N; i++) {
            for(int j = i+1; j < N; j++) {
                for(int k = j+1; k < N; k++) {
                    if(s[i] != s[j] && s[j] != s[k]) cnt++;
                }
            }
        }
        return cnt;
    }

int main()
{
    // int start = 10, goal = 7;
    // cout << minBitFlips(start, goal);
    
    
    // vector<int> nums = {1,2,3,4,5};
    // cout << triangularSum(nums);
    
    
    // string s = "11100";
    // cout << numberOfWays(s);

    return 0;
}