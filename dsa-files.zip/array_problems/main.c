/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>


void sumOfSubarrays(int arr[], int size)        // nC2 + n = n*(n + 1) / 2   -->  subarrays 
{
    int curr_sum;
    for(int i = 0; i < size; i++)
    {
        curr_sum = 0;
        for(int j = i; j < size; j++)
        {
            curr_sum += arr[j];
            printf("\n%d", curr_sum);
        }
        printf("\n");
    }
}

int main()
{
    int arr[] = {1, 2, 3, 4, 5};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    sumOfSubarrays(arr, size);
    
    return 0;
}
