/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
#include<cstring>
using namespace std;


class tree
{   tree *left,*right;
    char data;
public:
    tree * create(char);
    tree * construct_pre(char []);
    tree * construct_post(char []);
    void inorder_1(tree *);
    void preorder_1(tree *);
    void postorder_1(tree *);
    void inorder(tree *);
    void preorder(tree *);
    void postorder(tree *);
};
class stack
{
public:
    stack * next;
    tree * t;
    int flag;
    stack * push(stack *,tree *,int);
    stack * pop(stack *);

};
stack * stack::push(stack * top,tree * temp,int f)
{   stack * newnode=new stack;
    newnode->flag=f;
    newnode->t=temp;
    newnode->next=NULL;
    if(top==NULL)
        top=newnode;
    else
    {   newnode->next=top;
        top=newnode;
    }

    return top;
}
stack * stack::pop(stack * top)
{   stack * temp=top;
    if(top==NULL)
        cout<<"Stack is empty"<<endl;
    else
    {   top=top->next;
        delete temp;
    }
    return top;
}
tree * tree::create(char x)
{   tree * newnode=new tree;
    newnode->data=x;
    newnode->left=NULL;
    newnode->right=NULL;
    return newnode;
}
tree * tree::construct_pre(char exp[])
{   int j;
    stack *top=NULL;
    tree *temp;
    for(j=(strlen(exp)-1); j>=0; j--)
    {   if(isalnum(exp[j]))
        {   temp=create(exp[j]);
            top=top->push(top,temp,0);


        }
        else
        {   temp=create(exp[j]);
            temp->left=top->t;
            top=top->pop(top);
            temp->right=top->t;
            top=top->pop(top);
            top=top->push(top,temp,0);



        }
    }
    temp=top->t;
    top=top->pop(top);
    return temp;
}
tree * tree::construct_post(char exp[])
{   int i=0;
    stack *top=NULL;
    tree *temp;
    while(exp[i]!='\0')
    {   if(isalnum(exp[i]))
        {   temp=create(exp[i]);
            top=top->push(top,temp,0);
            i++;
        }
        else
        {   temp=create(exp[i]);
            temp->right=top->t;
            top=top->pop(top);
            temp->left=top->t;
            top=top->pop(top);
            top=top->push(top,temp,0);
            i++;

        }
    }
    temp=top->t;
    top=top->pop(top);
    return temp;
}
void tree::inorder_1(tree * root)
{   tree * curr=root;
    stack * top=NULL;
    while(1)
    {   while(curr)
        {   top=top->push(top,curr,0);
            curr=curr->left;
        }
        if(top!=NULL)
        {   curr=top->t;
            top=top->pop(top);
            cout<<curr->data;
            curr=curr->right;
        }
        else
            break;
    }
}
void tree::preorder_1(tree * root)
{   tree * curr=root;
    stack * top=NULL;
    while(1)
    {   while(curr)
        {   cout<<curr->data;
            if(curr->right)
                top=top->push(top,curr->right,0);
            curr=curr->left;

        }
        if(top!=NULL)
        {   curr=top->t;
            top=top->pop(top);
        }
        else
            break;
    }


}
void tree::postorder_1(tree * root)
{   stack * top=NULL;
    tree * curr=root;
    int flag;
    do
    {   while(curr!=NULL)
        {   top=top->push(top,curr,0);
            curr=curr->left;
        }
        flag=top->flag;
        curr=top->t;
        top=top->pop(top);
        if(flag==1)
        {   cout<<curr->data;
            curr=NULL;
        }
        else
        {   top=top->push(top,curr,1);
            curr=curr->right;
        }
    }
    while(top!=NULL);

}



void tree::inorder(tree * root)
{   if(root==NULL)
        return;
    inorder(root->left);
    cout<<root->data;
    inorder(root->right);
}
void tree::preorder(tree * root)
{   if(root==NULL)
        return;
    cout<<root->data;
    preorder(root->left);
    preorder(root->right);
}
void tree::postorder(tree * root)
{   if(root==NULL)
        return;
    postorder(root->left);
    postorder(root->right);
    cout<<root->data;
}
int main()
{   int ch,flag=0;
    tree *root=NULL;
    tree t;
    char post_exp[20];
    char pre_exp[20];
    while(ch!=3)
    {   cout<<"\n----Menu----"<<endl;
        cout<<"1.create postorder tree"<<endl;
        cout<<"2.create preorder tree"<<endl;
        cout<<"3.exit"<<endl;
        cout<<"Enter your choice: ";
        cin>>ch;
        switch(ch)
        {
        case 1:
            cout<<"Enter postfix expression: ";
            cin>>post_exp;
            root=t.construct_post(post_exp);

            while(ch!=4)

            {   cout<<"\n----Menu----"<<endl;
                cout<<"1.inorder"<<endl;
                cout<<"2.preorder"<<endl;
                cout<<"3.postorder"<<endl;
                cout<<"4.exit"<<endl;
                cout<<"Enter your choice: ";
                cin>>ch;
                switch(ch)
                {
                case 1:
                    cout<<"\n----Menu----"<<endl;
                    cout<<"1.Recursive"<<endl;
                    cout<<"2.Non Recursive"<<endl;
                    cout<<"Enter your choice: ";
                    cin>>ch;
                    switch(ch)
                    {
                    case 1:
                        cout<<"Result of inorder traversal: ";
                        t.inorder(root);
                        break;
                    case 2:
                        cout<<"Result of inorder traversal: ";
                        t.inorder_1(root);
                        break;
                    }
                    break;
                case 2:
                    cout<<"\n----Menu----"<<endl;
                    cout<<"1.Recursive"<<endl;
                    cout<<"2.Non Recursive"<<endl;
                    cout<<"Enter your choice: ";
                    cin>>ch;
                    switch(ch)
                    {
                    case 1:
                        cout<<"Result of preorder traversal: ";
                        t.preorder(root);
                        break;
                    case 2:
                        cout<<"Result of preorder traversal: ";
                        t.preorder_1(root);
                        break;
                    }
                    break;
                case 3:
                    cout<<"\n----Menu----"<<endl;
                    cout<<"1.Recursive"<<endl;
                    cout<<"2.Non Recursive"<<endl;
                    cout<<"Enter your choice: ";
                    cin>>ch;
                    switch(ch)
                    {
                    case 1:
                        cout<<"Result of postorder traversal: ";
                        t.postorder(root);
                        break;
                    case 2:
                        cout<<"Result of postorder traversal: ";
                        t.postorder_1(root);
                        break;
                    }
                    break;
                case 4:
                    continue;
                    break;
                default:
                    cout<<"Enter valid choice"<<endl;
                }
            }

            break;
        case 2:
            cout<<"Enter prefix expression: ";
            cin>>pre_exp;
            root=t.construct_pre(pre_exp);

            while(ch!=4)

            {   cout<<"\n----Menu----"<<endl;
                cout<<"1.inorder"<<endl;
                cout<<"2.preorder"<<endl;
                cout<<"3.postorder"<<endl;
                cout<<"4.exit"<<endl;
                cout<<"Enter your choice: ";
                cin>>ch;
                switch(ch)
                {
                case 1:
                    cout<<"\n----Menu----"<<endl;
                    cout<<"1.Recursive"<<endl;
                    cout<<"2.Non Recursive"<<endl;
                    cout<<"Enter your choice: ";
                    cin>>ch;
                    switch(ch)
                    {
                    case 1:
                        cout<<"Result of preorder traversal: ";
                        t.inorder(root);
                        break;
                    case 2:
                        cout<<"Result of preorder traversal: ";
                        t.inorder_1(root);
                        break;
                    }
                    break;
                case 2:
                    cout<<"\n----Menu----"<<endl;
                    cout<<"1.Recursive"<<endl;
                    cout<<"2.Non Recursive"<<endl;
                    cout<<"Enter your choice: ";
                    cin>>ch;
                    switch(ch)
                    {
                    case 1:
                        cout<<"Result of preorder traversal: ";
                        t.preorder(root);
                        break;
                    case 2:
                        cout<<"Result of preorder traversal: ";
                        t.preorder_1(root);
                        break;
                    }
                    break;
                case 3:
                    cout<<"\n----Menu----"<<endl;
                    cout<<"1.Recursive"<<endl;
                    cout<<"2.Non Recursive"<<endl;
                    cout<<"Enter your choice: ";
                    cin>>ch;
                    switch(ch)
                    {
                    case 1:
                        cout<<"Result of preorder traversal: ";
                        t.postorder(root);
                        break;
                    case 2:
                        cout<<"Result of preorder traversal: ";
                        t.postorder_1(root);
                        break;
                    }
                    break;
                case 4:
                    continue;
                    break;
                default:
                    cout<<"Enter valid choice"<<endl;
                }
            }
            break;
        case 3:
            exit(0);
            break;
        default:
            cout<<"Enter valid choice"<<endl;
        }


    }

    return 0;
}
