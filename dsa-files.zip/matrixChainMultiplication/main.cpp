#include <iostream>
#include <climits>
using namespace std;


int matrixChainMult(int dim[], int n)
{
    int j, min, q;
    
    int mat1[n][n] = {0};
    int mat2[n][n] = {0};
    
    for(int d = 1; d < n - 1; d++)
    {
        for(int i = 1; i < n - d; i++)
        {
            j = i + d;
            min = INT_MAX;
            for(int k = i; k <= j - 1; k++)
            {
                q = mat1[i][k] + mat1[k + 1][j] + dim[i - 1] * dim[k] * dim[j];
                if(q < min)
                {
                    min = q;
                    mat2[i][j] = k;
                }
                
            }
            mat1[i][j] = min;
        }
    }
    
    
    return mat1[1][n - 1];
}

int main()
{
    int n = 5;
    int dim[] = {5, 4, 6, 2, 7};
    
    cout << "Minimum cost of matrix chain multiplication is " << matrixChainMult(dim, n) << endl;

    return 0;
}
