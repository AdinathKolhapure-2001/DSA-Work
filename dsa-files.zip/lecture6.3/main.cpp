#include <bits/stdc++.h>

using namespace std;

int sumOfNNatural(int n) {
    int ans = 0;
    for(int i = 1; i <= n; i++) {
        ans += i;
    }
    return ans;
}

bool check(int a, int b, int c) {
    int x = max(a, max(b, c));
    int y, z;
    if(x == a) {
        y = b, z = c;
    }
    else if(x == b) {
        y = a, z = c;
    }
    else {
        y = a, z = b;
    }
    
    if(x * x == (y * y + z * z)) {
        return true;
    }
    else {
        return false;
    }
}


int binaryToDecimal(int n) {
    int ans = 0;
    int index = 1;
    while(n) {
        ans += index * (n % 10);
        index *= 2;
        n /= 10;
    }
    return ans;
}


int octalToDecimal(int n) {
    int ans = 0;
    int index = 1;
    while(n) {
        ans += index * (n % 10);
        index *= 8;
        n /= 10;
    }
    return ans;
}

int hexadecimalToDecimal(string s) {
    int ans = 0;
    int index = 1;
    for(int i = s.size() - 1; i >= 0; i--) {
        if(s[i] >= '0' and s[i] <= '9') {
            ans += index * (s[i] - '0');
        }
        else {
            ans += index * (s[i] - 'A' + 10);
        }
        index *= 16;
    }
    
    return ans;
}

int decimalToBinary(int n) {
    int ans = 0;
    int x = 1;
    while(x <= n)
        x *= 2;
    x /= 2;
    while(x) {
        int lastDigit = n / x;
        n -= lastDigit * x;
        x /= 2;
        ans = ans * 10 + lastDigit;
    }
    return ans;
}

int decimalToOctal(int n) {
    int ans = 0;
    int x = 1;
    while(x <= n)
        x *= 8;
    x /= 8;
    while(x) {
        int lastDigit = n / x;
        n -= lastDigit * x;
        x /= 8;
        ans = ans * 10 + lastDigit;
    }
    return ans;
}

string decimalTOHexadecimal(int n) {
    string ans = "";
    int x = 1;
    while(x <= n) {
        x *= 16;
    }
    x /= 16;
    while(x) {
        int lastDigit = n / x;
        n -= lastDigit * x;
        x /= 16;
        
        if(lastDigit <= 9) {
            ans = ans + to_string(lastDigit);
        }
        else {
            char c = 'A' + lastDigit - 10;
            ans.push_back(c);
        }
    }
    return ans;
    
}

int main()
{
    // Sum of n natural numbers
    // int n;
    // cin >> n;
    // cout << sumOfNNatural(n) << endl;
    
    // Pythagorian triplet
    // int a, b, c;
    // cin >> a >> b >> c;
    // if(check(a, b, c)) {
    //     cout << "Pythagorian triplet" << endl;
    // }
    // else {
    //     cout << "Not Pythagorian triplet" << endl;
    // }
    
    // Binary to decimal
    // int n;
    // cin >> n;
    // cout << binaryToDecimal(n) << endl;
    
    // Octal to decimal
    // int n;
    // cin >> n;
    // cout << octalToDecimal(n) << endl;
    
    // Hexadecimal to to decimal
    // string n;
    // cin >> n;
    // cout << hexadecimalToDecimal(n) << endl;
    
    
    // Decimal to binary 
    // int n;
    // cin >> n;
    // cout << decimalToBinary(n) << endl;
    
    // Decimal to octal 
    // int n;
    // cin >> n;
    // cout << decimalToOctal(n) << endl;
    
    // Decimal to Hexadecimal
    // int n;
    // cin >> n;
    // cout << decimalTOHexadecimal(n) << endl;
    
    

    return 0;
}