#include <bits/stdc++.h>

using namespace std;

// Problem Link : https://leetcode.com/problems/median-of-two-sorted-arrays/
// Solution link : https://www.youtube.com/watch?v=NTop3VTjmxk&t=1636s&ab_channel=takeUforward

// 4. Median of Two Sorted Arrays

// Given two sorted arrays nums1 and nums2 of size m and n respectively, return the median of the two sorted arrays.

// The overall run time complexity should be O(log (m+n)).

// Example 1:

// Input: nums1 = [1,3], nums2 = [2]
// Output: 2.00000
// Explanation: merged array = [1,2,3] and median is 2.
// Example 2:

// Input: nums1 = [1,2], nums2 = [3,4]
// Output: 2.50000
// Explanation: merged array = [1,2,3,4] and median is (2 + 3) / 2 = 2.5.

// Method 1(Simple) :
// Use merge techmique from merge sort two merge two sorted arrays 
// After merging check whether sum of size of two arrays is even or odd (number of elements)
// if it is even then calculate the median by taking arithmetic mean of two middle elements
// if it is odd then return the middle element

// Time complexity : O(m+n)
// Space complexity : O(m+n)

double findMedian1(vector<int> &nums1, vector<int> &nums2) {
    int m = nums1.size();
    int n = nums2.size();
    vector<int> merged(m + n);
    int i = 0, j = 0, k = 0;
    while(i < m && j < n) {
        if(nums1[i] < nums2[j])
            merged[k++] = nums1[i++];
        else 
            merged[k++] = nums2[j++];
    }
    while(i < m)
        merged[k++] = nums1[i++];
    while(j < n)
        merged[k++] = nums2[j++];
    
    if(!((m+n)&1))
        return (merged[(m+n)/2] + merged[(m+n)/2 - 1]) / 2.0;
    return merged[(m+n)/2];
}

// Method 2 : 
// In the above approach we are using some extra space, we can reduce the space complexity to O(1)
// we only need to find the middle element index to calculate the median
// once we got the middle element index then check the sum of size of arrays
// and return the median accordingly 
// Time complexity : O(m+n)
// space complexity : O(1)


double findMedian2(vector<int> &nums1, vector<int> &nums2) {
    int m = nums1.size();
    int n = nums2.size();
    int i = 0, j = 0, m1, m2;
    for(int idx = 0; idx <= (m+n)/2; idx++) {   // idx = 4
        m1 = m2;                                // m1 = 4
        if(i != m && j != n) {                  // m2 = 5 
            m2 = nums1[i] < nums2[j] ? nums1[i++] : nums2[j++]; // i = 1
        }                                                       // j = 3
        else if(i < m)
            m2 = nums1[i++];
        else 
            m2 = nums2[j++];
    }
    
    if(!((m+n)&1))
        return (m1 + m2) / 2.0;
    return m2;
}


// Method 3 : 
// Because arrays are sorted we can use binary search 
// consider an array with smaller length and apply binary search on that array 
// partition the arrays into two parts and check for its validity 
// For more information refer the video link given above 

double findMedian3(vector<int> &nums1, vector<int> &nums2) {
    if(nums2.size() < nums1.size()) return findMedian3(nums2, nums1);
    int m = nums1.size();
    int n = nums2.size();
    int cut1, cut2, left1, left2, right1, right2;
    int low = 0, high = m;
    while(low <= high) {
        cut1 = (low + high) >> 1;
        cut2 = (m + n + 1) / 2 - cut1;
        
        left1 = cut1 == 0 ? INT_MIN : nums1[cut1 - 1];
        left2 = cut2 == 0 ? INT_MIN : nums2[cut2 - 1];
        right1 = cut1 == m ? INT_MAX : nums1[cut1];
        right2 = cut2 == n ? INT_MAX : nums2[cut2];
        
        if(left1 <= right2 && left2 <= right1) {
            if(!((m+n)&1)) {
                return (max(left1, left2) + min(right1, right2)) / 2.0;
            }
            else 
                return max(left1, left2);
        }
        else if(left1 > right2) {
            high = cut1 - 1;
        }
        else {
            low = cut1 + 1;
        }
    }
    return 0.0;
}


int main()
{
    vector<int> nums1 = {5, 6, 9, 10};
    vector<int> nums2 = {1, 2, 4};
    
    double median = findMedian3(nums1, nums2);
    
    cout << median;


    return 0;
}