#include <bits/stdc++.h>

using namespace std;

// Problem link : https://www.geeksforgeeks.org/allocate-minimum-number-pages/
// Solution link : https://www.youtube.com/watch?v=gYmWHvRHu-s&t=62s&ab_channel=takeUforward

bool isPossible(vector<int>& books, int mid, int students) {
    int sum = 0, allocateedStudents = 1;
    // cout << "mid = " << mid << endl;
    for(auto& pages : books) {
        if(pages > mid) return false;
        else if(sum + pages > mid) {
            allocateedStudents++;
            sum = pages;
        }
        else {
            sum += pages;
        }
        // cout << sum << endl;
    }
    // cout << "allocateedStudents = " << allocateedStudents << endl;
    return allocateedStudents <= students;
}

int findPages(vector<int>& books, int students) {
    int n = books.size();
    int low = *max_element(books.begin(), books.end());
    int high = accumulate(books.begin(), books.end(), 0);
    int mid, pages = -1;
    
    while(low <= high) {
        mid = (low + high) >> 1;
        if(isPossible(books, mid, students)) {
            pages = mid;
            high = mid - 1;
        }
        else {
            low = mid + 1;
        }
        // cout << "pages = " << pages << endl;
        
    }
    
    return pages;
}


int main()
{
    vector<int> books = {12, 34, 67, 90};   // Output : 113
    int students = 2;
    
    int pages = findPages(books, students);
    
    cout << pages;
    
    return 0;
}
