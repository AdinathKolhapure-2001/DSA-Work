#include <bits/stdc++.h>

using namespace std;

// Q) find the smallest number >= target
// Approach: Given array is sorted and we need to find the smallest number which is just greater or equal to the target
// When we use binary search and when the target id not present start and end will cross 
// start will point to the number which is just greater than the target and 
// end will point to the number which is just smaller than the target
// edge case: when the target is greater than largest number, then start will go out of the bound of the array 
int ceilingOfNumber(vector<int> nums, int target) {
    int n = nums.size();
    int start = 0, end = n - 1, mid, ans; 
    if(target > nums[n - 1]) {
        return -1;
    }
    while(start <= end) {
        mid = start + (end - start) / 2;
        if(target < nums[mid]) {
            end = mid - 1;
            // ans = nums[mid]; // possible answer 
        }
        else if(target > nums[mid]){
            start = mid + 1;
        }
        else {
            return nums[mid];
        }
    }
    // return ans;
    return nums[start];
}

// Q) Find the largest number <= target
// Use the same Approach just return  the number which is present at end 
// edge case: when target is smaller than the smallest number then end will go out of bound of the array
int floorOfNumber(vector<int> nums, int target) {
    int n = nums.size();
    int start = 0, end = n - 1, mid, ans; 
    if(target < nums[0]) {
        return -1;
    }
    while(start <= end) {
        mid = start + (end - start) / 2;
        if(target < nums[mid]) {
            end = mid - 1;
        }
        else if(target > nums[mid]){
            start = mid + 1;
            // ans = nums[mid];
        }
        else {
            return nums[mid];
        }
    }
    // return ans;
    return nums[end];
}

int main()
{
    vector<int> nums = {2, 4, 5, 7, 13, 15, 15, 18, 19, 21};
    int target = 20;
    int ceiling = ceilingOfNumber(nums, target);
    cout << ceiling << endl;
    target = 6;
    int Floor = floorOfNumber(nums, target);
    cout << Floor << endl;
    
    
    return 0;
}
