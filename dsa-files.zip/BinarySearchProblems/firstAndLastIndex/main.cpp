// Given a sorted array of integers, return low and high index 
// of the given key. Retrun -1 if not found the array length can be 
// in millions with many duplicates.
// Input: [1, 1, 1, 2, 2, 2, 2, 3, 9, 9, 9], k=2
// Output: {3, 6}
// Time complexity should be O(logn)
// Approach: Use binary search twice. First to find index of first occurence of the key and second to find 
// the last occurence of the key

#include <iostream>

using namespace std;

int binarySearch(int arr[], int n, int key, bool findStartIndex) {
    int low = 0, high = n - 1, mid, ans = -1; 
    while(low <= high) {
        mid = high - (high - low) / 2;
        if(arr[mid] == key) {
            ans = mid;
            if(findStartIndex) {
                high = mid - 1;
            }
            else {
                low = mid + 1;
            }
        }
        else if(arr[mid] > key) {
            high = mid - 1;
        }
        else {
            low = mid + 1;
        }
    }
    return ans;
}


pair<int, int> firstAndLastPosition(int arr[], int n, int k) {
    pair<int, int> res = {-1, -1};
    res.first = binarySearch(arr, n, k, true);
    if(res.first != -1) {
        res.second = binarySearch(arr, n, k, false);
    }
    return res;
}

int main()
{
    int arr[] = {1, 1, 1, 2, 2, 2, 2, 3, 9, 9, 9}, k=1;
    
    int n = sizeof(arr) / sizeof(arr[0]);
    
    int key = 2;
    
    pair<int, int> firstAndLastIndex = firstAndLastPosition(arr, n, k);
    
    cout << "Start and end index of key is {" << firstAndLastIndex.first << ", " << firstAndLastIndex.second << "}" << endl;
    
    return 0;
}