#include <iostream>

using namespace std;

bool isPrime(int n) {
    for(int i = 2; i < n; i++) {
        if(n % i == 0) {
            return false;
        }
    }
    return true;
}


void fib(int n) {
    int t1 = 0, t2 = 1, nextTerm;
    for(int i = 0; i <= n; i++) {
        cout << t1 << " ";
        nextTerm = t1 + t2;
        t1 = t2;
        t2 = nextTerm;
    }
}


int fact(int n) {
    int factorial = 1;
    for(int i = 2; i <= n; i++) {
        factorial *= i;
    }
    return factorial;
}


int main()
{
    // All prime numbers between range(a, b)
    // int a,b;
    // cin >> a >> b;
    
    // for(int i = a; i < b; i++) {
    //     if(isPrime(i)) {
    //         cout << i << " ";
    //     }
    // }
    
    // fib sequence till n 
    // int n;
    // cin >> n;
    // fib(n);
    
    
    // n!
    // int n;
    // cin >> n;
    // cout << fact(n) << endl;
    
    
    // nCr
    // int n, r;
    // cin >> n >> r;
    
    // cout << fact(n) / (fact(n - r) * fact(r)) << endl;


    // pascle triangle
    // int n;
    // cin >> n;
    // for(int i = 0; i < n; i++) {
    //     for(int j = 0; j <= i; j++) {
    //         cout << fact(i) / (fact(i - j) * fact(j)) << " ";
    //     }
    //     cout << "\n";
    // }
    
    
    return 0;
}