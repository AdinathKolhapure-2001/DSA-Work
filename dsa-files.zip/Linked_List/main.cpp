#include <iostream>
using namespace std;


class linkedList
{
    int data;
    linkedList *next;
    
    public:
    
    ~linkedList()
    {
        
    }
    
    linkedList * createNode(int);
    linkedList *insertNodeAtTheBegin(linkedList *, int);
    linkedList *insertNodeAtTheEnd(linkedList*, int);
    linkedList *insertNodeAtPosition(linkedList *, int, int);
    linkedList *deleteNodeAtPosition(linkedList *, int);
    linkedList *reverseLinkedList(linkedList *);
    linkedList *recursiveReverse(linkedList *);
    int lengthOfLinkedList(linkedList *);
    void display(linkedList *);
    void reversePrint(linkedList *);
};


linkedList * linkedList::createNode(int data)
{
    linkedList * temp = new linkedList();
    temp->data = data;
    
    return temp;
}


linkedList * linkedList::insertNodeAtTheBegin(linkedList * head, int data)
{
    linkedList * newNode = createNode(data);
    newNode->next=head;
    head = newNode;
    
    return head;
}


linkedList * linkedList::insertNodeAtTheEnd(linkedList * head, int data)
{
    linkedList * temp = head;
    
    while(temp->next != NULL)
    {
        temp=temp->next;
    }
    
    linkedList * newNode = createNode(data);
    newNode->next=NULL;
    temp->next = newNode;
    
    return head;
}


linkedList * linkedList::insertNodeAtPosition(linkedList * head, int data, int position)
{
    linkedList *temp = head;
    linkedList *newNode = createNode(data);
    
    
    if(position==1)
    {
        newNode->next=head;
        head=newNode;
        return head;
    }
    
    for(int i=0;i<position-2;i++)
    {
        temp = temp->next;
    }
    
    newNode->next = temp->next;
    temp->next = newNode;
    
    return head;
}


int linkedList::lengthOfLinkedList(linkedList * temp)
{
    int length=0;
    
    while(temp != NULL)
    {
        length++;
        temp=temp->next;
    }
    return length;
}


linkedList * linkedList::deleteNodeAtPosition(linkedList *head, int position)
{
    linkedList *temp = head;
    linkedList *temp1;
    
    if(position==1)
    {
        temp1 = temp;
        head = head->next;
        cout<<"\nHead node is deleted, data of head node was: "<<temp1->data<<endl;
        delete temp1;
        
        return head;
    }
    
    for(int i =0; i<position-2; i++)
    {
        temp=temp->next;
    }
    
    cout<<"\nData of deleted node is: "<<temp->next->data<<endl;
    
    temp1 = temp->next;
    temp->next=temp->next->next;
    delete temp1;
    
    return head;
}

void linkedList::display(linkedList *temp)
{
    cout<<"\nLinked List: \n"<<endl;
    while(temp != NULL)
    {
        cout<<"| "<<temp->data<<" | --> ";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}


void linkedList::reversePrint(linkedList *temp)
{
    if(temp == NULL)
    {
        return;
    }
    reversePrint(temp->next);
    cout<<"| "<<temp->data<<" | --> ";
}


linkedList * linkedList::reverseLinkedList(linkedList *head)
{
    if(!head || !head -> next) {
        return head;
        
    }
    linkedList* prev = NULL;
    linkedList* curr = head;
    linkedList* nextNode = NULL;
    while(curr) {
        nextNode = curr -> next;
        curr -> next = prev;
        prev = curr;
        curr = nextNode;
    }
    return prev;
}

linkedList* linkedList :: recursiveReverse(linkedList* head) {
    if(!head || !head -> next) {
        return head;
    }
    linkedList* newHead = recursiveReverse(head -> next);
    head -> next -> next = head;
    head -> next = NULL;
    return newHead;
}

int main()
{
    
    linkedList *head=NULL;
    linkedList l;
    
    int ch,data,position,length;
    
    while(1)
    {
        
        cout<<"\n---------------------------------- Menu --------------------------------------"<<endl;
        cout<<"1.Insert New Node At the Beginning"<<endl;
        cout<<"2.Display Linked List"<<endl;
        cout<<"3.Insert New Node At the End"<<endl;
        cout<<"4.Insert New Node At Position"<<endl;
        cout<<"5.Delete Node At Position"<<endl;
        cout<<"6.Reverse print linked list"<<endl;
        cout <<"7.Reverse the linked list" << endl;
        cout <<"8.Recursive reverse" << endl;
        cout<<"9.Terminate The Program"<<endl;
        
        cout<<"\nEnter your choice: ";
        cin>>ch;
        
        
        switch(ch)
        {
            
            case 1:
            
            cout<<"\nEnter the data: ";
            cin>>data;
            
            head=l.insertNodeAtTheBegin(head,data);
            
            break;
            
            case 2:
            
            l.display(head);
            
            break;
            
            case 3:
            
            cout<<"\nEnter the data: ";
            cin>>data;
            
            head = l.insertNodeAtTheEnd(head,data);
            
            break;
            
            
            case 4:
            
            cout<<"\nEnter the data: ";
            cin>>data;
            
            length = l.lengthOfLinkedList(head);
            cout<<"\nWARNING: You can insert node in range (1, "<<length+1<<")"<<endl;
            
            cout<<"\nEner the position: ";
            cin>>position;
            
            if(position>0 && position<=length+1)
            {
                head=l.insertNodeAtPosition(head,data,position);
            }
            else
            {
                cout<<"\nWARNING: Enter valid position between range(1, "<<length+1<<")"<<endl;
            }
            
            break;
            
            case 5:
            
            
            
            if(head != NULL)
            {
                length = l.lengthOfLinkedList(head);
                cout<<"\nWARNING: You can delete node in range (1, "<<length<<")"<<endl;
                
                cout<<"\nEner the position: ";
                cin>>position;
                    
                if(position>0 && position<=length)
                {
                    head=l.deleteNodeAtPosition(head,position);
                }
                else
                {
                    cout<<"\nWARNING: Enter valid position between range(1, "<<length<<")"<<endl;
                }
            }
            else
            {
                cout<<"\nWARNING: Linked list is empty"<<endl;
            }
           
            
            break;
            
            case 6:
            
            cout<<"\nReversed Linked list is :\n"<<endl;
            l.reversePrint(head);
            cout<<"NULL"<<endl;
            break;
            
            case 7:
            
            head = l.reverseLinkedList(head);
            cout << "Linked List Reversed successfully" << endl;
            break;
            
            case 8:
            
            head = l.recursiveReverse(head);
            cout << "Linked List Reversed successfully" << endl;
            break;
            
            case 9:
            
            exit(0);
            
            break;
            
            default:
            cout<<"Enter valid choice"<<endl;
            
            
        }
        
        
    }
    
    
    
    
    return 0;
}


