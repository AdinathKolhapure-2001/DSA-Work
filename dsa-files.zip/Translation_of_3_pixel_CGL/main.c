#include <stdio.h>

int main ()
{
  int mat1[3][3], mat2[3][3], output[3][3];

  float tx, ty;

  for (int i = 0; i < 2; i++)
    {
      for (int j = 0; j < 3; j++)
	{
	  printf ("\nEnter mat1[%d][%d]: ", i, j);
	  scanf ("%d", &mat1[i][j]);

	}

    }
  mat1[2][0] = mat1[2][1] = mat1[2][2] = 1;


  printf ("\nEnter the values of tx and ty: ");
  scanf ("%f%f", &tx, &ty);

  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 3; j++)
	{
	  if (i == j)
	    {
	      mat2[i][j] = 1;
	    }
	  else
	    {
	      mat2[i][j] = 0;
	    }
	}
    }
  mat2[0][2] = tx;
  mat2[1][2] = ty;

  int m, n, l;

  for (m = 0; m < 3; m++)
    {
      for (n = 0; n < 3; n++)
	{
	  output[m][n] = 0.0;

	  for (l = 0; l < 3; l++)
	    {
	      output[m][n] += mat2[m][l] * mat1[l][n];
	    }
	}
    }

  printf ("\nThe Result is: \n");

  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 3; j++)
	{
	  printf ("%d\t", output[i][j]);
	}
      printf ("\n");
    }

  return 0;
}
