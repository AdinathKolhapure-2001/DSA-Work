#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n, revN = 0; 
    cin >> n;
    
    // Prime or Non-prime
    
    // bool flag = 0;
    // for(int i = 2; i < sqrt(n); i++) {
    //     if(n%i == 0) {
    //         cout << "Non-prime" << endl;
    //         flag = 1;
    //         break;
    //     }
    // }
    // if(!flag) {
    //     cout << "Prime";
    // }
    
    
    // Reverse a number 
    
    // while(n) {
    //     revN = revN * 10 + n % 10;
    //     n /= 10;
    // }
    // cout << revN << endl;
    
    
    // Armstrong or not (sum of cube of digits = number) 
    
    // int sum = 0, originalN = n;
    // while(n) {
    //     sum += pow(n%10, 3);
    //     n /= 10;
    // }
    // if(sum == originalN) {
    //     cout << "Armstrong" << endl;
    // }
    // else {
    //     cout << "Not Armstrong" << endl;
    // }
    
    
    return 0;
}