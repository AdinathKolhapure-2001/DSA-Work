#include<bits/stdc++.h>

using namespace  std;



// leetcode weekly contest 272:


// problem 5957
string addSpaces(string s, vector<int>& spaces) {   // giving TLE
        int n = spaces.size();
        for(int i = 0; i < n; i++) {
            s.insert(spaces[i] + i, " ");
        }
        return s;
    }
    
    
// problem 5956:    Accepted
bool isPalindrome(string s) {   
        int low = 0, high = s.length() - 1;
        while(low < high) {
            if(s[low++] != s[high--]) {
                return false;
            }
        }
        return true;
        
    }
string firstPalindrome(vector<string>& words) {
        int n = words.size();
        string newStr = "";
        for(int i = 0; i < n; i++) {
            if(isPalindrome(words[i])) {
                newStr = words[i];
                break;
            }
        }
        return newStr;
    }
    
    
// problem 5958:
long long getDescentPeriods(vector<int>& prices) {          // NA
        long long n = prices.size(), k = 2, count = 0, price = 0;
        if(n == 1) {
            return n;
        }
        for(int i = 0; i < n - k + 1; i++){
            for(int j = 0; j < k - 1; j++) {
            price = prices[j] - prices[j + 1];
            if( price == 1) count++;
            }
            for(int m = k; m < n; m++) {
                price = prices[m - k] - prices[k];
                if( price == 1) count++;
                }
                k++;
        }
        
        return n + count;
    }
    

int kIncreasing(vector<int>& nums, int k) { // wrong
        int output=0;
        for(int i=0;i<nums.size()-1;i++){
            if(nums[i]<nums[i+1])
                continue;
            else{
                output=output+(nums[i]+1-nums[i+1]);
                nums[i+1]=nums[i]+1;
            }
        }
        return output;
        
    }

int main()
{
    // string s = "LeetcodeHelpsMeLearn";
    // vector <int> spaces = {8,13,15};
    
    
    // string s = "spacing";
    // vector<int> spaces = {0,1,2,3,4,5,6};
    
    // cout << addSpaces(s, spaces);
    
    
    
    
    // vector<string> words = {"abc","car","ada","racecar","cool"};
    
    // vector<string> words ={"def","ghi"};
    
    // cout << firstPalindrome(words);
    
    
    
    // vector<int> prices = {8,6,7,7};
    
    // cout << getDescentPeriods(prices);
    
    
    
    
    // vector<int> arr = {4,1,5,2,6,2}; int k = 2;
    
    // cout << kIncreasing(arr, k);

    return 0;
}
