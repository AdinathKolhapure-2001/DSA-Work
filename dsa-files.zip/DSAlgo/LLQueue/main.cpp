#include <iostream>
#include <unistd.h>
using namespace std;


struct LLQueue
{
    private:
        
        int data;
        LLQueue* next;
    public:
        ~LLQueue();
        LLQueue* createNode(int);
        void enqueue(int);
        void dequeue();
        bool empty();
        int Front();
        int back();
        void print();
};

LLQueue* front = NULL;
LLQueue* rear = NULL;

LLQueue :: ~LLQueue()
{
    
}


LLQueue* LLQueue :: createNode(int data)
{
    LLQueue* newNode = new LLQueue();
    newNode -> data = data;
    newNode -> next = NULL;
    return newNode;
}


void LLQueue :: enqueue(int data)
{
    LLQueue* newNode = createNode(data);
    if(empty())
    {
        front = rear = newNode;
        return;
    }
    
    rear -> next = newNode;
    rear = newNode;
}


void LLQueue :: dequeue()
{
    LLQueue* temp = NULL;
    if(empty())
    {
        cout << "\nQueue is empty" << endl;
        return;
    }
    else if(front == rear)
    {
        temp = front;
        front = rear = NULL;
    }
    else
    {
        temp = front;
        front = front -> next;
    }
    
    cout << "\nDequeued element is " << temp -> data << endl;
    delete temp;
}


bool LLQueue :: empty()
{
    return front == NULL && rear == NULL;
}


int LLQueue :: Front()
{
    if(empty())
        return -1;
        
    return front -> data;
}


int LLQueue :: back()
{
    if(empty())
        return -1;
        
    return rear -> data;
}


void LLQueue :: print()
{
    if(empty())
    {
        cout << "\nQueue is empty" << endl;
        return;
    }
    
    LLQueue* temp = front;
    while(temp != NULL)
    {
        cout << temp -> data << " | ";
        temp = temp -> next;
    }
    cout << "\n";
}


int main()
{
    
    int x, ch;
    
    LLQueue q;
    
    while(true)
    {
        cout << "\n---------------------------------- Menu ----------------------------------" << endl;
        cout << "\n1. Enqueue\n2. Dequeue\n3. Front\n4. Back\n5. Print\n6. Exit" << endl;
        
        cout << "\nEnter your choice: ";
        cin >> ch;
        
        switch(ch)
        {
            case 1:
                cout << "\nEnter the element: ";
                cin >> x;
                q.enqueue(x);
                break;
                
            case 2:
                q.dequeue();
                break;
                
            case 3:
                x = q.Front();
                if(x != -1)
                {
                    cout << "\nFront element is  " << x << endl;
                }
                else
                {
                    cout << "\nQueue is empty" << endl;
                }
                break;
                
            case 4:
                x = q.back();
                if(x != -1)
                {
                    cout << "\nBack element is  " << x << endl;
                }
                else
                {
                    cout << "\nQueue is empty" << endl;
                }
                break;
                
            case 5:
                q.print();
                break;
                
            case 6:
                cout << "\nTerminating the program...." << endl;
                sleep(1);
                exit(0);
                
            default:
                cout << "\nEnter a valid choice" << endl;
        }
    }
    
    
    
    return 0;
}

