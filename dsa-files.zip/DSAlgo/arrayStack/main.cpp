#include <iostream>

using namespace std;

// Array implementation of stack

struct stack 
{
    private:
        int top;
        int size;
        int* arr;
    public:
        stack(int);
        ~stack();
        void push(int);
        int pop();
        int Top();
        bool isEmpty();
        void print();
};

stack :: stack(int size)
{
    top = -1;
    this -> size = size;
    arr = new int[size];
}

stack :: ~stack()
{
    delete [] arr;
}

void stack :: push(int x)
{
    if(top == size - 1)
    {
        cout << "\nERROR: Stack Overflow" << endl;
        return;
    }
    arr[++top] = x;
}

int stack :: pop()
{
    if(isEmpty())
    {
        cout << "\nERROR: Stack Underflow" << endl;
        return -1;
    }
    return arr[top--];
}

int stack :: Top()
{
    if(isEmpty())
    {
        cout << "\nERROR: Stack Underflow" << endl;
        return -1;
    }
    return arr[top];
}

bool stack :: isEmpty()
{
    return top == -1;
}


void stack :: print()
{
    if(isEmpty())
    {
        cout << "\nERROR: Stack Underflow" << endl;
        return;
    }
    
    cout << "Stack: \n" << endl;
    
    for(int i = top; i >= 0; i--)
    {
        cout << "| " << arr[i] << " |" << endl;
    }
    cout << "|____| " << endl;  
}

int main()
{
    
    int ch, size, x;
    
    cout << "Enter the stack size: ";
    cin >> size;
    
    stack s(size);
    
    while(ch != 5)
    {
        cout << "\n---------------------------------------- Menu ----------------------------------------" << endl;
        cout << "\n1. Push\n2. Pop\n3. Top\n4. Print\n5. Exit" << endl;
        
        cout << "\nEnter your choice: ";
        cin >> ch;
        
        switch(ch)
        {
            case 1:
                cout << "\nEnter the element: ";
                cin >> x;
                s.push(x);
                break;
                
            case 2:
                x = s.pop();
                if(x != -1)
                    cout << "\nPoped element is " << x << endl;
                break;
                
            case 3:
                x = s.Top();
                if(x != -1)
                    cout << "\nTop of stack is " << x << endl;
                break;
                
            case 4:
                s.print();
                break;
            case 5:
                exit(0);
            
            default:
                cout << "\nEnter valid choice" << endl;
        }
    }

    return 0;
}


