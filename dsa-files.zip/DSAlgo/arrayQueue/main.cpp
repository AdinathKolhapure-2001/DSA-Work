#include <iostream>
#include <unistd.h>
using namespace std;


struct queue
{
    private:
        int front;
        int rear;
        int size;
        int* arr;
    public:
        queue(int);
        ~queue();
        void enqueue(int);
        void dequeue();
        int Front();
        int back();
        bool empty();
        bool full();
        void print();
};


queue :: queue(int size)
{
    this -> size = size;
    arr = new int[size];
    front = rear = -1;
}

queue :: ~queue()
{
    delete [] arr;
}


void queue :: enqueue(int x)
{
    if(full())
    {
        cout << "\nQueue is full" << endl;
    }
    else if(empty())
    {
        ++front;
        arr[++rear] = x;
    }
    else
    {
        arr[++rear] = x;
    }
}


void queue :: dequeue()
{
    int temp;
    
    if(empty())
    {
        cout << "\nQueue is empty" << endl;
        return;
    }
    else if(front == rear)
    {
        temp = front;
        
        front = rear = -1;
    }
    else
    {
        temp = front;
        
        front++;
    }
    cout << "\nDequeued element is " << arr[temp] << endl;
}


int queue :: Front()
{
    if(empty())
    {
        return -1;
    }
    return arr[front];
    
}

int queue :: back()
{
    if(empty())
    {
        return -1;
    }
        return arr[rear];
}

bool queue :: empty()
{
    return front == -1 && rear == -1;
}

bool queue :: full()
{
    return rear == size - 1;
}


void queue :: print()
{
    if(empty())
    {
        cout << "\nQueue is empty" << endl;
        return;
    }
    cout << "Queue: ";
    for(int i = front; i <= rear; i++)
    {
        cout << arr[i] << " | ";
    }
    cout << "\n";
}

int main()
{
    int size, x, ch;
    
    cout << "Enter the size of the queue: ";
    
    cin >> size;
    
    queue q(size);
    
    while(true)
    {
        cout << "\n---------------------------------- Menu ----------------------------------" << endl;
        cout << "\n1. Enqueue\n2. Dequeue\n3. Front\n4. Back\n5. Print\n6. Exit" << endl;
        
        cout << "\nEnter your choice: ";
        cin >> ch;
        
        switch(ch)
        {
            case 1:
                cout << "\nEnter the element: ";
                cin >> x;
                q.enqueue(x);
                break;
                
            case 2:
                q.dequeue();
                break;
                
            case 3:
                x = q.Front();
                if(x != -1)
                {
                    cout << "\nFront element is  " << x << endl;
                }
                else
                {
                    cout << "\nQueue is empty" << endl;
                }
                break;
                
            case 4:
                x = q.back();
                if(x != -1)
                {
                    cout << "\nBack element is  " << x << endl;
                }
                else
                {
                    cout << "\nQueue is empty" << endl;
                }
                break;
                
            case 5:
                q.print();
                break;
                
            case 6:
                cout << "\nTerminating the program...." << endl;
                sleep(2);
                exit(0);
                
            default:
                cout << "\nEnter a valid choice" << endl;
        }
    }
    
    
    
    
    
    return 0;
}
