// Find equilibrium index of an array
// Given an integer array, find the equilibrium index in it.

// For an array A consisting n elements, index i is an equilibrium index if the sum 
// of elements of subarray A[0…i-1] is equal to the sum of elements of subarray A[i+1…n-1]. i.e.
// (A[0] + A[1] + … + A[i-1]) = (A[i+1] + A[i+2] + … + A[n-1]), where 0 < i < n-1

// Similarly, 0 is an equilibrium index if A[1] + A[2] + … + A[n-1] sums to 0 and n-1 is an 
// equilibrium index if A[0] + A[1] + … + A[n-2] sums to 0.

// To illustrate, consider the array {0, -3, 5, -4, -2, 3, 1, 0}. The equilibrium index is found at index 0, 3, and 7.

// A naive solution would be to calculate the sum of elements to the left and the sum of elements 
// to each array element’s right. If the left subarray sum is the same as the right subarray sum 
// for an element, print its index. The time complexity of this solution is O(n2), where n is the size of the input.


#include <iostream>

using namespace std;


void bruteFore(int arr[], int size)
{
    int j, k, leftSum, rightSum;
    
    cout << "Equilibrium Index found at: ";
    
    for(int i = 0; i < size; i++)
    {
        leftSum = 0;
        rightSum = 0;
        j = i - 1;
        k = i + 1;
        
        while(j >= 0)
        {
            leftSum += arr[j];
            j--;
        }
        
        while(k < size)
        {
            rightSum += arr[k];
            k++;
        }
        
        if(leftSum == rightSum)
        {
            cout << i << ", ";
        }
    }
}


void findEquilibriumIndex(int arr[], int size)
{
    int left[size];
    
    left[0] = 0;
    
    for(int i = 1; i < size; i++)   // i = 3
    {
        left[i] = left[i - 1] + arr[i - 1]; // 0, 1, 3, 6, 10
    }
    
    // for(int i : left)cout << i << " ";
    
    // `right` stores the sum of elements of subarray `A[i+1…n)`
    int right = 0;
 
    // traverse the array from right to left
    for (int i = size - 1; i >= 0; i--)     // i = 0
    {
        /* If the sum of elements of subarray `A[0…i-1]` is equal to
           the sum of elements of the subarray `A[i+1…n)` i.e.
           `(A[0] + A[1] + … + A[i-1])` = `(A[i+1] + A[i+2] + … + A[n-1])`
        */
 
        if (left[i] == right) {
            printf("Equilibrium Index found at %d\n", i);   // 3
        }
 
        // new right is `A[i] + (A[i+1] + A[i+2] + … + A[n-1])`
        right += arr[i];            // 16
    }
}


int main()
{
    int arr[] = {1, 2, 3, 4, 6};
    int size = sizeof(arr) / sizeof(arr[0]);
    
    // bruteFore(arr, size);
    findEquilibriumIndex(arr, size);
    

    return 0;
}
