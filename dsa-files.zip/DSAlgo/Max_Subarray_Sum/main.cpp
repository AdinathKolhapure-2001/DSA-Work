/*
    Sliding window challenge:
    For a given array and integers k and x, find the 
    maximum sum subarray of size k and having sum less than x
*/

#include <iostream>
#include <climits>                         
                                // k --> 3 --> arr[n - 2]   --> n - k + 1 = 3
using namespace std;            // k --> 2 --> arr[n - 1]


int bruteForce(int arr[], int n, int k, int x)      // Time complexity O(n*k)
{
    if(n < k)
    {
        cout << "Invalid" << endl;
        return -1;
    }
    int a[n - k + 1], sum;                         // 1, 2, 3, 4, 5
    for(int i = 0; i < n - k + 1; i++)
    {
        sum = 0;
        for(int j = i; j < k + i; j++)
        {
            sum += arr[j];
        }
        a[i] = sum;
    }
    
    int _min = INT_MIN;
    for(int i : a)
    {
        
        if(i < x)   _min = max(_min, i);
    }
    
    
    return _min;
}


int maxSubarraySum(int arr[], int n, int k, int x)  // Time complexity O(n)
{
    if(n < k)
    {
        cout << "Invalid" << endl;
        return -1;
    }
    int sum = 0, ans = 0;
    
    for(int i = 0; i < k; i++)
    {
        sum += arr[i];              
    }
    
    if(sum < x) ans = sum;
    
    for(int i = k; i < n; i++)      
    {
        sum = sum - arr[i - k] + arr[i];    
        if(sum < x) 
        {
            ans = max(sum, ans);        
        }
    }
    return ans;
}


int main()
{
    int arr[] = {1, 2, 3, 4, 2, 10, 1, 0, 20};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    cout << "Maximum subarray sum < x (sliding window) = " << maxSubarraySum(arr, size, 4, 20) << endl;
    cout << "Maximum subarray sum < x (brute force) = " << bruteForce(arr, size, 4, 20) << endl;

    return 0;
}


