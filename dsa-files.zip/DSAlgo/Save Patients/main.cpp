#include <iostream>
using namespace std;


// Problem
// A new deadly virus has infected large population of a planet. 
// A brilliant scientist has discovered a new strain of virus 
// which can cure this disease. Vaccine produced from this virus 
// has various strength depending on midichlorians count. A person 
// is cured only if midichlorians count in vaccine batch is more than 
// midichlorians count of person. A doctor receives a new set of report 
// which contains midichlorians count of each infected patient, Practo 
// stores all vaccine doctor has and their midichlorians count. 
// You need to determine if doctor can save all patients with the 
// vaccines he has. The number of vaccines and patients are equal.


// Input Format

// First line contains the number of vaccines - N. Second line contains N integers, 
// which are strength of vaccines. Third line contains N integers, which are midichlorians count of patients.


// Output Format

// Print a single line containing "YES" or "NO".

// Input Constraint

// 1 < N < 10

// Strength of vaccines and midichlorians count of patients fit in integer

// Sample Input                         Sample Output
// 5
// 123 146 454 542 456                      "NO"
// 100 328 248 689 200

void bubbleSort(int count, int mid_vac[], int mid_pat[])
{
    for(int i = 0; i < count - 1; i++)
    {
        for(int j = 0; j < count - i - 1; j++)
        {
            if(mid_vac[j] > mid_vac[j + 1])
            {
                swap(mid_vac[j], mid_vac[j + 1]);
            }
            
            if(mid_pat[j] > mid_pat[j + 1])
            {
                swap(mid_pat[j], mid_pat[j + 1]);
            }
        }
    }
}


void selectionSort(int count, int mid_vac[], int mid_pat[])
{
    for(int i = 0; i < count; i++)
    {
        int imin = i;
        int jmin = i;
        for(int j = i + 1; j < count; j++)
        {
            if(mid_vac[imin] > mid_vac[j])
            {
                imin = j;
            }
            if(mid_pat[jmin] > mid_pat[j])
            {
                jmin = j;
            }
        }
        swap(mid_vac[imin], mid_vac[i]);
        swap(mid_pat[jmin], mid_pat[i]);
    }
}



bool canSave(int count, int mid_vac[], int mid_pat[])
{
    // bubbleSort(count, mid_vac, mid_pat);
    selectionSort(count, mid_vac, mid_pat);
    
    // for(int i = 0; i < count; i++)
    // {
    //     cout << mid_vac[i] << " ";
    // }
    // cout << "\n";
    // for(int i = 0; i < count; i++)
    // {
    //     cout << mid_pat[i] << " ";
    // }
    
    bool result;
    for(int i = 0; i < count; i++)
    {
        result = false;
        
        if(mid_vac[i] > mid_pat[i])
        {
            result = true;
        }
        else
        {
            result = false;
            break;
        }
    }
    
    return result;
    
}



int main()
{
    int count = 5;
    int mid_vac[] = {123, 146, 454, 542, 456};
    int mid_pat[] = {100, 328, 248, 689, 200};
    
    if(canSave(count, mid_vac, mid_pat))
    {
        cout << "YES" << endl;
    }
    else
    {
        cout << "NO" << endl;
    }
    
    return 0;
}


