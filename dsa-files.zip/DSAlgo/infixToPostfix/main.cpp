#include <iostream>
#include <stack>

using namespace std;


bool isOpeningBracket(char c)
{
    return (c == '(' || c == '{' || c == '[');
}

bool isClosingBracket(char c)
{
    return (c == ')' || c == '}' || c == ']');
}



bool checkExpression(string expression)
{
    stack<char> s;
    int n = expression.length();
    char x;
    
    for(int i = 0; i < n; i++)
    {
        if(expression[i] == ' ')
        {
            continue;
        }
        else if(isOpeningBracket(expression[i]))
        {
            s.push(expression[i]);
        }
        else if(!isOpeningBracket(expression[i]) && !isClosingBracket(expression[i]))
        {
            continue;
        }

        if(s.empty())
        {
            return false;
        }
        
        switch(expression[i])
        {
            case ')':
                x =s.top();
                s.pop();
                if(x == '[' || x == '{' || x == '<')
                    return false;
                break;
                
            case ']':
                x =s.top();
                s.pop();
                if(x == '(' || x == '{' || x == '<')
                    return false;
                break;  
                
            case '}':
                x =s.top();
                s.pop();
                if(x == '[' || x == '(' || x == '<')
                    return false;
                break;
                
            case '>':
                x =s.top();
                s.pop();
                if(x == '[' || x == '{' || x == '(')
                    return false;
                break;
        }
    }
    
    return s.empty();
    
}


int precedence(char c)
{
    switch(c)
    {
        case '+':
            return 0;
            break;
            
        case '-':
            return 0;
            break;
        
        case '*':
            return 1;
            break;
            
        case '/':
            return 1;
            break;
            
        default:
            return -1;
    }
}



string infixToPostfix(string expr, bool isPrefix = false)
{
    string res = "";
    stack<char> s;
    
    if(checkExpression(expr))
    {
        for(int i = 0; i < expr.length(); i++)
        {
            if(expr[i] == ' ')      // If the char is space then skip that char 
            {
                continue;
            }
            else if(isalpha(expr[i]))       // If the char is an alphabet then append it to res string
            {
                res += expr[i];
            }
            else if(isOpeningBracket(expr[i]))  // If char is an opening bracket then push it into the stack 
            {
                s.push(expr[i]);
            }
            else if(isClosingBracket(expr[i]))      // if char is closing barcket then pop all the operators and append 
            {                                       // it to the res string till you encounter an opening bracket then pop that opening bracket
                while(!s.empty() && !isOpeningBracket(s.top()))
                {
                    res += s.top();
                    s.pop();
                }
                s.pop();            // To remove opening bracket 
            }
            else                // If char is an operator then pop all the operator from the stack and append to the res string
            {                   // which has precedence greater than or equal to the char, then push that char into the stack 
            
                if(isPrefix)    // Note: for prefix conversion we need to consider strict precedence
                {
                    while(!s.empty() && precedence(s.top()) > precedence(expr[i]))
                    {
                        res += s.top();
                        s.pop();
                    }
                }
                else
                {
                    while(!s.empty() && precedence(s.top()) >= precedence(expr[i]))
                    {
                        res += s.top();
                        s.pop();
                    }
                }
                s.push(expr[i]);    // push the incoming operator  
            }
        }
        
        while(!s.empty())       // If stack contains some operators, then append it to the res string
        {
            res += s.top();
            s.pop();
        }
        
        return res; 
    }
    
    return "Expression is not valid";
    
}

void reverse(string& expr)
{
    int start = 0;
    int end = expr.length() - 1;
    
    while(start < end)
    {
        swap(expr[start++], expr[end--]);
    }
}

string infixToPrefix(string expr)
{
    reverse(expr);                              // reverse the given Expression
                                                // Make every opening bracket as closing and vice verse 
    for(int i = 0; i < expr.length(); i++)      // Convert reversed expression to Postfix from
    {                                           // Again reverse the postfix expression that will be the final prefix expression
        if(isOpeningBracket(expr[i]))           // Note: for prefix conversion we need to consider strict precedence
        {
            switch(expr[i])
            {
                case '(':
                    expr[i] = ')';
                    break;
                    
                case '{':
                    expr[i] = '}';
                    break;
                    
                case '[':
                    expr[i] = ']';
                    break;
                
            }
        }
        else if(isClosingBracket(expr[i]))
        {
            switch(expr[i])
            {
                case ')':
                    expr[i] = '(';
                    break;
                    
                case '}':
                    expr[i] = '{';
                    break;
                    
                case ']':
                    expr[i] = '[';
                    break;
                
            }
        }
    }
    
    expr = infixToPostfix(expr, true);
   
    reverse(expr);
    
    return expr;
}


int main()
{
    string expr, res;
    
    cout << "Enter the Infix expression: ";
    
    getline(cin, expr);
    
    res = infixToPostfix(expr);
    
    cout << "Postfix expression: " << res << endl;

    res = infixToPrefix(expr);
    
    cout << "Prefix expression: " << res << endl;
    
    return 0;
}



