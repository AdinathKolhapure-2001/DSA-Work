#include <iostream>
#include <stack>

using namespace std;

int main()
{
    stack<char> s;
    
    string str;
    
    cout << "Enter the string: ";
    
    cin >> str;
    
    for(char c : str)
    {
        s.push(c);
    }
    
    for(int i = 0; i < str.length(); i++)
    {
        str[i] = s.top();
        s.pop();
    }

    for(int i = 0; i < str.length(); i++)
    {
        cout << str[i];
    }
    return 0;
}
