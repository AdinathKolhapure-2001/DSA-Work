#include <iostream>
#include <stack>

using namespace std;


// Expression evaluation -->  1. Prefix Expression evaluation (Polish Notation)
//                            2. Postfix Expression evaluation (Reverse Polish Notation)

// 1. Postfix Expression evaluation:
// Scan the Expression left to right
// if you encounter a number push into the stack
// if you encounter an operator then pop two numbers from the stak and 
// perform second number operator first number and push the result back into the stack do this till end of Expression
// pop the the last number that will be the final answer.

// 2. Prefix Expression evaluation:
// Scan the Expression right to left 
// if you encounter a number push into the stack
// if you encounter an operator then pop two numbers from the stak and 
// perform firs number operator second number and push the result back into the stack do this till end of Expression
// pop the the last number that will be the final answer.


//create an object of stack

stack<int> s;


int calculateResult(char oper, int x, int y)
{
    switch(oper)
    {
        case '+':
            return x + y;
            break;
        case '-':
            return x - y;
            break;
        case '*':
            return x * y;
            break;
        case '/':
            return x / y;
    }
    return -1;
}

int postfixEvaluation(string expr)
{
    int x, y, res;
    
    while(!s.empty())
    {
        s.pop();
    }
    
    for(int i = 0; i < expr.length(); i++)
    {
        if(isdigit(expr[i]))    // check whether expr[i] is a number 
        {
            s.push(expr[i] - '0');
        }
        else
        {
            y = s.top();
            s.pop();
            x = s.top();
            s.pop();
            
            res = calculateResult(expr[i], x, y);
            
            s.push(res);
        }
    }
    
    return s.top();
}


int prefixEvaluation(string expr)
{
    int x, y, res;
    
    while(!s.empty())
    {
        s.pop();
    }
    
    for(int i = expr.length() - 1; i >= 0; i--)
    {
        if(isdigit(expr[i]))    // check whether expr[i] is a number 
        {
            s.push(expr[i] - '0');
        }
        else
        {
            x = s.top();
            s.pop();
            y = s.top();
            s.pop();
            
            res = calculateResult(expr[i], x, y);
            
            s.push(res);
        }
    }
    
    return s.top();
}



int main()
{
    string expr, expr1;
    
    // Dont give space in Expression
    // Expression must not contain any kind of brackets
    // Here I am assuming that the entered Expression is valid
    
    cout << "\nEnter the Postfix Expression: ";
    
    cin >> expr;
    
    cout << "\nResult of Postfix evaluation is = " << postfixEvaluation(expr) << endl;
    
    cout << "\nEnter the Prefix Expression: ";
    
    cin >> expr1;
    
    cout << "\nResult of Postfix evaluation is = " << prefixEvaluation(expr1) << endl;
    
    
    //  Infix : ((2 * (2 + 3) / 5)) - 2 * (3 + 5 / 5)  = 2 - 8   =   -6
    
    // Prefix : - / * 2 + 2 3 5 2 * 2 + 3 / 5 5     -->  - * 2 / + 2 3 5 2 * 2 + 3 / 5 5
    
    // Postfix : 2 2 3 + * 5 / 2 3 5 5 / + * -   -->    2 2 3 + 5 / * 2 3 5 5 / + * -
    
    

    return 0;
}

