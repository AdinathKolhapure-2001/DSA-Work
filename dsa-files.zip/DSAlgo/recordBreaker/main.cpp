#include <iostream>
#include <climits>

using namespace std;


// Katrina is given the number of visitors at her local park on N consecutive days.
// The number of visitors on the i-th day i Vi. A day is a record breaking if it satifies both of the 
// following conditions:
// 1. The number of visitors on the day is strictly larger than the number of visitors on each 
// of the previous days.
// 2. Either it is the last day or the number of visitors on the day is strictly larger than the 
// number of visitors on the following day.

// Note that the very first day could be a record breaking day.
// Plese help Katrina to find out the number of record breaking days.


int recordBreaker(int arr[], int size)
{
    int n = 0;
    int mx = INT_MIN;
    
    for(int i = 0; i < size; i++)
    {
        if(arr[i] > mx && arr[i] > arr[i + 1])
        {
            n++;
        }
        mx = max(mx, arr[i]);
    }
    
    return n;
}


int bruteForce(int arr[], int size)
{
    int n = 0;
    bool flag;
    
    for(int i = 0; i < size; i++)       // i = 3
    {
        if(i == 0 && arr[i] > arr[i + 1])   // n = 2
        {
            n++;
        }
        else
        {
            for(int j = i - 1; j >= 0; j--) // j = 1
            {
                flag = false;
                
                if(arr[i] > arr[j] && arr[i] > arr[i + 1])
                {
                    flag = true;
                }
                else
                {
                    break;
                }
            }
            
            if(flag)
            {
                n++;
            }
        }
        
    }
    
    return n;
}

int main()
{
    int arr[] = {1, 2, 0, 7, 2, 0, 2, 2, INT_MIN};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    // int n = recordBreaker(arr, size - 1);
    int n = bruteForce(arr, size - 1);
    
    cout << "Number of record breaking days = " << n << endl;

    return 0;
}

