#include <iostream>

using namespace std;

// DNF --> Dutch National Flag
// 0, 2, 1, 0, 1, 2, 0, 1, 2, 0, 0
//    zeors   ones    unknown    twos
// 0 0 0 0  1 1 1 1   ? ? ? ?   2 2 2 2 


// set three pointers
// low, mid, high

// low = 0, mid = 0, high = size - 1

// traverse the array 
// chech arr[mid]

// if 0 --> swap(arr[low], arr[mid]) low++, mid++;
// if 1 --> mid++
// if 2 --> swap(arr[mid], arr[high]) high--;

// 0  1  2  3  4  5  6
// 0, 0, 0, 1, 1, 2, 2


// low = 3; mid = 5; high = 5
// arr[mid] = 2
// while(mid <= high) mid = 5; high = 5

void DNFSort(int arr[], int size)
{
    int low = 0, mid = 0, high = size - 1;
    
    while(mid <= high)
    {
        switch(arr[mid])
        {
            case 0:
                swap(arr[low++], arr[mid++]);
                break;
            case 1:
                mid++;
                break;
            case 2:
                swap(arr[mid], arr[high--]);
        }
    }
}


void RGBSort(char arr[], int size)
{
    int low = 0, mid = 0, high = size - 1;
    
    while(mid <= high)
    {
        switch(arr[mid])
        {
            case 'R':
                swap(arr[low++], arr[mid++]);
                break;
            case 'G':
                mid++;
                break;
            case 'B':
                swap(arr[mid], arr[high--]);
        }
    }
}

int main()
{   
    int arr[] = {2, 0, 2, 1, 0, 1, 2, 0, 1, 2, 0, 1};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    DNFSort(arr, size);
    
    for(int i : arr)    cout << i << " ";
    
    // cout << "\n";
    
    // {R, G, R, B, R, G ,B}  --> R G B
    
    // char RGB[] = {'G', 'R', 'G', 'R', 'G', 'B', 'R','B', 'G', 'B'};
    
    // int size1 = sizeof(RGB) / sizeof(RGB[0]);
    
    // RGBSort(RGB, size1);
    
    // for(char i : RGB)   cout << i << " ";
    
    return 0;
}
