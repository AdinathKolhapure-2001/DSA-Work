#include <iostream>

using namespace std;



int main()
{
    // subarray : Contiguous part of the array(include atleat one element)
    
    // 1, 2, 3, 4  --> {1, 2}, {2, 3, 4}, {1, 2, 3, 4}, {3, 4}, {1, 2, 3}, {2, 3}, {1}, {2}, {3}, {4}
    
    
    // sub-sequence : A sequence of numbers from the array(Here order does not matter)
    
    // 1, 2, 3, 4  --> {1}, {2}, {3}, {4}, {1, 2}, {1, 2, 3}, {1, 2, 3, 4}, {2, 3}, {2, 3, 4}, {3, 4}, {1, 3}, {1, 4}, {2, 4}, {1, 2, 4}, {1, 3, 4}

    
    // subarray vs sub-sequence
    
    // every subarray is a sub-sequence but vice versa is not true 
    
    // n = 4;
    
    // possible subarray of length n = nC2 + n = (n * (n + 1)) / 2  = 10
    
    // 1
    // 2 
    // 3 
    // 4
    // 1, 2 
    // 1, 2, 3 
    // 1, 2, 3, 4
    // 2, 3
    // 2, 3, 4
    // 3, 4
    

    // n! / (n - 2)!*2! = n * (n- 1) * (n - 2)! /  (n - 2)! * 2! + n  = (n * n (n - 1) / 2) + n = (n * (n - 1) + 2n) / 2 = (n^2 - n + 2n ) / 2 = n * (n + 1) / 2
    
    
    // possible sub-sequence of length n = 2^n - 1
    
    // 1, 2, 3
    
    
    // 1 
    // 2 
    // 3 
    // 1, 2 
    // 1, 2, 3 
    // 1, 3 
    // 2, 3 
    
    
    
    // subarray
    
    // 1, 2, 3
    
    // 1 = 1
    // 2 = 2
    // 3 = 3
    // 1, 2 = 3
    // 1, 2, 3 = 6
    // 2, 3 = 5
    
    //       j
    // 1, 2, 3      Sum = 3
    //       i 
    
    // Sum of all the subarray
    // sum += arr[j]  // 3 
    // cout << sum;   // 1  3  6    2   5   3
    
    // int arr[] = {1, 2, 3};
    
    // int size = sizeof(arr)/ sizeof(arr[0]);
    
    // int sum = 0;
    // for(int i = 0; i < size; i++)
    // {
    //     sum = 0;
    //     for(int j = i; j < size; j++)
    //     {
    //         sum += arr[j];
    //         cout << sum << endl;
    //     }
        
    //     cout << "\n";
    // }
    
    
    // Maximum sum subarray 
    
    // currSum = 0; 
    // maxSum = 0;
    
    // j
    // 2, 0, -1, -3, 4, 1, -1  --> nC2 + 2 = n*(n + 1) / 2  = (7 * 8) / 2 = 28
    // i
    
    // ex. -1, 4, 0, 1, -2, 3, 0, -3, 2  --> 6
    
    // currSum += arr[j]; // -1
    // maxSum = max(maxSum, currSum); // 5   
    //                  5  , -1
    
    
    // cout << maxSum << endl;
    
    
    // int arr[] = {2, 0, -1, -3, 4, 1, -1};  //  --> 5
    // int size = sizeof(arr)/ sizeof(arr[0]);
    // int currSum = 0; 
    // int maxSum = 0;
    
    // for(int i = 0; i < size; i++)               // O(n^2)
    // {
    //     currSum = 0;
    //     for(int j = i; j < size; j++)
    //     {
    //         currSum += arr[j];
    //         maxSum = max(maxSum, currSum);
    //     }
    // }
    
    // cout << maxSum << endl;
    
    // -2, -3, 4, -1, -2, 1, 5, -3  --> 7
    
    // Kadane's algorithm --> Used to find Maximum sum subarray
    
    // int arr[] = {-2, -3, 4, -1, -2, 1, 5, -3};   // start_index = 2, end_index = 6;
    // int size = sizeof(arr)/ sizeof(arr[0]);
    
    // for(int i = 0; i < size; i++)   // i =  7         // O(n)
    // {
    //     currSum += arr[i];          // 4
    //     maxSum = max(maxSum, currSum);  // 7
        
    //     if(currSum < 0)
    //     {
    //         currSum = 0;
    //     }
        
    // }
    
    // cout << maxSum << endl;
    
    
    
    // 2, 0, -3, -1, 2, 0, -1, 3  
    
    
    // printing all the subarrays
    
    // int arr[] = {1, 2, 3}; 
    
    // for(int i = 0; i < 3; i++)
    // {
    //     for(int j = i; j < 3; j++)
    //     {
    //         for(int k = i; k <= j; k++)
    //         {
    //             cout << arr[k] << " ";
    //         }
    //         cout << "\n";
    //     }
        
    //     cout << "\n";
    // }
    
    
    
    // Warning : This will work in C only  
    
    // int arr[] = {1, 2, [12] = 16, [4] = 2, [9] = -6, [5] = 10};      // If you specify an element after highest initilizer 
                                                                        // It will consider that as the last element and size will also get change
    // // {0, 0, 0, 0, 2, 10, 0, 0, 0, -6, 0, 0, 0, 0, 16}
    // int size = sizeof(arr) / sizeof(arr[0]);
    // printf("\nSize of the array: %d\n", size);
    
    // for(int i = 0; i < size; i++)
    // {
    //     printf("%d ", arr[i]);
        
    // }
    
    
    
    
    
    
    
    return 0;
}



