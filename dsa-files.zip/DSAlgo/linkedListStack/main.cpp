#include <iostream>

using namespace std;

// Linked Lisrt implementation of stack

struct stack
{
    private:
        int data;
        stack* next;
        stack* top;
    public:
        stack();
        ~stack();
        void push(int);
        int pop();
        int Top();
        bool isEmpty();
        void print();
};


stack :: stack()
{
    next = NULL;
    top = NULL;
}


stack :: ~stack()
{
    cout << "\nDestructor called" << endl;
    delete next, top;
}


void stack :: push(int x)
{
    // malloc() vs new(): 

    // malloc(): It is a C library function that can also be used in C++, 
    // while the “new” operator is specific for C++ only. 

    // Both malloc() and new are used to allocate the memory dynamically in heap. 
    // But “new” does call the constructor of a class whereas “malloc()” does not.
    
    stack* newNode = new stack();
    newNode -> data = x;
    newNode -> next = top;
    top = newNode;
}


int stack :: pop()
{
    // free() vs delete: 
    
    // free() is a C library function that can also be used in C++, while “delete” is a C++ keyword.
    
    // free() frees memory but doesn’t call Destructor of a class whereas “delete” frees the memory and 
    // also calls the Destructor of the class.
    
    if(isEmpty())
    {
        cout << "\nERROR: Stack Underflow" << endl;
        return -1;
    }
    stack* temp = top;
    top = top -> next;
    int x = temp -> data;
    free(temp);
    return x;
}


int stack :: Top()
{
    if(isEmpty())
    {
        cout << "\nERROR: Stack Underflow" << endl;
        return -1;
    }
    return top -> data;
}


bool stack :: isEmpty()
{
    return top == NULL;
}


void stack :: print()
{
    if(isEmpty())
    {
        cout << "\nERROR: Stack Underflow" << endl;
        return;
    }
    
    cout << "\nStack: " << endl;
    stack* temp = top;
    while(temp != NULL)
    {
        cout << "| " << temp -> data << " |" << endl;
        temp = temp -> next;
    }
    cout << "|____|" << endl;
}


int main()
{
    int ch, x;

    stack s;
    
    
    while(ch != 5)
    {
        cout << "\n---------------------------------------- Menu ----------------------------------------" << endl;
        cout << "\n1. Push\n2. Pop\n3. Top\n4. Print\n5. Exit" << endl;
        
        cout << "\nEnter your choice: ";
        cin >> ch;
        
        switch(ch)
        {
            case 1:
                cout << "\nEnter the element: ";
                cin >> x;
                s.push(x);
                break;
                
            case 2:
                x = s.pop();
                if(x != -1)
                    cout << "\nPoped element is " << x << endl;
                break;
                
            case 3:
                x = s.Top();
                if(x != -1)
                    cout << "\nTop of stack is " << x << endl;
                break;
                
            case 4:
                s.print();
                break;
            case 5:
                exit(0);
            
            default:
                cout << "\nEnter valid choice" << endl;
        }
    }

    return 0;
}
