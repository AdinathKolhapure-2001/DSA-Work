#include <stdio.h>
#define SIZE 5


void rowColumnSum()
{
    int arr[SIZE][SIZE];
    
    for(int i = 0; i < SIZE; i++)
    {
        printf("Enter row %d: ", i + 1);
        
        for(int j = 0; j < SIZE; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }
    
    // Row sum 
    
    int sum;
    
    printf("\nRow Total: ");
    
    for(int i = 0; i < SIZE; i++)
    {
        sum = 0;
        for(int j = 0; j < SIZE; j++)
        {
            sum += arr[i][j];
        }
        printf("%d ", sum);
    }
    
    printf("\n");
    
    printf("\nColumn Total: ");
    
    for(int i = 0; i < SIZE; i++)
    {   
        sum = 0;
        for(int j = 0; j < SIZE; j++)
        {
            sum += arr[j][i];
        }
        printf("%d ", sum);
    }
    
    printf("\n");
}

int main()
{
    
    // 1. Designated initializers:
    // lets say we want an array that contains some numbers at some index and rest 0's
    // in such case we can make use of designated initializers, systax is as follows
    // data_type array_name[size] = {[index] = number, ....., }
    // Here no need to fill zeros those will get filled automatically
    // We can have combination of regula array and designated initializers like
    // data_type array_name[size] = {5, 6, [index] = number, 8, ....., }
    // designated initializers have higher priority that regular index i.e 
    // int arr[5] = {2, 4, 5, [2] = 3, 7} then at 2nd index 3 get stored(5 get overwritten)
    // then array will look like this  {2, 4, 3, 7, 0}
    // while declaring the array if we do not specify size then the highest designated index + 1 is considered as the array size
    // i.e int arr[] = {[2] = 8, [7] = 6, [12] = 45, [3] = 7} then array size will be 13 (highest designated index = 12)
    // here the order of designated index does not matter
    
    // int arr[10] = {[7] = 10, [0] = 1, [5] = 4, [3] = 16};
    
    // // int arr[5] = {2, 4, 5, [2] = 3, 7};
    
    // // int arr[] = {[2] = 8, [7] = 6, [12] = 45, [3] = 7};
    
    // int size = sizeof(arr) / sizeof(arr[0]);
    
    // printf("Size of an array: %d\n", size);
    
    // for(int i = 0; i < size; i++) 
    // {
    //     printf("%d ", arr[i]);
    // }
    
    
    
    // 2. Write a program to check whether any of the digit in a number appears more than one 
    
    
    // int num, rem;
    // int seen[10] = {0};      // we have declared an array of size 10 because we have 10 numbers 0 - 9
    //                         // all indexes get initializes to 0's
    // printf("\nEnter the number: ");
    // scanf("%d", &num);
    
    // while(num > 0)
    // {
    //     rem = num % 10;     // Access the unit place digit
    //     if(seen[rem] == 1)   // if we already visited this index then value at that index must be 1
    //         break;          // if so then break out from the loop. In this case the value of num > 0 
    //     seen[rem] = 1;      // if the first conditon is not true then set the value at index rem to 1 (visited)
    //     num /= 10;          // then eliminate the unit place digit by dividing it by 10
    // }                       // the second case we break out from the loop is when num value becomes = 0 (i.e no digit repeated)
    
    // if(num > 0)             // if the first case if true then this conditon is true 
    //     printf("\nYes");
    // else
    //     printf("\nNo");
    
    
    
    // 3. Multi-dimentional arrays
    // Multi-dimentional array can be defined as array of arrays
    // General form of defining N dimentional arrar is as follows:
    // data_type array_name[size1][size2].....[sizeN];
    // ex. int arr1[3][4];  Two dimentional array  
    // int arr2[2][3][4];   Three dimentional array
    
    
    // 3.0 2-dimentional array
    // 2D array can be declared as data_type array_name[size1][size2] = {elements};
    // ex. int arr[2][3] = {1, 2, 3, 4, 5, 6}   Its bit confusing a better way is as follows:
    // int arr[2][3] = {{1, 2, 3}, {4, 5, 6}};
    
    // 3.0.0 Pinting the elements of 2D array 
    // for printing 2D array we need nested for loop as follows
    
    // int arr[2][3] = {{1, 2, 3}, {4, 5, 6}};
    
    // for(int i = 0; i < 2; i++)
    // {
    //     for(int j = 0; j < 3; j++)
    //     {
    //         printf("%d ", arr[i][j]);
    //     }
    //     printf("\n");
    // }
    
    // 3.1 3-dimentional array
    // 3D array is declared as data_type array_name[size1][size2][size3] = {elements};
    // int arr[2][2][3] = {{{1, 2, 3}, {4, 5, 6}}, {{7, 8, 9}, {10, 11, 12}}};
    // It can be visualize as, 2 2D array having dimentions (2, 3)
    
    // 3.1.0 printing the elements of 3D array 
    // In order to print the elements of 3D array we need 3 for loops(nested)
    
    // int arr[2][2][3] = {{{1, 2, 3}, {4, 5, 6}}, {{7, 8, 9}, {10, 11, 12}}};
    
    // for(int i = 0; i < 2; i++)
    // {
    //     for(int j = 0; j < 2; j++)
    //     {
    //         for(int k = 0; k < 3; k++)
    //         {
    //             printf("%d ", arr[i][j][k]);
    //         }
    //         printf("\n");
    //     }
    //     printf("\n");
    // }
    
    
    
    // 4. Write a program that reads a 5x5 array of integers and then print the row sum and column sum
    // Enter row 1: 8 3 9 0 10
    // Enter row 2: 3 5 17 1 1
    // Enter row 3: 2 8 6 23 1 
    // Enter row 4: 15 7 3 2 9
    // Enter row 5: 6 14 2 6 0 
    
    // Row Total: 30 27 40 36 28
    
    // Column Total: 34 37 37 32 21
    
    // rowColumnSum();
    

    
    
    
    
    
    

    return 0;
}



