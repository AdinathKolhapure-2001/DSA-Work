#include <iostream>

using namespace std;

// 3 most important questions on linked list 
// 1. Find and delete the nth node from the end of the linked List
// 2. Check if the linked List is Palindrome
// 3. Detect and remove the cycle in a linked List



struct linkedList
{
    private:
        int data;
        linkedList* next;
    public:
        // linkedList* next;   // This is for 3 problem
        linkedList* createNode(int);
        linkedList* addLast(linkedList*, int);
        linkedList* removeNthFromEnd(linkedList*, int);
        linkedList* reverse(linkedList*);
        linkedList* getMiddle(linkedList*);
        bool isPalindrome(linkedList*);
        linkedList* hasCycle(linkedList*);
        void removeCycle(linkedList*);
        int printNthFromLast(linkedList*, int);
        void print(linkedList*);
        
};


linkedList* linkedList :: createNode(int data)
{
    linkedList* newNode = (linkedList*)malloc(sizeof(linkedList));
    newNode -> data = data;
    newNode -> next = NULL;
    return newNode;
}

linkedList* linkedList :: addLast(linkedList* head, int data)
{
    linkedList* newNode = createNode(data);
    if(head == NULL)
    {
        head = newNode;
        return head;
    }
    
    linkedList* temp = head;
    
    while(temp -> next != NULL)
    {
        temp = temp -> next;
    }
    
    temp -> next = newNode;
    
    return head;
}


void linkedList :: print(linkedList* head)
{
    if(head == NULL)
    {
        cout << "\nLinked List is empty" << endl;
        return;
    }
    // print the list 
    while(head != NULL)
    {
        cout << head -> data << " --> ";
        head = head -> next;
    }
    cout << "\n";
}


// create your functions from here


linkedList* linkedList :: removeNthFromEnd(linkedList* head, int n)
{
    if(head == NULL)
    {
        return head;
    }
    
    int size = 0;
    
    linkedList* temp = head;
    
    while(temp != NULL)     // calculate the size of the linked List
    {
        size++;
        temp = temp -> next;
    }
    
    if(n == size)       // n == size then we need to delete head node and return the next of head node
    {
        temp = head;
        head = head -> next;
        free(temp);
        return head;
    }
    else if(n > size)       // This is no valid condition
    {
        cout << "N is greater than the size" << endl;
        return head;
    }
     
    int indexToSearch = size - n;   // we need to find the previous node of the node to delete
    linkedList* prev = head;
    int i = 1;
    
    
    while(i < indexToSearch) // 3 < 3
    {
        prev = prev -> next;    // 3
        i++;
    }
    
    temp = prev -> next;    // 4
    prev -> next = prev -> next -> next;
    free(temp);
    
    return head;
}


linkedList* linkedList :: reverse(linkedList* head)
{
    linkedList* prev = NULL;
    linkedList* curr = head;
    linkedList* next = NULL;
    
    while(curr != NULL)
    {
        next = curr -> next;
        curr -> next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}


linkedList* linkedList :: getMiddle(linkedList* head)
{
    linkedList* slow = head;
    linkedList* fast = head;
    
    while(fast -> next != NULL && fast -> next -> next != NULL)
    {
        slow = slow -> next;
        fast = fast -> next -> next;
    }
    return slow;
}

bool linkedList :: isPalindrome(linkedList* head)
{
    // Find the middle of the linked list 
    // Reverse the second half of the linked list 
    // compare the first and second half
    
    if(head == NULL || head -> next == NULL)
    {
        return true;
    }
    
    linkedList* middle = getMiddle(head);
    
    linkedList* secondHalfHead = reverse(middle -> next);
    
    while(secondHalfHead != NULL)
    {
        if(head -> data != secondHalfHead -> data)
        {
            return false;
        }
        head = head -> next;
        secondHalfHead = secondHalfHead -> next;
    }
    
    return true;
}


linkedList* linkedList :: hasCycle(linkedList* head)
{
    if(head == NULL)
    {
        return head;
    }
    
    linkedList* slow = head;
    linkedList* fast = head;
    
    while(fast != NULL && fast -> next != NULL)
    {
        slow = slow -> next;
        fast = fast -> next -> next;
        
        if(slow == fast)
        {
            return slow;
        }
    }
    return NULL;
}


void linkedList :: removeCycle(linkedList* head)
{
    linkedList* meetingNode = hasCycle(head);

    if(head == NULL || meetingNode == NULL)
    {
        return;
    }
    cout << "\nlinkedList has a cycle" << endl;
    linkedList* prev = NULL;
    
    while(head != meetingNode)
    {
        head = head -> next;
        prev = meetingNode;
        meetingNode = meetingNode -> next;
    }
    
    prev -> next = NULL;
}


int linkedList :: printNthFromLast(linkedList* head, int n)
{
	int i = 0;
	if (head == NULL)
		return i;
	i = printNthFromLast(head->next, n);
	if (++i == n)
		cout<<head->data;
	return i;
}


int main()
{
    
   
    linkedList l;
    linkedList* head = NULL;
    // linkedList* Node2 = NULL;
    // linkedList* Node3 = NULL;
    // linkedList* Node4 = NULL;
    // linkedList* Node5 = NULL;
    // linkedList* Node6 = NULL;
   
   
   
   // 1. Find and delete the nth node from the end of linked list
   
    // head = l.addLast(head, 10);
    // l.addLast(head, 25);
    // l.addLast(head, 37);
    // l.addLast(head, 43);
    // l.addLast(head, 54);
    //                     //                s           f
    // l.print(head);   // 1 --> 2 --> 3 --> 4 --> 5 --> NULL
   
    // int n = 2;   // delete the second last node fron the linked list (i.e 4)
   
    // head = l.removeNthFromEnd(head, n);
   
    // l.print(head);
    
    
    // 2. Check if the linked List is Palindrome
    
    // head = l.addLast(head, 1);
    // l.addLast(head, 2);
    // l.addLast(head, 3);
    // l.addLast(head, 2);
    // l.addLast(head, 1);
    
    // l.print(head);
    
    // l.isPalindrome(head) ? cout << "Linked list is palindrome" : cout << "Linked list is not palindrome";
    
    
    // 3. Detect and remove the cycle in a linked List 
    
    // head = l.createNode(1);
    // Node2 = l.createNode(2);
    // Node3 = l.createNode(3);
    // Node4 = l.createNode(4);
    // Node5 = l.createNode(5);
    // Node6 = l.createNode(6);
    
    // head -> next = Node2;
    // Node2 -> next = Node3;
    // Node3 -> next = Node4;
    // Node4 -> next = Node5;
    // Node5 -> next = Node6;
    // Node6 -> next = Node3;
    
    // // l.print(head);      // It will go in infinite loop
    
    // l.removeCycle(head);
    
    // l.print(head);
    
    // l.printNthFromLast(head, 3);
    
    return 0;
}



