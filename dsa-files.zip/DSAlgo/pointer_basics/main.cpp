#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    // 0 syntax : data_type* name = address_of_vsriable
    
    // int a = 5;
    
    // int* p = &a;
    
    // cout << "a = " << a << ", *p = " << *p << ", *&a = " << *&a << endl;    // These all are same, it gives the value of a
    
    // cout << "&a = " << &a << ", p = " << p << ", *&p = " << *&p  << ", &*p = " << &*p << endl;  // These all are same, it gives the address of a
    
    
    
    // 1. Pointer Arithmetic
    // 1.1 Adddition 
    // int arr[] = {1, 2, 3, 4, 5, 6};
    
    // int* ptr = arr; // Its same as --> int* ptr = &arr[0]
    
    // int* ptr = &arr[2];
    
    // int* ptr2 = &arr[5];
    
    // cout << "arr = " << arr << ", ptr = " << ptr << ", &arr[0] = " << &arr[0] << endl;
    
    // for(int i = 0; i < 3; i++)
    // {
    //     cout << *(arr + i) << endl;
    // }
    
    
    // cout << endl;
    
    // 1.2 Subtraction 
    
    // cout << ptr2 - ptr << endl; // It give the difference between pointers 
    
    // 1.3 Increment & Decrement
    
    // post Increment
    // cout << *(ptr++) << endl;   // 3 
    // cout << *ptr << endl;       // 4
    
    // pre Increment    --> Ignore the above operations
    // cout << *(++ptr) << endl;   // 4
    // cout << *ptr << endl;       // 4
    
    
    // post Decrement   --> Ignore all the above operations
    // cout << *(ptr--) << endl;   // 3 
    // cout << *ptr << endl;       // 2
    
    // // pre Decrement    --> Ignore all the above operations
    // cout << *(--ptr) << endl;   // 2
    // cout << *ptr << endl;       // 2
    
    
    // 2 Comparing two pointers
    
    // Use relational operators (<, >, <=, >=) and equality operators (==, !=) to compare pointers.
    // Ony possible when both pointer point to same array.
    // Output depends on relative position of both the pointers.
    
    
    
    
    
    return 0;
}

