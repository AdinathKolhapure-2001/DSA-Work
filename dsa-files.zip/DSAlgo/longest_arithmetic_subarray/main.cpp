#include <iostream>

using namespace std;


// Arithmetic subarray: Arithmetic array is an array in which difference of consecutive numbers is constant
// ex. {0, 2, 4, 6} is an Arithmetic array because the difference between consecutive numbers is constant i.e 2 
// {2, 4, 3, 5} is not an Arithmetic array because the difference is not constant
// In Our problem statement we need to find the Lognest Arithmetic subarray(return the length of the subarray)


// In original problem we are considering strict difference (-2 != 2)
// But here I am negleting that using 'abs' function


int longestArithmeticSubarray(int arr[], int size)
{
    int pd = abs(arr[1] - arr[0]);   // This variable is to store previous difference        
    int curr = 2, ans = 2;          // The smallest Arithmetic subarray possible is of length 2         
    
    for(int i = 2; i < size; i++)   
    {
        if(pd == abs(arr[i] - arr[i - 1]))
        {
            curr++;              
        }
        else
        {
            pd = abs(arr[i] - arr[i - 1]);
            curr = 2;                       // If the difference is not constant reset the value of curr 
        }
        
        ans = max(ans, curr);
    }
    
    return ans;
}


int main()
{
    int arr[] = {1, 4, 2, 0, -2, 4};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    int ans = longestArithmeticSubarray(arr, size);
    
    cout << "Lognest arithmetic subarray is of length = " << ans << endl;

    return 0;
}
