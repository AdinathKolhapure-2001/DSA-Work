#include <iostream>

using namespace std;


// left rotation of an array k times 

void leftRotation(int arr[], int n, int k) // n = 5, k = 2
{
    for(int i = k; i < k + n; i++)      // i = 2, 3, 4, 5, 6;  i < 7;
    {
        cout << arr[i%n] << " ";      // arr[2], arr[3], arr[4], arr[0], arr[1]
    }
    cout << "\n";
}


// Right rotation of an array k times

void rightRotation(int arr[], int n, int k) // n = 5, k = 1
{
    for(int i = n - (k%n); i < 2*n - (k%n); i++)      // i = 4, 5, 6, 7, 8; i < 9;
    {
        cout << arr[i%n] << " ";      // arr[4], arr[0], arr[1], arr[2], arr[3]
    }
    cout << "\n";
}


int main()
{
    int arr[] = {1, 2, 3, 4, 5};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    cout << "Left rotation" << endl;
    
    int k = 2;
    
    leftRotation(arr, size, k);
    
    k = 4;
    
    leftRotation(arr, size, k);
    
    k = 8;
    
    leftRotation(arr, size, k);
    
    k = 16;
    
    leftRotation(arr, size, k);
    
    cout << "Right rotation" << endl;
    
    k = 2;
    
    rightRotation(arr, size, k);
    
    k = 4;
    
    rightRotation(arr, size, k);
    
    k = 8;
    
    rightRotation(arr, size, k);
    
    k = 16;
    
    rightRotation(arr, size, k);
    

    return 0;
}
