#include <iostream>
#include <stack>

using namespace std;


bool isOpeningBracket(char c)
{
    return c == '(' || c == '{' || c == '[' || c == '<';
}

bool isClosingBracket(char c)
{
    return c == ')' || c == '}' || c == ']' || c == '>';
}

bool checkExpression(string expression)
{
    stack<char> s;
    int n = expression.length();
    char x;
    
    for(int i = 0; i < n; i++)
    {
        if(expression[i] == ' ')
        {
            continue;
        }
        else if(isOpeningBracket(expression[i]))
        {
            s.push(expression[i]);
        }
        else if(!isOpeningBracket(expression[i]) && !isClosingBracket(expression[i]))
        {
            continue;
        }

        if(s.empty())
        {
            cout << "Invalid expression: Right brackets are more than left brackets" << endl;
            return false;
        }
        
        switch(expression[i])
        {
            case ')':
                x =s.top();
                s.pop();
                if(x == '[' || x == '{' || x == '<')
                    return false;
                break;
                
            case ']':
                x =s.top();
                s.pop();
                if(x == '(' || x == '{' || x == '<')
                    return false;
                break;
                
            case '}':
                x =s.top();
                s.pop();
                if(x == '[' || x == '(' || x == '<')
                    return false;
                break;
                
            case '>':
                x =s.top();
                s.pop();
                if(x == '[' || x == '{' || x == '(')
                    return false;
                break;
        }
    }
    
    return s.empty();
    
}


int main()
{
   
   string expression;
   
    cout << "Enter the expression: ";
       
    getline(cin, expression);
       
    if(checkExpression(expression))
    {
        cout << "Valid expression" << endl;
    }
    else
    {
        cout << "Invalid expression" << endl;
    }
   
    
    return 0;
}

