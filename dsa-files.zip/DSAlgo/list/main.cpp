#include <iostream>

using namespace std;

// Data Structures : Way to store and orgnize the data inonder to retirve it efficiently
// array 
// stack 
// queue
// ll 
// tree 
// graph
// tris 

// logical Way --> Abstract data type --> freatures and functions --> not Implimention

// Implimention


// list --> array 

// create a list of some size
// add
// remove 
// add at location
// remove from location 
// remove all the elemetns 


//int a[10000000];    // max size possible for an array = 10^7




class list
{
    private:                       
        int end;    // 0, 1, 2, 3 
        int size;
        int arr[1000000]; // max size possible for an array = 10^6 
    
    public:
    list(int);
    void add(int);
    void Remove(int);
    void removeFromLocation(int);
    void addAtLocation(int, int);    // arr[i] =  base + i * 4 
    int linearSearch(int);           // arr[5] = 100 + 5 * 4 
    void removeAll();
    void print();                   // 100 104 108 112  116 120
                                   //| 1 | 2 | 3 | 4 | 5 | 6 |  |
};// arr[4]   -->  1, 2, 3, 4, 5, 6                          end

list :: list(int size)              // constant_time not related input size 
{
    this -> size = size;
    end = -1;
    
}


void list :: add(int num)   // Time complexity = O(1)
{
    arr[++end] = num;
}


int list :: linearSearch(int num)       // Time complexity = O(n)
{
    for(int i = 0; i < size; i++)
    {                                   
        if(arr[i] == num)
        {
            return i;
        }
    }
    return -1;
}


void list :: Remove(int num)    // Time complexity = O(n)  
{
    if(end == -1)               
    {
        cout << "List is empty" << endl;
        return;
    }
    int index = linearSearch(num);          
    if(index == -1)                        
    {
        cout << num << " is not present" << endl;
    }
    else
    {
        //          i
        // 5, 6, 8, 9, 9
        for(int i = index; i < size - 1; i++)  
        {
            arr[i] = arr[i + 1];
        }
        
        size--;
        end--;
    }
}


void list :: removeFromLocation(int index)      // Time complexity = O(n)
{
    for(int i = index; i < size - 1; i++)          
    {
        arr[i] = arr[i + 1];                
    }
    size--;
}


void list :: addAtLocation(int index, int num)    // Time complexity = O(n)
{   
    
    if(end == -1)
    {
        cout << "List is empty" << endl;
        return;
    }
    if(index > size)
    {
        cout << "Please enter the valid index(index should less than " << size << " )" << endl;
    }
    else
    {   
        //       i   s = 5
        // 5, 6, 10, 8, 9   
        // i = 2
        // 5, 6, 10, 8, 9
        size++;
        end++;
        for(int i = size - 1; i > index; i--)
        {
            arr[i] = arr[i - 1];
        }
        arr[index] = num;
        
    }
}


void list :: removeAll()            // Time complexity = O(1)
{
    size = end = -1;
}

void list :: print()            // Time complexity = O(n)
{
    if(end == -1)
    {
        cout << "List is empty" << endl;
        return;
    }
    for(int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}






int main()
{
    
    list l(5);
    l.add(5);
    l.add(6);
    l.add(7);
    l.add(8);
    l.add(9);
    l.print();
    // l.Remove(7);
    // l.print();
    // l.addAtLocation(2, 10);
    // l.print();
    // l.removeAll();
    // l.print();
    cout << l.linearSearch(10);
    

    
    
    
    // 5, 6, 7, 8, 9
    // 5, 6, 8, 9
    
    
    return 0;
}


