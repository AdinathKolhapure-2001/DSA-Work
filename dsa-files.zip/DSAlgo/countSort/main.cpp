#include <iostream>

using namespace std;


void countSort(int arr[], int size)
{
    // find the max element
    int imax = 0;
    for(int i = 1; i < size; i++)
    {
        if(arr[i] > arr[imax])  imax = i;
    }
    
    int* count  = new int[imax + 1];    // dyanamic memory allocation in c++
    // int* count = (int*)malloc(imax + 1);   // dyanamic memory allocation in c
    
    // finding the frequency 
    for(int i = 0; i < size; i++)
    {
        count[arr[i]]++;
    }
    // 0, 1, 2, 3 
    // 0  2  3  2
    
    // Update count array as count[i] += count[i - 1];
    for(int i = 1; i <= imax; i++)
    {
        count[i] += count[i - 1];
    }
    
    
    int temp[size];
    
    // travers the original array form back 
    // check the arr[i] --> go to the index arr[i] in count array
    // x = count[arr[i]]--
    // temp[x] = arr[i];
    
    for(int i = size - 1; i >= 0; i--)
    {
        temp[--count[arr[i]]] = arr[i];
    }
    
    // copying the numbers into the original array
    for(int i = 0; i < size; i++)
    {
        arr[i] = temp[i];
    }
    
    // Time Complexity == O(max(imax, n))
}

int main()
{
    
    // 2, 1, 2, 3, 2, 1, 3
    
    //count =  2 --> 3, 1 --> 2, 3 --> 2
    
    // position = 2 --> 3, 1 --> 1, 3 --> 6
    
    // 1 1 2 2 2 3 3
    
    // pos[2]  = 2;
    // pos[1] = 0;
    // pos[3] = 5;
    
    int arr[] = {2, 1, 2, 3, 2, 1, 3};
    
    int size = sizeof(arr) / sizeof(arr[0]);
    // cout << size;
    
    countSort(arr, size);
    
    for(int i : arr)    
    {
        cout << i << " ";
    }
    
    
    // i = 0 1 2 3 
    // a = 0 2 3 2 

    
    // int imax = arr[0];
    // for(int i : arr)
    // {
    //     if(i > imax) imax = i;
    // }
    
    // cout << imax;
    
    // int count[imax + 1];
    
    
    // 2, 1, 2, 3, 2, 1, 3
    
    // 0 2 3 2 
    // 0 1 2 3
    
    // 0 2 5 7
    // 1 1 2 2 2 3 3
    
    // arr[1] = arr[1] + arr[0];
    
     //
    // 2, 1, 2, 3, 2, 1, 3
    
    // 0, 1, 2, 3
    // 0, 0, 2, 5
    
    // 0  1  2  3  4  5  6
    // 1, 1, 2, 2, 2, 3, 3
    
    
    
    // Algorithm for count sort -->
    
    // step 0 : find the max element form the input array and create count array of size (max_element + 1)
    // step 1 : find the frequency of individual element and store it into count array
    // step 2 : Update count array as --> count[i] = count[i] + count[i - 1]
    // step 3 : create a temp array of size of input array 
    //          travers the original array form back 
    //          check the arr[i] --> go to the index arr[i] in count array
    //          x = count[arr[i]]--;
    //          temp[x] = arr[i];
    // step 4 : copy the elements of temp into the input array
    
    
    
    
    
    
    
    return 0;
}

