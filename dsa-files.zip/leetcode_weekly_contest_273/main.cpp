#include <bits/stdc++.h>

using namespace std;

// leetcode Weekly Contest 273

// problem 5963

// 5963. A Number After a Double Reversal
// User Accepted:5268
// User Tried:5423
// Total Accepted:5401
// Total Submissions:6842
// Difficulty:Easy
// Reversing an integer means to reverse all its digits.

// For example, reversing 2021 gives 1202. Reversing 12300 gives 321 as the leading zeros are not retained.
// Given an integer num, reverse num to get reversed1, then reverse reversed1 to get reversed2. Return true if reversed2 equals num. Otherwise return false.


// Example 1:

// Input: num = 526
// Output: true
// Explanation: Reverse num to get 625, then reverse 625 to get 526, which equals num.
// Example 2:

// Input: num = 1800
// Output: false
// Explanation: Reverse num to get 81, then reverse 81 to get 18, which does not equal num.
// Example 3:

// Input: num = 0
// Output: true
// Explanation: Reverse num to get 0, then reverse 0 to get 0, which equals num.

int reverse(int num) {          // Accepted
        int rev = 0;
        while(num) {
            rev = rev * 10 + num % 10;
            num /= 10;
        }
        return rev;
    }
    bool isSameAfterReversals(int num) {
        int reversed1 = reverse(num);
        int reversed2 = reverse(reversed1);
        return num == reversed2;
    }
    
    
    
    
    
// 5964. Execution of All Suffix Instructions Staying in a Grid
// User Accepted:3774
// User Tried:3940
// Total Accepted:3823
// Total Submissions:4509
// Difficulty:Medium
// There is an n x n grid, with the top-left cell at (0, 0) and the bottom-right cell at (n - 1, n - 1). You are given the integer n and an integer array startPos where startPos = [startrow, startcol] indicates that a robot is initially at cell (startrow, startcol).

// You are also given a 0-indexed string s of length m where s[i] is the ith instruction for the robot: 'L' (move left), 'R' (move right), 'U' (move up), and 'D' (move down).

// The robot can begin executing from any ith instruction in s. It executes the instructions one by one towards the end of s but it stops if either of these conditions is met:

// The next instruction will move the robot off the grid.
// There are no more instructions left to execute.
// Return an array answer of length m where answer[i] is the number of instructions the robot can execute if the robot begins executing from the ith instruction in s.

 

// Example 1:


// Input: n = 3, startPos = [0,1], s = "RRDDLU"
// Output: [1,5,4,3,1,0]
// Explanation: Starting from startPos and beginning execution from the ith instruction:
// - 0th: "RRDDLU". Only one instruction "R" can be executed before it moves off the grid.
// - 1st:  "RDDLU". All five instructions can be executed while it stays in the grid and ends at (1, 1).
// - 2nd:   "DDLU". All four instructions can be executed while it stays in the grid and ends at (1, 0).
// - 3rd:    "DLU". All three instructions can be executed while it stays in the grid and ends at (0, 0).
// - 4th:     "LU". Only one instruction "L" can be executed before it moves off the grid.
// - 5th:      "U". If moving up, it would move off the grid.
// Example 2:


// Input: n = 2, startPos = [1,1], s = "LURD"
// Output: [4,1,0,0]
// Explanation:
// - 0th: "LURD".
// - 1st:  "URD".
// - 2nd:   "RD".
// - 3rd:    "D".
// Example 3:


// Input: n = 1, startPos = [0,0], s = "LRUD"
// Output: [0,0,0,0]
// Explanation: No matter which instruction the robot begins execution from, it would move off the grid.
 

// Constraints:

// m == s.length
// 1 <= n, m <= 500
// startPos.length == 2
// 0 <= startrow, startcol < n
// s consists of 'L', 'R', 'U', and 'D'.
    
    
    
    
    
// 5965. Intervals Between Identical Elements
// User Accepted:1427
// User Tried:3353
// Total Accepted:1456
// Total Submissions:5641
// Difficulty:Medium
// You are given a 0-indexed array of n integers arr.

// The interval between two elements in arr is defined as the absolute difference between their indices. More formally, the interval between arr[i] and arr[j] is |i - j|.

// Return an array intervals of length n where intervals[i] is the sum of intervals between arr[i] and each element in arr with the same value as arr[i].

// Note: |x| is the absolute value of x.


// Input: arr = [2,1,3,1,2,3,3]
// Output: [4,2,7,2,4,4,5]
// Explanation:
// - Index 0: Another 2 is found at index 4. |0 - 4| = 4
// - Index 1: Another 1 is found at index 3. |1 - 3| = 2
// - Index 2: Two more 3s are found at indices 5 and 6. |2 - 5| + |2 - 6| = 7
// - Index 3: Another 1 is found at index 1. |3 - 1| = 2
// - Index 4: Another 2 is found at index 0. |4 - 0| = 4
// - Index 5: Two more 3s are found at indices 2 and 6. |5 - 2| + |5 - 6| = 4
// - Index 6: Two more 3s are found at indices 2 and 5. |6 - 2| + |6 - 5| = 5

vector<long long> getDistances(vector<int>& arr) {  // giving TLE
        int n = arr.size();
        vector<long long> v(n);
        unordered_map<int, vector<int>> mp;
        for(auto i = 0; i < n; i++) {
            if(!mp[arr[i]].empty()) {
                mp[arr[i]].push_back(i);
            }
            else
                mp[arr[i]].push_back(i);
        }
        
        for(auto i = 0; i < n; i++) {
                auto S = 0;
                int m = mp[arr[i]].size();
                for(auto j = 0; j < m; j++) 
                    S += abs(i - mp[arr[i]][j]);
                v[i] = S;
        }
        
        // for(int i = 0; i < n; i++) {     // brute force
        //     int S = 0;
        //     for(int j = 0; j < n; j++) {
        //         if(arr[i] == arr[j]) S += abs(i - j);
        //     }
        //     v.push_back(S);
        // }
        
        return v;
    }
    
    
    
    
    
    
// 5966. Recover the Original Array
// User Accepted:411
// User Tried:938
// Total Accepted:450
// Total Submissions:2041
// Difficulty:Hard
// Alice had a 0-indexed array arr consisting of n positive integers. She chose an arbitrary positive integer k and created two new 0-indexed integer arrays lower and higher in the following manner:

// lower[i] = arr[i] - k, for every index i where 0 <= i < n
// higher[i] = arr[i] + k, for every index i where 0 <= i < n
// Unfortunately, Alice lost all three arrays. However, she remembers the integers that were present in the arrays lower and higher, but not the array each integer belonged to. Help Alice and recover the original array.

// Given an array nums consisting of 2n integers, where exactly n of the integers were present in lower and the remaining in higher, return the original array arr. In case the answer is not unique, return any valid array.

// Note: The test cases are generated such that there exists at least one valid array arr.

 

// Example 1:

// Input: nums = [2,10,6,4,8,12]
// Output: [3,7,11]
// Explanation:
// If arr = [3,7,11] and k = 1, we get lower = [2,6,10] and higher = [4,8,12].
// Combining lower and higher gives us [2,6,10,4,8,12], which is a permutation of nums.
// Another valid possibility is that arr = [5,7,9] and k = 3. In that case, lower = [2,4,6] and higher = [8,10,12]. 
// Example 2:

// Input: nums = [1,1,3,3]
// Output: [2,2]
// Explanation:
// If arr = [2,2] and k = 1, we get lower = [1,1] and higher = [3,3].
// Combining lower and higher gives us [1,1,3,3], which is equal to nums.
// Note that arr cannot be [1,3] because in that case, the only possible way to obtain [1,1,3,3] is with k = 0.
// This is invalid since k must be positive.
// Example 3:

// Input: nums = [5,435]
// Output: [220]
// Explanation:
// The only possible combination is arr = [220] and k = 215. Using them, we get lower = [5] and higher = [435].
 

// Constraints:

// 2 * n == nums.length
// 1 <= n <= 1000
// 1 <= nums[i] <= 109
// The test cases are generated such that there exists at least one valid array arr.



    
int main()
{
    // int num = 1800;
    // cout << isSameAfterReversals(num);
    
    // vector<int> arr = {2,1,3,1,2,3,3};  // 2 : 0, 4;  3 : 2, 5, 6
    
    
    // vector<long long> arr1 = getDistances(arr); // [4,2,7,2,4,4,5]
    
    // for(auto i : arr1) cout << i << " ";

    return 0;
}
