#include <iostream>

using namespace std;


struct stack
{
    private: 
        int top;
        int* arr;
        int size;
    public:
        stack(int);
        ~stack();
        void push(int);
        int pop();
        int Top();
        bool isEmpty();
        bool isFull();
        void print();
};

// return_type class_name :: function_name()

stack :: stack(int size)
{
    this -> size = size;
    top = -1;
    arr = new int[size];
}

stack :: ~stack()
{
    delete [] arr;
    cout << "Destructor called" << endl;
}

void stack :: push(int x)
{
    // precondition 
    // top++
    // arr[top] = x
    if(isFull())
    {
     cout << "ERROR: Stack Overflow" << endl;
     return;
    }
    arr[++top] = x;
}


int stack :: pop()
{
    // precondition --> what is it?
    // top--
    if(top == -1)
    {
        // It means stack is empty --> i.e. stack underflow
        cout << "ERROR: Stack Underflow" << endl;
        return -1;
    }
    return arr[top--];
}


int stack :: Top()
{
    // return top element 
    return arr[top];
}

bool stack :: isEmpty()
{
    // if(top == -1)
    // {
    //     return true;
    // }
    // else
    // {
    //     return false;
    // }
    
    return top == -1;
}


bool stack :: isFull()
{
    return top == size - 1;
}


void stack :: print()
{
    for(int i = top; i >= 0; i--)
    {
        cout << "| " << arr[i] << " |" << endl;
    }
    cout << "|____|" << endl;
}


int main()
{
    
    // lIFO
    
    // |   |   --> top
    // |   |
    // |   |
    // |___|

    // push     --> O(1)
    // pop      --> O(1)
    // top      --> O(1)
    // ifFull()
    // isEmpty()
    // print()
    
    
    
    int size;
    cout << "Enter the size of stack: ";
    cin >> size;
    stack s(size);
    
    
    s.push(10);
    s.push(20);
    s.push(30);
    s.push(40);
    s.push(50);
    s.push(60);
    s.print();
    
    cout << "Poped element is " << s.pop() << endl;
    
    s.print();
    
    
    
    return 0;
}
