#include <iostream>
using namespace std;

class cqueue
{   
    int size,front,rear;
    int arr[10];
    
    public:
    
    cqueue(int size)    //constructor
    {   
        this->size=size;
        front=-1;
        rear=-1;
    }
    
    void enqueue(int);
    void dequeue();
    bool isFull();
    bool isEmpty();
    void frontElement();
    void display();
    
    
};


void cqueue::enqueue(int x)
{
    if(isFull())
    {
        cout<<"Queue is full, can not insert element "<<x<<endl;
    }
    else if(front==-1 && rear==-1)
    {
        front++;
        rear++;
        arr[rear]=x;
    }
    else
    {
        rear=(rear+1)%size;
        arr[rear]=x;
        
    }
}

void cqueue::dequeue()
{
    if(isEmpty())
    {
        cout<<"\nQueue is Empty"<<endl;
    }
    else if(front==rear)
    {
        cout<<"\nDequeued element is "<<arr[front]<<endl;
        front=rear=-1;
    }
    else
    {
        cout<<"\nDequeued element is "<<arr[front]<<endl;
        front=(front+1)%size;
    }
}

bool cqueue::isFull()
{
    return (rear+1)%size==front;
}

bool cqueue::isEmpty()
{
    if(front ==-1 && rear==-1)
    {
        return true;
    }
    return false;
}

void cqueue::frontElement()
{
    if(isEmpty())
    {
        cout<<"\nQueue is empty"<<endl;
        return;
    }
    cout<<"\nElement at the front is "<<arr[front]<<endl;
}

void cqueue::display()
{
    if(isEmpty())
    {
        cout<<"\nQueue is empty"<<endl;
        return;
    }
    int i=front;
    while(i!=rear)
    {
        cout<<arr[i]<<" <-- ";
        i=(i+1)%size;
    }
    cout<<arr[rear]<<endl;
}


int main()
{
    int size,element,ch;
    
    cout<<"Enter the size of cqueue: ";
    cin>>size;
    
    cqueue q(size);
    
    while(ch!=5)
    {
        cout<<"\n------------------------------------ Menu -----------------------------------"<<endl;
        cout<<"1.Enqueue"<<endl;
        cout<<"2.Dequeue"<<endl;
        cout<<"3.Front Element"<<endl;
        cout<<"4.Display"<<endl;
        
        cout<<"Enter your choice: ";
        cin>>ch;
        
        switch(ch)
        {
            case 1:
            
            cout<<"\nEnter the element: ";
            cin>>element;
            q.enqueue(element);
            
            break;
            
            case 2:
            
            q.dequeue();
            
            break;
            
            case 3:
            
            q.frontElement();
            
            break;
            
            case 4:
            
            q.display();
            
            break;
            
            case 5:
            
            exit(0);
            
            break;
            
            default:
            cout<<"\nEnter valid choice"<<endl;
        }
        
    }
    
    return 0;
}

