#include<stdio.h>

//void Bresenham_Circle(int xc, int yc,int r)
void Bresenham_Circle(int r)
{
    int x,y,d;
    //int xc,yc;
    d=3-2*r;
    x=0;
    y=r;
    printf("x\ty\td\n");
    do
    {

        printf("%d\t%d\t%d\n",x,y,d);
        //printf("%d\t%d\t%d\n",x+xc,y+yc,d);
        if(d<0)
        {   x=x+1;
            d=d+4*x+6;
        }
        else
        {   x=x+1;
            y=y-1;
            d=d+4*x-4*y+10;
        }
    } while(x<=y);

}



int main()
{
    int radius;
    //int xc,yc;
    printf("\nEnter the radius: ");
    scanf("%d",&radius);
    //printf("\nEnter center points: ");
    //scanf("%d%d",%xc,%yc);
    Bresenham_Circle(radius);
    //Bresenham_Circle(xc,yc,radius);
    return 0;
}
