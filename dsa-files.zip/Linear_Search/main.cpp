
#include <iostream>
using namespace std;

void Linear_search(int arr[10],int num)
{
    int flag = 0;
    for(int i = 0; i<10;i++)
    {
        if(arr[i] == num)
        {
            flag = 1;
            cout<<"Entered number is at position "<<i+1<<endl;
            break;
        }
    }
    if(flag == 0)
    {
        cout<<"Entered number not found"<<endl;
    }
    
}


int main()
{

    int arr[10];
    int num;
    for(int i = 0; i<10;i++)
    {
        cout<<"Enter: ";
        cin>>arr[i];
    }
    cout<<"Enter a number: ";
    cin>>num;
    Linear_search(arr,num);


    

    return 0;
}
