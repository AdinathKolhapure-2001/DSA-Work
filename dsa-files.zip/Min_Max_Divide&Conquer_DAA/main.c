/*
Problem Statement:
Find minimum and maximum elements in the given array 
by using divide and conquer srategy */

/**************************************************************************************************/

#include <stdio.h>

struct pair                                             // structure containing min and max variables
{
    int min;
    int max;
}p;


void accept(int arr[], int n)                       // funnction to accept the array elements
{
    for(int i = 0; i<n; i++)
    {
        printf("\nEnter the element: ");
        scanf("%d", &arr[i]);
    }
}


struct pair min_max(int low, int high, int arr[])
{
    struct pair pl, pr;
    
    if(low == high)                                 // if only one element in the array
    {
        p.min = arr[low];
        p.max = arr[low];
    }
    
    else if(low == high - 1)                              // If two elements in the array
    {
        if(arr[low] < arr[high])
        {
            p.min = arr[low];
            p.max = arr[high];
        }
        else
        {
            p.min = arr[high];
            p.max = arr[low];
        }
    }
    
    else
    {
        int mid = (low + high) / 2;
        pl = min_max(low, mid, arr);                    // left array
        pr = min_max(mid + 1, high, arr);               // right array
        
        if(pl.min < pr.min)                             // comparing the min element in left array and right array
        {
            p.min = pl.min;
        }
        else
        {
            p.min = pr.min;
        }
        if(pl.max > pr.max)                           // comparing the max element in left array and right array
        {
            p.max = pl.max;
        }
        else
        {
            p.max = pr.max;
        }
    }
    
    return p;                                   
}


void display(int arr[], int n)                          // funnction to display array elements and min and max elements
{
    printf("\nArray elements are: \n|");
    for(int i = 0; i<n; i++)
    {
        printf(" %d |", arr[i]);
    }
    
    printf("\n\nMininum element in the array is: %d", p.min);
    printf("\nMaxinum element in the array is: %d", p.max);
    
}

int main()
{
    int n;
    
    printf("\nEnter the size of an array: ");
    scanf("%d", &n);
    
    int arr[n];
    
    accept(arr, n);                             // call to accept function 
    
    min_max(0, n-1, arr);                       // call to min_max function 

    display(arr, n);                            // call to display function 


    return 0;
}
