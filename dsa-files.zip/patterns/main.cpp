#include <iostream>

using namespace std;

void palindromicPyramid(int n)
{
    
    for(int i = 1; i <= n; i++)     
    {
        
        for(int j = 1; j <= (n - i); j++)        // Spaces  -->  (n - i)
        {
            cout << "  ";
        }
        
        for(int j = i; j >= 1; j--)
        {
            cout << j << " ";
        }
        
        for(int j = 2; j <= i; j++)
        {
            cout << j << " ";
        }
        
        cout << "\n";
        
    }
    
    
    
}


void dimond(int m)
{
    
    // upper half
    for(int i = 1; i <= m; i++)
    {
        for(int j = 1; j <= (m - i); j++)       // Spaces
        {
            cout << "  ";
        }
        for(int j = 1; j <= (2*i - 1); j++)     // Stars
        {
            cout << "* ";
        }
        
        cout << "\n";
    }
    
    // Bottom half
    for(int i = m; i >= 1; i--)
    {
        for(int j = 1; j <= (m - i); j++)       // Spaces
        {
            cout << "  ";
        }
        for(int j = 1; j <= (2*i - 1); j++)     // Stars
        {
            cout << "* ";
        }
        
        cout << "\n";
    }
}


void binaryTriangle(int l)
{
    
    for(int i = 1; i <= l; i++)
    {
        for(int j = 1; j <= i; j++)
        {
            if((i + j)%2)
            {
                cout << 0 << " ";
            }
            else
            {
                cout << 1 << " ";
            }
        }
        
        cout << "\n";
    }
    
}


int main()
{
    int n = 5;
    
    //         1 
    //       2 1 2 
    //     3 2 1 2 3 
    //   4 3 2 1 2 3 4
    // 5 4 3 2 1 2 3 4 5
    
    palindromicPyramid(n);
    
    cout << "\n";
    
    int m = 4;
                              //   row    spa   star
        //         *            --> 1 --> 3 -->  1    spaces = (m - i)
        //       * * *          --> 2 --> 2 -->  3    stars = (2*i - 1)
        //     * * * * *        --> 3 --> 1 -->  5    
        //   * * * * * * *      --> 4 --> 0 -->  7    
        //   * * * * * * *
        //     * * * * *
        //       * * * 
        //         *
        
        
        dimond(m);
        
        
        int l = 5;
        
                                  // row     
        // 1  --> ((1, 1) + 1) % 2   1      i = rows = 1;   sum -> even --> 1 
        // 0 1                       2      j= col = 1;     sun -> odd --> 0
        // 1 0 1                     3           
        // 0 1 0 1                   4           
        // 1 0 1 0 1                 5           
          
        binaryTriangle(l);  
        
        int x = 5
        
        // *                 *
        // * *             * *
        // * * *         * * *
        // * * * *     * * * *
        // * * * * * * * * * *
        // * * * * * * * * * *      
        // * * * *     * * * *
        // * * *         * * *
        // * *             * *
        // *                 *
        
        
        
    return 0;
}

