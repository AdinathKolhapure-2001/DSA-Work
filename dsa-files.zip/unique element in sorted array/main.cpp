#include <bits/stdc++.h>

using namespace std;

// Problem Link : https://www.geeksforgeeks.org/find-the-element-that-appears-once-in-a-sorted-array/

// Find the element that appears once in a sorted array

// Given a sorted array in which all elements appear twice (one after one) and one element appears only once. 
// Find that element in O(log n) complexity.

// Example: 
// Input:   arr[] = {1, 1, 3, 3, 4, 5, 5, 7, 7, 8, 8}
// Output:  4

// Input:   arr[] = {1, 1, 3, 3, 4, 4, 5, 5, 7, 7, 8}
// Output:  8


// A Simple Solution is to traverse the array from left to right. Since the array is sorted, 
// we can easily figure out the required element.

// Time Complexity: O(n)
// Auxiliary Space: O(1),  since no extra space has been taken.

int searchUnique1(vector<int> &nums) {
    int n = nums.size();
    for(int i = 0; i < n - 1; i+=2) {
        if(nums[i] != nums[i + 1]) 
            return nums[i];
    }
    return nums[n - 1]; 
}


// Another Simple Solution is to use the properties of XOR (a ^ a = 0 & a ^ 0 = a). 
// The idea is to find the XOR of the complete array. The XOR of the array is the required answer.
// Time Complexity: O(n)
// Auxiliary Space: O(1) 

int searchUnique2(vector<int> &nums) {
    int n = nums.size();
    int XOR = 0;
    for(int i = 0; i < n; i++) 
        XOR ^= nums[i];
    return XOR;
}


// Third approach is by using hashing. Use a map to store the frequency of the elements
// return the element whose frequency is 1 
// Time Complexity : O(n)
// Space Complexity : O(n)


int searchUnique3(vector<int> &nums) {
    unordered_map<int, int> mp;
    for(int &num : nums) 
        mp[num]++;
    for(auto &[num, freq] : mp)
        if(freq == 1)
            return num;
    return -1;
}


// An Efficient Solution can find the required element in O(Log n) time. The idea is to use Binary Search. 
// Below is an observation on the input array. All elements before the required have the first occurrence 
// at even index (0, 2, ..) and the next occurrence at odd index (1, 3, …). And all elements after the 
// required elements have the first occurrence at an odd index and the next occurrence at an even index. 

// 1. Find the middle index, say ‘mid’.
// 2. If ‘mid’ is even, then compare arr[mid] and arr[mid + 1]. If both are the same, 
// then the required element after ‘mid’ and else before mid.
// 3. If ‘mid’ is odd, then compare arr[mid] and arr[mid – 1]. If both are the same, 
// then the required element after ‘mid’ and else before mid.
// Time Complexity: O(Log n)
// Space Complexity : O(1)

int searchUnique4(vector<int> &nums) {
    int n = nums.size();
    int low = 0, high = n - 1;
    int mid;
    while(low <= high) {
        mid = (low + high) >> 1;
        if(!(mid & 1)) {
            if(nums[mid] == nums[mid + 1]) {
                low = mid + 1;
            }
            else {
                high = mid - 1;
            }
        }
        else {
            if(nums[mid] == nums[mid - 1]) {
                low = mid + 1;
            }
            else {
                high = mid - 1;
            }
        }
    }
    return nums[mid];
}

int main()
{
    vector<int> nums = {1, 1, 3, 3, 5, 5, 7, 7, 8, 9, 9};
    
    int unique = searchUnique4(nums);
    
    cout << unique;

    return 0;
}