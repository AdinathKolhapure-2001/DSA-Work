#include <bits/stdc++.h>

using namespace std;

unordered_map<string, unordered_map<string, float>> graph;
unordered_map<string, float> costs;
unordered_map<string, string> parents;
vector<string> processed;

string lowCostNode()
{
    float lowest_cost = INT_MAX;
    float cost;
    string lowest_cost_node = "";
    for(const auto& it : costs)
    {
        cost = costs[it.first];
        if(cost < lowest_cost && find(processed.cbegin(), processed.cend(), it.first) == processed.end())
        {
            lowest_cost = cost;
            lowest_cost_node = it.first;
        }
    }
    
    return lowest_cost_node;
}

void dijkstraAlgo() 
{
    string node = lowCostNode();
    float cost, new_cost;
    unordered_map<string, float> neighbors;
    while(node.length())
    {
        cost = costs[node];
        neighbors = graph[node];
        for(const auto& it : neighbors)
        {
            new_cost = cost + it.second;
            if(costs[it.first] > new_cost)
            {
                costs[it.first] = new_cost;
                parents[it.first] = node;
            }
        }
        processed.push_back(node);
        node = lowCostNode();
    }
}

int main()
{
    // graph["start"] = {{"A", 6}, {"B", 2}};
    // graph["A"] = {{"fin", 1}};
    // graph["B"] = {{"A", 3}, {"fin", 5}};
    // graph["fin"] = {};
    
    // costs["A"] = 6;
    // costs["B"] = 2;
    // costs["fin"] = INT_MAX;
    
    // parents["A"] = "start";
    // parents["B"] = "start";
    // parents["fin"] = "";
    string node;
    int numberOfNodes;
    int numberOfChildNode;
    string child_node;
    float cost;
    cout << "Enter the number of nodes: ";
    cin >> numberOfNodes;
    
    for(int i = 0; i < numberOfNodes; i++)
    {
        cout << "Enter the node: ";
        cin >> node;
        graph[node] = {};
        cout << "How many child nodes " << node << " have: ";
        cin >> numberOfChildNode;
        for(int j = 0; j < numberOfChildNode; j++)
        {
            cout << "Enter the child node: ";
            cin >> child_node;
            cout << "Enter the cost: ";
            cin >> cost;
            graph[node].insert({child_node, cost});
            parents[child_node] = node;
            if(i == 0)
            {
                costs[node] = 0;
                costs[child_node] = cost;
            }
        }
        
        if(costs.find(node) == costs.end())
        {
            costs[node] = INT_MAX;
        }
    }
    
    // for(const auto& it : graph)
    // {
    //     for(const auto& it1 : it.second)
    //     {
    //         cout << it.first << " " << it1.first << " " << it1.second << endl;
    //     }
        
    // }
    
    // cout << "\n\n";
    
    // for(const auto& it : costs)
    // {
    //     cout << it.first << " " << it.second << endl; 
    // }
    
    dijkstraAlgo();
    
    // cout << "\n\n";
    
    // for(const auto& it : costs)
    // {
    //     cout << it.first << " " << it.second << endl; 
    // }
    
    // cout << "\n\n";
    
    // for(const auto& it : parents)
    // {
    //     cout << it.first << " " << it.second << endl; 
    // }
    string finish = "Piano";
    
    cout << "\nMinimum cost require to reach finish is = " << costs[finish] << endl;
    
    string path = " --> " + finish;
    node = parents[finish];
    int n = parents.size();
    while(n)
    {
        path = " --> " + node + path;
        node = parents[node];
        n--;
    }
    
    cout << "\nPath form start to finish:" << endl << path << endl;
    
    
    return 0;
}

