#include <bits/stdc++.h>

using namespace std;


// function to get the difference between head and all the remaining tracks -->

void getDiff(const vector<int>& requestQueue, vector<pair<int,int>>& Diff, int head) { 
    int n = requestQueue.size();
    for(int i = 0; i < n; i++) {
        Diff[i] = {requestQueue[i], abs(head - requestQueue[i])};   // store as pair of {track, difference}
    }
}


// function to get the minimum difference out of all the difference from the head -->

auto getMin(vector<pair<int,int>>& Diff) {
    int n = Diff.size();
    int minDiff = INT_MAX;
    auto minTrack = Diff.begin();
    
    for(auto i = Diff.begin(); i != Diff.end(); i++) {
        if(minDiff > (*i).second) {
            minDiff = (*i).second;
            minTrack = i;
        }
    }
    
    return minTrack;
}


// function to get the seek Time by using SSTF algorithm -->

int SSTF(vector<int>& requestQueue, int head) {
    int seekTime = 0, n = requestQueue.size();
    vector<pair<int,int>> Diff(n);
    auto minTrack = Diff.begin();
    
    for(int i = 0; i < n; i++) {
        getDiff(requestQueue, Diff, head);      // get the difference between head and all the tracks
        minTrack = getMin(Diff);                // get the min difference pair
        seekTime += (*minTrack).second;         // add the difference to seekTime
        head = (*minTrack).first;               // updating head 
        Diff.erase(minTrack);                   // remove processed track
        cout << "\nNew head = " << head << endl;
        // removing the current head(proccessed head) from the requestQueue
        requestQueue.erase(find(requestQueue.begin(), requestQueue.end(), head)); 
        
    }
    
    return seekTime;
    
}

int main()
{
    
    vector<int> requestQueue;
    int head, track, trackSize, seekTime;
    
    cout << "Enter the track size: ";
    cin >> trackSize;
    
    cout << "\nEnter -1 to stop" << endl;
    
    while(1) {
        cout << "\nEnter the track: ";
        cin >> track;
        if(track == -1) break;
        else if(track > (trackSize - 1))        // if track in invalid
            cout << "\nInvalid track" << endl;
        else 
            requestQueue.push_back(track);
    }
    
    cout << "\nEnter the head position: ";
    cin >> head;
    
    seekTime = SSTF(requestQueue, head);
    
    cout << "\nSeek Time = " << seekTime << endl;

    return 0;
}
