#include <bits/stdc++.h>

using namespace std;

void merge(int arr[], int low, int mid, int high) {
    int leftSize = mid - low + 1, rightSize = high - mid, left[leftSize], right[rightSize];
    int k = low, l = mid + 1, i, j;
    for(i = 0; i < leftSize; i++) {
        left[i] = arr[k++];
    }
    for(j = 0; j < rightSize; j++) {
        right[j] = arr[l++];
    }
    i = 0; j = 0, k = low;
    while(i < leftSize && j < rightSize) {
        if(left[i] <= right[j]) arr[k++] = left[i++];
        else arr[k++] = right[j++];
    }
    while(i < leftSize) arr[k++] = left[i++];
    while(j < rightSize) arr[k++] = right[j++];
    // for(int i = low; i <= high; i++) cout << arr[i] << " ";
    // cout << endl;
}

void mergeSort(int arr[], int low, int high) {
    if(high - low == 0) return;
    int mid = low + (high - low) / 2;
    mergeSort(arr, low, mid);
    mergeSort(arr, mid + 1, high);
    merge(arr, low, mid, high); // O(n)
}

int main()
{
    int arr[] = {9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    int n = sizeof(arr) / sizeof(arr[0]);
    
    mergeSort(arr, 0, n - 1);
    
    for(int i : arr) cout << i << " ";
   
    return 0;
}

