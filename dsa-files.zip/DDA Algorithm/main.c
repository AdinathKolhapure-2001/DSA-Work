#include<stdio.h>
#include<stdlib.h>


int ROUND(float a)
{
    a=a+0.5;
    return (int)a;
}


void LineDDA(int xa,int ya,int xb,int yb)
{
    int dx,dy,steps;
    dx=xb-xa;
    dy=yb-ya;
    if(abs(dx)>abs(dy))
    {
        steps=abs(dx);

    }
    else
    {   steps=abs(dy);
    }

    float xincrement,yincrement;
    xincrement=dx/(float)steps;
    yincrement=dy/(float)steps;
    float x=xa,y=ya;
    printf("x\ty\tx plot\ty plot\n");
    printf("%f\t%f\t%d\t%d\n",x,y, ROUND(x), ROUND(y));

    for(int k=0; k<steps; k++)
    {   x=x+xincrement;
        y=y+yincrement;
        printf("%f\t%f\t%d\t%d\n",x,y, ROUND(x), ROUND(y));
    }
}

int main()
{
    int xa,ya,xb,yb;
    printf("\nEnter first point: ");
    scanf("%d%d",&xa,&ya);
    printf("\nEnter second point: ");
    scanf("%d%d",&xb,&yb);

    LineDDA(xa,ya,xb,yb);

    return 0;
}
