

/*Design and develop inheritance for a given case study, identify objects and relationships 
and implement inheritance wherever applicable. Employee class has Emp_name, Emp_id, Address, 
Mail_id, and Mobile_no as members. Inherit the classes: Programmer, Team Lead, Assistant 
Project Manager and Project Manager from employee class. Add Basic Pay (BP) as the member of 
all the inherited classes with 97% of BP as DA, 10 % of BP as HRA, 12% of BP as PF, 0.1% of BP
for staff club fund. Generate pay slips */

//Adinath Kolhapure
// SI02

// Java Program to generate pay slip for Employees


import java.util.Scanner;


class Employee
{
    // Adding Data members 
    protected String Emp_name;
    protected int Emp_id;
    protected String Address;
    protected String Mail_id;
    protected int Mobile_no;
    
    
    // Employee class constructor(parameterized)
    
    public Employee(String Emp_name, int Emp_id, String Address, String Mail_id, int Mobile_no)
    {
        this.Emp_name = Emp_name;
        this.Emp_id = Emp_id;
        this.Address = Address;
        this.Mail_id = Mail_id;
        this.Mobile_no = Mobile_no;
        
    }
    
    
}  // End of Employee Class


class Programmer extends Employee
{
    // Adding Data members
    double BP, DA, HRA, PF, SCF, Net_Sal, Gross_Sal;
    
    // constructor (parameterized) of Programmer class
    public Programmer(String Emp_name, int Emp_id, String Address, String Mail_id, int Mobile_no, double BP)
    {
        // Calling parent class constructor
        super(Emp_name, Emp_id, Address, Mail_id, Mobile_no);   
        
        // Adding extra member BP(Basic Pay)
        this.BP = BP;
    }
    
    
    // Cal_Sal method for calculating net salary
    
    public void Cal_Sal()
    {
        DA=(0.97*BP);
        HRA=(0.10*BP);
        PF=(0.12*BP);
        SCF=(0.001*BP);
        Gross_Sal=(BP+DA+HRA);
        Net_Sal=(Gross_Sal-PF-SCF);
    }
    
    
    // Display method to display pay slip for Employee
    
    public void display()
    {
        System.out.println("\nID\tName\tAddress\tMail_id\t\tMobile_no\tNet_salary");
        System.out.println(Emp_id+"\t"+Emp_name+"\t"+Address+"\t"+Mail_id+"\t"+Mobile_no+"\t\t"+Net_Sal+" $");
    }
    
    
}  //End of Programmer class


class Team_lead extends Employee
{
    // Adding Data members
    double BP, DA, HRA, PF, SCF, Net_Sal, Gross_Sal;
    
    // constructor (parameterized) of Team_lead class
    public Team_lead(String Emp_name, int Emp_id, String Address, String Mail_id, int Mobile_no, double BP)
    {
        // Calling parent class constructor
        super(Emp_name, Emp_id, Address, Mail_id, Mobile_no);   
        
        // Adding extra member BP(Basic Pay)
        this.BP = BP;
    }
    
    
    // Cal_Sal method for calculating net salary
    
    public void Cal_Sal()
    {
        DA=(0.97*BP);
        HRA=(0.10*BP);
        PF=(0.12*BP);
        SCF=(0.001*BP);
        Gross_Sal=(BP+DA+HRA);
        Net_Sal=(Gross_Sal-PF-SCF);
    }
    
    
    // Display method to display pay slip for Employee
    
    public void display()
    {
        System.out.println("\nID\tName\tAddress\tMail_id\t\tMobile_no\tNet_salary");
        System.out.println(Emp_id+"\t"+Emp_name+"\t"+Address+"\t"+Mail_id+"\t"+Mobile_no+"\t\t"+Net_Sal+" $");
    }
    
    
    
}   // End of Team_lead class


class Assistant_Project_Manager extends Employee
{
    // Adding Data members
    double BP, DA, HRA, PF, SCF, Net_Sal, Gross_Sal;
    
    // constructor (parameterized) of Assistant_Project_Manager class
    public Assistant_Project_Manager(String Emp_name, int Emp_id, String Address, String Mail_id, int Mobile_no, double BP)
    {
        // Calling parent class constructor
        super(Emp_name, Emp_id, Address, Mail_id, Mobile_no);    
        
        // Adding extra member BP(Basic Pay)
        this.BP = BP;
    }
    
    
    // Cal_Sal method for calculating net salary
    
    public void Cal_Sal()
    {
        DA=(0.97*BP);
        HRA=(0.10*BP);
        PF=(0.12*BP);
        SCF=(0.001*BP);
        Gross_Sal=(BP+DA+HRA);
        Net_Sal=(Gross_Sal-PF-SCF);
    }
    
    
    // Display method to display pay slip for Employee
    
    public void display()
    {
        System.out.println("\nID\tName\tAddress\tMail_id\t\tMobile_no\tNet_salary");
        System.out.println(Emp_id+"\t"+Emp_name+"\t"+Address+"\t"+Mail_id+"\t"+Mobile_no+"\t\t"+Net_Sal+" $");
    }
    
    
    
}  //End of Assistant_Project_Manager class



class Project_Manager extends Employee
{
    // Adding Data members
    double BP, DA, HRA, PF, SCF, Net_Sal, Gross_Sal;
    
    // constructor (parameterized) of Project_Manager class
    public Project_Manager(String Emp_name, int Emp_id, String Address, String Mail_id, int Mobile_no, double BP)
    {
        // Calling parent class constructor
        super(Emp_name, Emp_id, Address, Mail_id, Mobile_no);    
        
        // Adding extra member BP(Basic Pay)
        this.BP = BP;
    }
    
    
    // Cal_Sal method for calculating net salary
    
    public void Cal_Sal()
    {
        DA=(0.97*BP);
        HRA=(0.10*BP);
        PF=(0.12*BP);
        SCF=(0.001*BP);
        Gross_Sal=(BP+DA+HRA);
        Net_Sal=(Gross_Sal-PF-SCF);
    }
    
    
    // Display method to display pay slip for Employee
    
    public void display()
    {
        System.out.println("\nID\tName\tAddress\tMail_id\t\tMobile_no\tNet_salary");
        System.out.println(Emp_id+"\t"+Emp_name+"\t"+Address+"\t"+Mail_id+"\t"+Mobile_no+"\t\t"+Net_Sal+" $");
    }
    
    
    
}  // End of Project_Manager class 




public class Main
{
    
    public static Scanner scan = new Scanner(System.in);
    
	public static void main(String[] args) {
		
		
		int ch = 0;
		double BP;
		String Emp_name;
        int Emp_id;
        String Address;
        String Mail_id;
        int Mobile_no;
		
		
		
		
		while(ch != 5)
		{
		     
		    // Displaying the Menu to the User
		    
		    System.out.println("\n----------------------------------- Menu -------------------------------------");
		    System.out.println("1.Generate pay slip for Programmer");
		    System.out.println("2.Generate pay slip for Team lead");
		    System.out.println("3.Generate pay slip for Assistant Project Manager");
		    System.out.println("4.Generate pay slip for Project Manager");
		    System.out.println("5.Terminate the Program");
		    
		    // Accepting users choice
		    
		    System.out.print("\nEnter your choice: ");
		    ch = scan.nextInt();
		    
		    
		    // switch case 
		    
		    switch(ch)
		    {
		        
		        case 1:
		            
		            System.out.print("\nEnter the name: ");
		            Emp_name = scan.next();
		            System.out.print("\nEnter the ID: ");
		            Emp_id = scan.nextInt();
		            System.out.print("\nEnter the Address: ");
		            Address = scan.next();
		            System.out.print("\nEnter the Mail_id: ");
		            Mail_id = scan.next();
		            System.out.print("\nEnter the Mobile_no: ");
		            Mobile_no = scan.nextInt();
		            System.out.print("\nEnter the Basic Pay: ");
		            BP = scan.nextDouble();
		            
		            // Creating object of Programmer class
		            Programmer p_obj = new Programmer(Emp_name, Emp_id, Address, Mail_id, Mobile_no, BP);   
		            
		            System.out.println("\nCalculating Salary, Please Wait.....");
		            p_obj.Cal_Sal();
		            
		            System.out.println("\nGenerating Pay Slip Please Wait......\n");
		            p_obj.display();
		            
		            break;
		            
		            
		        case 2:
		            
		            System.out.print("\nEnter the name: ");
		            Emp_name = scan.next();
		            System.out.print("\nEnter the ID: ");
		            Emp_id = scan.nextInt();
		            System.out.print("\nEnter the Address: ");
		            Address = scan.next();
		            System.out.print("\nEnter the Mail_id: ");
		            Mail_id = scan.next();
		            System.out.print("\nEnter the Mobile_no: ");
		            Mobile_no = scan.nextInt();
		            System.out.print("\nEnter the Basic Pay: ");
		            BP = scan.nextDouble();
		            
		            // Creating object of Team_lead class
		            Team_lead t_obj = new Team_lead(Emp_name, Emp_id, Address, Mail_id, Mobile_no, BP);
		            
		            System.out.println("\nCalculating Salary, Please Wait.....");
		            t_obj.Cal_Sal();
		            
		            System.out.println("\nGenerating Pay Slip Please Wait......\n");
		            t_obj.display();
		            
		            
		            break;
		            
		            
		        case 3:
		            
		            System.out.print("\nEnter the name: ");
		            Emp_name = scan.next();
		            System.out.print("\nEnter the ID: ");
		            Emp_id = scan.nextInt();
		            System.out.print("\nEnter the Address: ");
		            Address = scan.next();
		            System.out.print("\nEnter the Mail_id: ");
		            Mail_id = scan.next();
		            System.out.print("\nEnter the Mobile_no: ");
		            Mobile_no = scan.nextInt();
		            System.out.print("\nEnter the Basic Pay: ");
		            BP = scan.nextDouble();
		            
		            // Creating object of Assistant_Project_Manager class
		            Assistant_Project_Manager a_obj = new Assistant_Project_Manager(Emp_name, Emp_id, Address, Mail_id, Mobile_no, BP);   
		            
		            System.out.println("\nCalculating Salary, Please Wait.....");
		            a_obj.Cal_Sal();
		            
		            System.out.println("\nGenerating Pay Slip Please Wait......\n");
		            a_obj.display();
		            
		            
		            break;
		            
		        case 4:
		            
		            System.out.print("\nEnter the name: ");
		            Emp_name = scan.next();
		            System.out.print("\nEnter the ID: ");
		            Emp_id = scan.nextInt();
		            System.out.print("\nEnter the Address: ");
		            Address = scan.next();
		            System.out.print("\nEnter the Mail_id: ");
		            Mail_id = scan.next();
		            System.out.print("\nEnter the Mobile_no: ");
		            Mobile_no = scan.nextInt();
		            System.out.print("\nEnter the Basic Pay: ");
		            BP = scan.nextDouble();
		            
		            // Creating object of Project_Manager class
		            Project_Manager pm_obj = new Project_Manager(Emp_name, Emp_id, Address, Mail_id, Mobile_no, BP);   
		            
		            System.out.println("\nCalculating Salary, Please Wait.....");
		            pm_obj.Cal_Sal();
		            
		            System.out.println("\nGenerating Pay Slip Please Wait......\n");
		            pm_obj.display();
		            
		            
		            break;
		            
		        case 5:
		            
		            System.exit(0);
		            
		            break;
		            
		        default:
		        
		            System.out.println("\nEnter valid choice");
		        
		        
		        
		        
		        
		        
		        
		    }  // End switch case  
		    
		    
		}  // End while loop
		
		

		
		
		
		
	}  // End main method 
	
}  // End main class







