
#include<sys/types.h>
#include<unistd.h>
#include <stdio.h>

int main()
{
    pid_t child_pid;
    int a = 10;
    int *p = &a;
    // p = &a;
    child_pid = fork();

    if(child_pid == 0)
    {   
        a+=5;
        // *p+=5;
        printf("\n In if block");
        printf("\n This is child proccess with id: %d",getpid());
        printf("\n My parent proccess id is: %d",getppid());
        printf("\n%d",a);
    }
    else
    {
        a-=5;
        // *p-=5;
        sleep(1);
        printf("\n\n In else block");
        printf("\n This is parent proccess with id: %d",getpid());
        printf("\n My child proccess id is: %d",child_pid);
        printf("\n My parent proccess id is: %d",getppid());
        printf("\n%d",a);
    }
    
    
    
    return 0;
}


