/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include<iostream>
// #include<vector>
using namespace std;

class HeapSort
{
    void max_Heapify(int [],int,int);
    void min_Heapify(int [],int,int);

public:

    void maxHeap_sort(int [],int);
    void minHeap_sort(int [],int);
    void PrintArray(int [],int);

};

void HeapSort::max_Heapify(int arr[],int index,int n)
{   int largest=index;
    int left=2*index+1;
    int right=2*index+2;
    if(left<n && arr[left]>arr[largest])
    {   largest=left;
    }

    if(right<n && arr[right]>arr[largest])
    {
        largest=right;

    }

    if(largest!=index)
    {   swap(arr[index],arr[largest]);

        max_Heapify(arr,largest,n);
    }


}

void HeapSort::min_Heapify(int arr[],int index,int n)
{
    int smallest=index;
    int left=2*index+1;
    int right=2*index+2;
    if(left<n && arr[left]<arr[smallest])
    {   smallest=left;
    }
    if(right<n && arr[right]<arr[smallest])
    {
        smallest=right;

    }

    if(smallest!=index)
    {   swap(arr[index],arr[smallest]);

        max_Heapify(arr,smallest,n);
    }

}

void HeapSort::maxHeap_sort(int arr[],int n)
{
    for(int i=(n/2)-1; i>=0; i--)
    {
        max_Heapify(arr,i,n);
    }
    for(int i=n-1; i>=0; i--)
    {
        swap(arr[0],arr[i]);

        max_Heapify(arr,0,i);
    }

}

void HeapSort::minHeap_sort(int arr[],int n)
{
    for(int i=(n/2)-1; i>=0; i--)
    {
        min_Heapify(arr,i,n);
    }
    for(int i=n-1; i>=0; i--)
    {   swap(arr[0],arr[i]);

        min_Heapify(arr,0,i);
    }



}
void HeapSort::PrintArray(int arr[],int n)
{
    cout<<"\nAter sorting:"<<endl;
    for(int i=0; i<n; i++)
    {   cout<<arr[i]<<" ";
    }
    cout<<"\n"<<endl;

}
int main()
{
    HeapSort h;
    int n,ch,flag1=0,flag2=0;
    cout<<"\nEnter the size of the heap: ";
    cin>>n;

    // vector<int> arr[n];
    int arr[n];

    while(ch!=5)
    {
        cout<<"\n----Menu----"<<endl;
        cout<<"1.Create a heap"<<endl;
        cout<<"2.Sort in ascending order"<<endl;
        cout<<"3.Sort in descending order"<<endl;
        cout<<"4.Print sorted array"<<endl;
        cout<<"5.Terminate the program"<<endl;
        cout<<"\nEnter your choice: ";
        cin>>ch;

        switch(ch)
        {
        case 1:

            for(int i=0; i<n; i++)
            {
                cout<<"\nEnter the element: ";
                cin>>arr[i];

            }
            flag1=1;
            break;

        case 2:
            if(flag1==1)
            {
                h.maxHeap_sort(arr,n);
                flag2=1;
            }
            else
            {
                cout<<"\nWarning:Create a heap first"<<endl;
            }

            break;
        case 3:
            if(flag1==1)
            {
                h.minHeap_sort(arr,n);
                flag2=1;
            }
            else
            {
                cout<<"\nWanring:Create a heap first"<<endl;
            }
            break;
        case 4:
            if(flag2==1)
            {
                h.PrintArray(arr,n);
            }
            else
            {
                cout<<"\nWarning:Please create a heap first or select option 2 or 3"<<endl;
            }
            break;
        case 5:
            exit(0);
            break;
        default:
            cout<<"\nEnter valid choice"<<endl;







        }
    }

    return 0;
}

