#include<iostream>
#include <stack>
#include<string>
using namespace std;


class Stack
{   
        Stack * next;
        char data;
    public:
        Stack * push(Stack *,char);
        Stack * pop(Stack *);     
        void display();
        bool empty();
        string InfixToPrefix(string);
        int precedence(char);
        int PrefixEval(string);
        
} s;

Stack * top=NULL;

Stack * Stack::push(Stack * top,char x)
{   Stack * newnode;
    newnode=new Stack;
    newnode->data=x;
    newnode->next=top;
    top=newnode;
    
    return top;
}
Stack * Stack::pop(Stack * top)
{   
    Stack * temp;
    temp=top;
    if(top==NULL)
    {
        //cout<<"stack underflow"<<endl;
    }
    else
    {
        top=top->next;
        delete temp;
    }
    
    return top;
}


bool Stack::empty()
{   if(top==NULL)
        return true;
    else
        return false;
}


int Stack::precedence(char c)
{   
    if(c=='^')
        return 3;
    else if(c=='/' || c=='*')
        return 2;
    else if(c=='+' || c=='-')
        return 1;
    else
        return 0;
}


string Stack::InfixToPrefix(string infix)
{   
    string prefix;

    int i=0;
    int j=infix.length()-1;
    char temp;

    while(j>i)              // reversing the expression
    {   temp=infix[j];
        infix[j]=infix[i];
        infix[i]=temp;
        i++;
        j--;
    }

    for(i=0; i<infix.length(); i++)         // if '(' make it ')' and vice versa
    {   if(infix[i]=='(')
        {
            infix[i]=')';
        }
        else if(infix[i]==')')
        {
            infix[i]='(';
        }

    }
    // cout<<"Reversed infix expression:"<<endl<<infix<<endl;
    
    for( i=0; i<infix.length(); i++)
    {   if(isalnum(infix[i]))                   // if oprand append it to prefix string
        {
            prefix+=infix[i];
        }
        else if(infix[i]=='(')                  // if '(' push it 
        {
            top=s.push(top,infix[i]);
        }
        else if(infix[i]==')')                  // if ')' pop all the operator till '('
        {
            while(top->data!='(' && (!s.empty()))
            {
                
                prefix+=top->data;
                
                top=s.pop(top);
               
            }

            top=s.pop(top);
        }

        else {
            if(top==NULL)                       // stack empty
            {
                top=s.push(top,infix[i]);       
            }

            else if(top!=NULL)                  // stack not empty
            {   
                if(precedence(infix[i])>precedence(top->data))          // checking precedence
                {
                    top=s.push(top,infix[i]);
                }

            
                else if(precedence(infix[i])<=precedence(top->data)) {
                    
                    while(top!=NULL && precedence(infix[i])<=precedence(top->data))
                    {   
                        prefix+=top->data;
                        top=s.pop(top);

                    }
                    top=s.push(top,infix[i]);
                }

            }
        }
    }  //end for
    
    while(top!=NULL)            // poping all the data from stack
    {   
        prefix+=top->data;
        top=s.pop(top);

    }
    // cout<<"Evaluated postfix expression:"<<endl<<prefix<<endl;
    
    int k=prefix.length()-1;
    i=0;
    while(k>i)                      // reversing the expression
    {   temp=prefix[k];
        prefix[k]=prefix[i];
        prefix[i]=temp;
        i++;
        k--;
    }
   
// cout<<"After reversing postfix expression:"<<endl<<prefix<<endl;

    return prefix;
}


int Stack::PrefixEval(string prefix)
{
    double res;
    
    stack<double> s1;
    
    for(int i = prefix.length()-1; i>=0; i--)
    {
        double x,y;
        char out;
        
        if(isalnum(prefix[i]))
        {
            cout<<"\nEnter the value of "<<prefix[i]<<": ";
            cin>>out;
            prefix[i] = out;
            s1.push(prefix[i]- '0');
        }
        else
        {
            x =s1.top();
            s1.pop();
            y = s1.top();
            s1.pop();
            
            switch(prefix[i])
            {
                case '+':
                s1.push(x+y);
                break;
                case '-':
                s1.push(x-y);
                break;
                case '*':
                s1.push(x*y);
                break;
                case '/':
                s1.push(x/y);
                break;
                
            }
            
        }
    }
    
    
    return s1.top();
}


int main()
{
    int ch,res;
    Stack s;
    string infix_exp,prefix_exp;

    
   
    
    while(ch != 3)
    {
        cout<<"\n---------------------------------- Menu ----------------------------"<<endl;
        cout<<"1.Infix To Prefix"<<endl;
        cout<<"2.Prefix Evaluation"<<endl;
        cout<<"3.Terminate the program"<<endl;
        
        cout<<"\nEnter your choice: ";
        cin>>ch;
        
        
        switch(ch)
        {
            case 1:
            
            cout<<"Enter the infix expression:"<<endl;
            cin>>infix_exp;
            
            // cout<<"infix expression:"<<endl<<infix_exp<<endl;
            
            prefix_exp=s.InfixToPrefix(infix_exp);
             
            cout<<"Final prefix expression:"<<endl<<prefix_exp<<endl;
    
            
            break;
            
            case 2:
            
            cout<<"\nEnter the Prefix Expression: ";
            cin>>prefix_exp;
            
            res = s.PrefixEval(prefix_exp);
            
            cout<<"\nPrefix Evaluation is: "<<res<<endl;
            
            break;
            
            case 3:
            
            exit(0);
            
            break;
            
            default:
            
            cout<<"\nEnter valid choice"<<endl;
            
        }
    }
    
    
    
    return 0;
}
