#include <bits/stdc++.h>

using namespace std;

// leetcode 1313:
vector<int> decompressRLElist(vector<int>& nums) {
        int n = nums.size(), freq, val;
        vector<int> res;
        for(int i = 0; i < n; i+=2) {
            freq = nums[i], val = nums[i + 1];
            for(int j = 0; j < freq; j++) {
                res.push_back(val);
            }
        }
        return res;
    }
    
// leetcode 1446:
int maxPower(string s) {
    int power = 1, prev = 0;
        int max_power = INT_MIN;
        int n = s.length();
        for(int i = 1; i < n; i++) {
            if(s[i] == s[prev]) power++;
            else power = 1;
            max_power = max(max_power, power);
            prev++;
        }
        return max_power;
}

// leetcode 26:
int removeDuplicates(vector<int>& nums) {
        int k = 0, prev = 0;
        int n = nums.size();
        if(n == 0) return k;
        for(int i = 1; i < n; i++) {
            if(nums[i] != nums[prev]) nums[++k] = nums[i];
            prev++;
        }
        return k + 1;
    }
    

// leetcode 1281:
int subtractProductAndSum(int n) {
        int p = 1, s = 0, digit;
        while(n) {
            digit = n % 10;
            p *= digit;
            s += digit;
            n /= 10;
        }
        return p - s;
    }

int main()
{
    
    // vector<int> nums = {1,1,2,3};
    
    // nums = decompressRLElist(nums);
    
    // for(int i : nums) cout << i << " ";
    
    
    
    // string s = "leetcode";
    // cout << maxPower(s);
    
    
    
    // vector<int> nums = {0,0,1,1,1,2,2,3,3,4};
    
    // cout << removeDuplicates(nums) << endl;
    
    // for(int i : nums) cout << i << " ";
    
    // int n = 4421;
    
    // cout << subtractProductAndSum(n) << endl;
    
    return 0;
}
