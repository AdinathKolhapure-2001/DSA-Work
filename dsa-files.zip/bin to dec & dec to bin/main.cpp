#include<bits/stdc++.h>

using namespace std;


string decimalToBinary(int num) {
    string bin = "";
    while(num) {
        bin = to_string(num & 1) + bin;
        num >>= 1;
    }
    return bin;
}

int binaryToDecimal(string bin) {
    int dec = 0;
    int base = 1;  // As 2^0 = 1
    for(int i = bin.size() - 1; i >= 0; i--) {
        dec += (bin[i] - '0') * base;
        base *= 2;
    }
    return dec;
}

int main()
{
    
    int num = 123456789;
    
    string bin = decimalToBinary(num);
    
    int dec = binaryToDecimal(bin);
    
    cout << num << " --> " << bin << " --> " << dec << endl;
    
    return 0;
}
