#include <bits/stdc++.h>

using namespace std;

// 448. Find All Numbers Disappeared in an Array

// Problem Link : https://leetcode.com/problems/find-all-numbers-disappeared-in-an-array/

// solution link : https://www.youtube.com/watch?v=JfinxytTYFQ&t=430s&ab_channel=KunalKushwaha

// Given an array nums of n integers where nums[i] is in the range [1, n], return an array of 
// all the integers in the range [1, n] that do not appear in nums.

// Example 1:

// Input: nums = [4,3,2,7,8,2,3,1]
// Output: [5,6]
// Example 2:

// Input: nums = [1,1]
// Output: [2]
 

// Constraints:

// n == nums.length
// 1 <= n <= 105
// 1 <= nums[i] <= n
 

// Follow up: Could you do it without extra space and in O(n) runtime? You may assume the returned list does not count as extra space.


// Solution I:
// We know that all the numbers are in the range [1, n].
// So we mark all the indices of the numbers we saw by making the number negative.
// Then, we iterate through the array again and each number that is positive - we know we never saw that index and we can add it to res.

// Time Complexity: O(n)
// Space Complexity: O(1)


vector<int> findDisappearedNumbers1(vector<int> &nums) {
    int n = nums.size();
    vector<int> disappeared;
    for(int i = 0; i < n; i++) {
        nums[abs(nums[i]) - 1] = -abs(nums[abs(nums[i]) - 1]);
    }
    for(int i = 0; i < n; i++) {
        if(nums[i] > 0) {
            disappeared.push_back(i + 1);
        }
    }
    return disappeared;
}



// Solution II : Use cycle sort 
// Algorithm:
// use cycle sort to sort the array 
// If the index does not have corrct value then the  missing value will be index+1

// Time Complexity : O(n)
// Space Complexity : O(1)

vector<int> findDisappearedNumbers2(vector<int> &nums) {
    int n = nums.size();
    vector<int> disappeared;
    int i = 0;
    while(i < n) {
        if(nums[i] != i + 1 && nums[i] != nums[nums[i] - 1]) {
            swap(nums[i], nums[nums[i] - 1]);
        }
        else {
            i++;
        }
    }
    for(int i = 0; i < n; i++) {
        if(nums[i] != i + 1) {
            disappeared.push_back(i + 1);
        }
    }
    return disappeared;
}

int main()
{
    vector<int> nums = {4,3,2,7,8,2,3,1};   // -4, -3, -2, -7, 8, 2, -3, -1
    
    vector<int> disappeared = findDisappearedNumbers2(nums);
    
    for(int num : disappeared) {
        cout << num << " ";
    }

    return 0;
}