#include <bits/stdc++.h>

using namespace std;

// 268. Missing Number

// Problem link : https://leetcode.com/problems/missing-number/

// solution links : https://www.youtube.com/watch?v=JfinxytTYFQ&t=430s&ab_channel=KunalKushwaha
// https://www.youtube.com/watch?v=WnPLSRLSANE&ab_channel=NeetCode
// https://www.geeksforgeeks.org/find-the-missing-number/



int main()
{
    

    return 0;
}