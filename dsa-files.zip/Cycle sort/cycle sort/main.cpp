#include <bits/stdc++.h>

using namespace std;

// refer : https://www.youtube.com/watch?v=JfinxytTYFQ&ab_channel=KunalKushwaha

// when to use cyclic sort : when given numbers are in the range 1 to N or 0 to N 

// Intuition : 
// when the numbers are in the range 1 to N then in the sorted array every number will be at index, (index - 1)
// or value present at any index will be (index + 1) 
// If the value present at the index is not equal to the index+1 then that value is not at its correct place
// place this value to its correct place by swapping 

// Note : In the worst case (N-1) swaps will be made and (N-1) comparision will br made after that, in all the time 
// complexity would be O(n)

// Algorithm :
// Traverse the array check if the given number is at its correct place or not 
// if yes then move forward, else swap the number with number at its correct place

// Time complexity : O(n)
// space complexity : O(1)


void cycleSort(int arr[], int n) {
    // for(int i = 0; i < n; i++) {
    //     while(arr[i] != i + 1) {
    //         swap(arr[i], arr[arr[i] - 1]);
    //     }
    // }
    int i = 0;
    while(i < n) {
        if(arr[i] != i + 1) {
            swap(arr[i], arr[arr[i] - 1]);
        }
        else {
            i++;
        }
    }
}

int main()
{
    int arr[] = {5, 1, 4, 2, 3};
 
    int n = sizeof(arr) / sizeof(arr[0]);
    
    cycleSort(arr, n);
    
    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}