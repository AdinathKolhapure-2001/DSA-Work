#include <bits/stdc++.h>

using namespace std;

/*
Given an array if n integers, find the first element that occurs k number of times.
If no element occurs k times, then print -1. The distribution of integer elements could be in any range.
Input: N=5, A[] = {5, 2, 2, 5, 5}, k=3
output: 5
*/

int firstEleKOccur(int a[], int n, int k) {
    unordered_map<int, pair<int, int>> umap;
    for(int i = 0; i < n; i++) {
        if(umap.find(a[i]) != umap.end()) {     // element already present in map
            umap[a[i]].first++;
            umap[a[i]].second = i;
        }
        else {                                  // new element 
            umap[a[i]].first = 1;
            umap[a[i]].second = i;
        }
    }
    int pos = n, res = -1;
    for(auto i = umap.begin(); i != umap.end(); i++) {
        if(i->second.first == k && i->second.second < pos) {    // check the frequency as well as the position of last occurrence
            res = i->first;
            pos = i->second.second;
        }
    }
    
    return res;
}

// time complexity = O(n)
// space complexity = O(n);

int main()
{
    int a[] = {1, 7, 4, 3, 2, 7, 4};
    
    int n = sizeof(a)/sizeof(a[0]);
    
    int k = 2;
    
    int res = firstEleKOccur(a, n, k);
    
    if(res+1) {
        cout << res << " is the first element that occur " << k << " times" << endl;
    }
    else {
        cout << "NO element occure " << k << " times" << endl;
    }

    return 0;
}