#include <iostream>
using namespace std;


class stack
{
    int arr[10];
    int top;
    int size;
    
    public:
    
    stack(int size)
    {
        this->size=size;
        top=-1;
    }
    
    void push(int);
    void pop();
    bool isFull();
    bool isEmpty();
    void peek();
    void display();
};


void stack::push(int element)
{
    if(isFull())
    {
        cout<<"Stack Overflow"<<endl;
    }
    else if(top==-1)
    {
        top++;
        arr[top]=element;
    }
    else
    {
        top++;
        arr[top]=element;
        
    }
}


void stack::pop()
{
    if(isEmpty())
    {
        cout<<"\nStack Underflow"<<endl;
        return;
    }
    cout<<"\nPoped element is: "<<arr[top]<<endl;
    top--;
    
}


bool stack::isFull()
{
    return top==(size-1);
}


bool stack::isEmpty()
{
    return top==-1;
}


void stack::peek()
{
    if(isEmpty())
    {
        cout<<"\nStack Underflow"<<endl;
        return;
    }
    
    cout<<"\nPeek element is: "<<arr[top]<<endl;
}


void stack::display()
{
     if(isEmpty())
    {
        cout<<"\nStack Underflow"<<endl;
        return;
    }
    
    cout<<"\nStack:\n"<<endl;
    
    for(int i=top;i>=0;i--)
    {
        cout<<"|  "<<arr[i]<<"  |"<<endl;
    }
    cout<<"|______|"<<endl;
}



int main()
{
    
    int size,element,ch;

    cout<<"\nEnter the size of stack: ";
    cin>>size;

    stack s(size);
    
    while(ch!=5)
    {
        cout<<"\n---------------------------------- Menu ----------------------------"<<endl;
        cout<<"1.Push"<<endl;
        cout<<"2.Pop"<<endl;
        cout<<"3.Peek"<<endl;
        cout<<"4.Display"<<endl;
        cout<<"5.Terminate the program"<<endl;
        
        cout<<"\nEnter your choice: ";
        cin>>ch;
        
        
        switch(ch)
        {
            case 1:
            
            cout<<"\nEnter the element: ";
            cin>>element;
            
            s.push(element);
            
            break;
            
            case 2:
            
            s.pop();
            
            break;
            
            case 3:
            
            s.peek();
            
            break;
            
            case 4:
            
            s.display();
            
            break;
            
            case 5:
            exit(0);
            break;
            
            default:
            
            cout<<"\nEnter valid choice"<<endl;
            
        }
    }
    
    
    return 0;
}
