#include <iostream>
#include <queue>
using namespace std;

struct BST {
    int data;
    BST* left;
    BST* right;
};

BST* createNode(int data) {
    
    BST* newNode = new BST;
    newNode -> data = data;
    newNode -> left = NULL;
    newNode -> right = NULL;
    return newNode;
}

BST* insert(BST* root, int data) {
    if(root == NULL) {
        root = createNode(data);
    }
    else if(data <= root -> data) { 
        root -> left = insert(root -> left, data);
    }
    else {
        root -> right = insert(root -> right, data);
    }
    
    return root;
    
    
    
    // BST* newNode = createNode(data);
    // if(!root) {
    //     root = newNode;
    //     return root;
    // }
    
    // BST* curr = root;
    // BST* parent = NULL;
    // while(curr) {
    //     if(data <= curr -> data) {
    //         parent = curr;
    //         curr = curr -> left;
    //     }
    //     else {
    //         parent = curr;
    //         curr = curr -> right;
    //     }
    // }
    // if(data <= parent -> data) parent -> left = newNode;
    // else parent -> right = newNode;
    
    // return root;
    
    
}


int search(BST* root, int data) {
    if(root == NULL) {
        return 0;
    }
    if(data == root -> data) {
        return root -> data;
    }
    else if(data <= root -> data) {
        return search(root -> left, data);
    }
    else {
        return search(root -> right, data);
    }
    
    
    // while(root) {
    //     if(data == root -> data) return root -> data;
    //     else if(data <= root -> data) root = root -> left;
    //     else root = root -> right;
    // }
    // return 0;
    
}


void inorder(BST* root) {
    if(root == NULL) return;
    inorder(root -> left);
    cout << root -> data << " --> ";
    inorder(root -> right);
    
}


BST* findMin(BST* root) {
    if(!root) return root;
    // while(root -> left) root = root -> left;
    // return root -> data;
    
    if(!root -> left) return root;
    return findMin(root -> left);
}


int findMax(BST* root) {
    if(!root) return 0;
    // while(root -> right) root = root -> right;
    // return root -> data;
    
    if(!root -> right) return root -> data;
    return findMax(root -> right);
    
}


int findHeight(BST* root) {
    if(!root) return -1;
    return 1 + max(findHeight(root -> left), findHeight(root -> right));
}


void levelOrder(BST* root) {
    if(!root) return;
    queue<BST*> q;
    
    q.push(root);
    BST* curr = NULL;
    while(!q.empty()) {
        curr = q.front();
        cout << curr -> data << " --> ";
        if(curr -> left) q.push(curr -> left);
        if(curr -> right) q.push(curr -> right);
        q.pop();
    }
    
}


BST* deleteNode(BST* root, int data) {
    if(root == NULL) return root;
    if(data < root -> data) root -> left = deleteNode(root -> left, data);
    else if(data > root -> data) root -> right = deleteNode(root -> right, data);
    else {
        // leaf node
        if(root -> left == NULL && root -> right == NULL) {
            delete root;
            root = NULL;
        }   
        else if(root -> left == NULL) { // node with one child
            BST* temp = root;
            root = root -> right;
            delete temp;
        }
        else if(root -> right == NULL) {
            BST* temp = root;
            root = root -> left;
            delete temp;
        }
        else {  // node with 2 child
            BST* inorderSuccessor = findMin(root -> right); 
            root -> data = inorderSuccessor -> data;
            root -> right = deleteNode(root -> right, inorderSuccessor -> data);
        }
        
    }
    return root;
}

int main()
{
    
    BST* root = NULL;
    
    
    root = insert(root, 12);
    root = insert(root, 5);
    root = insert(root, 3);
    root = insert(root, 7);
    root = insert(root, 9);
    root = insert(root, 8);
    root = insert(root, 11);
    root = insert(root, 1);
    root = insert(root, 15);
    root = insert(root, 13);
    root = insert(root, 14);
    root = insert(root, 17);
    root = insert(root, 16);
    root = insert(root, 20);
    
    
    inorder(root);
    
    cout << endl;
    // search(root, 4) ? cout << "\nData found" << endl : cout << "\nData not found" << endl;
    
    // cout << "\nMin data = " << findMin(root) << endl;
    
    // cout << "\nMax data = " << findMax(root) << endl;
    
    // cout << "\nMax height = " << findHeight(root) << endl;
    
    // cout << "\nLevel order = " << endl;
    
    // levelOrder(root);
    
    // root = deleteNode(root, 8);
    
    // inorder(root);  
    
    // cout << endl;
    
    // root = deleteNode(root, 7);
    
    // inorder(root);
    
    // cout << endl;
    
    // root = deleteNode(root, 15);
    
    // inorder(root);
    
    // cout << endl;
    
    
    
    return 0;
}





