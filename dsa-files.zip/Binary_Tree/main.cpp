#include <bits/stdc++.h>
using namespace std;

class node {
    private:
    int data;
    node* left;
    node* right;
    
    public:
    node* buildTree(node*);
    node* buildFromLevelOrderTraversal(node*);
    void levelOrderTraversal(node*);
    void reverseLevelOrderTraversal(node*);
    
    
    node(int data) {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};


node* node::buildTree(node* root) {
    int data;
    cout << "Enter the data: ";
    cin >> data;
    if(data == -1) return NULL;
    
    root = new node(data);
    
    cout << "Enter the data to insert to the left of " << data << endl;
    root -> left = buildTree(root->left);
    
    cout << "Enter the data to insert to the right of the " << data << endl;
    root -> right = buildTree(root->right);
    
    return root;
}

node* node::buildFromLevelOrderTraversal(node* root) {
    int rootData;
    cout << "Enter data for root: ";
    cin >> rootData;
    root = new node(rootData);
    queue<node*> q;
    q.push(root);
    
    while(!q.empty()) {
        node* temp = q.front();
        q.pop();
        
        int leftData;
        cout << "Enter data for left child of " << temp->data << endl;
        cin >> leftData;
        
        if(leftData != -1) {
            temp->left = new node(leftData);
            q.push(temp->left);
        }
        int rightData;
        cout << "Enter data for right child of " << temp->data << endl;
        cin >> rightData;
        
        if(rightData != -1) {
            temp->right = new node(rightData);
            q.push(temp->right);
        }
        
    }
    return root;
}


void node::levelOrderTraversal(node* root) {
    queue<node*> q;
    q.push(root);
    q.push(NULL);
    
    while(!q.empty()) {
        node* temp = q.front();
        q.pop();
        if(temp==NULL) {
            cout << endl;
            if(!q.empty()) q.push(NULL);
        }
        else {
            cout << temp -> data << " ";
            if(temp->left) q.push(temp->left);
            if(temp->right) q.push(temp->right);
        }
        
    }
}


void node::reverseLevelOrderTraversal(node* root) {
    queue<node*> q;     // 
    stack<node*> s;     // 1 N 5 3 N 17 11 7 N 
                        // t = N 
    q.push(root);
    q.push(NULL);

    while(!q.empty()) {
        node* temp = q.front();
        q.pop();
        
        if(temp == NULL) {
            if(!q.empty()) {
                s.push(temp);
                q.push(NULL);
            }
                
        }
        else {
            s.push(temp);
            if(temp->right) q.push(temp->right);
            if(temp->left) q.push(temp->left);
        }
        
    }

    while(!s.empty()) {
        if(s.top() == NULL) {
            cout << endl;
            s.pop();
        }
        else {
            cout << s.top()->data << " ";
            s.pop();
        }
        
    }
}


int main()
{
    node* root = NULL;
    
    // root = root->buildTree(root);
    
    // 1 3 7 -1 -1 11 -1 -1 5 17 -1 -1 -1 
    
    root = root->buildFromLevelOrderTraversal(root);
    
    // 1 3 5 7 11 17 -1 -1 -1 -1 -1 -1 -1 
    
    
    cout << "\nLevel Order Traversal:" << endl;
    
    root->levelOrderTraversal(root);
    
    cout << "\nReverse Level Order Traversal:" << endl;
    
    root->reverseLevelOrderTraversal(root);
    
    

    return 0;
}

