/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int Binary_search (int arr[], int size, int num)
{
  int start = 0;
  int end = size - 1;
  int mid = 0;
  while (start <= end)
    {
      mid = (start + end) / 2;
      if (arr[mid] == num)
	{
	  return mid;
	}
      else if (arr[mid] > num)
	{
	  end = mid - 1;
	}
      else
	{
	  start = mid + 1;
	}

    }
  return -1;
}

int recursiveBinarySearch(int arr[], int low, int high, int num) {
    int mid = high-(high-low)/2;
    if(low > high) {
        return -1;
    }
    else if(arr[mid] == num) {
        return mid;
    }
    else if(arr[mid] > num) {
        high=mid-1;
        recursiveBinarySearch(arr, low, high, num);
    }
    else {
        low=mid+1;
        recursiveBinarySearch(arr, low, high, num);
    }
}

int
main ()
{
  int num;
  int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
  int size = sizeof (arr) / sizeof (arr[0]);
  cout << "Enter a number: ";
  cin >> num;
//   int result = Binary_search (arr, size, num);
  int result = recursiveBinarySearch(arr, 0, size-1, num);
  if (result+1)
    {
      cout << "Entered number is at position " << result + 1 << endl;
    }
  else
    {
      cout << "Entered number is not found" << endl;
    }



  return 0;
}


