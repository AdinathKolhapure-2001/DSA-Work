#include <iostream>
#include <stack>

using namespace std;

// Infix to postfix converssion


int precedence(char c)
{
    switch(c)
    {
        case '+':
            return 0;
            break;
            
        case '-':
            return 0;
            break;
            
        case '*':
            return 1;
            break;
            
        case '/':
            return 1;
            break;
    }
    return -1;
}

bool isOpeningBracket(char c)
{
   return c == '(' || c == '{' || c == '[';     // this function will return true if char is opening bracket else false 
}

bool isClosingBracket(char c)
{
   return c == ')' || c == '}' || c == ']';     // this function will return true if char is closing bracket else false 
}


string infixToPostfix(string expr, bool prefix = false)
{
    string res = "";
    stack<char> s;  // stack which takes char 
    
    for(int i = 0; i < expr.length(); i++)
    {
        if(expr[i] == ' ')
        {
            continue;
        }
        else if(isalnum(expr[i]))        // if my current char is oprand then append it the res 
        {
            res += expr[i]; // we can wreite short hand notation 
        }
        else if(isOpeningBracket(expr[i]))      // if curr char is opening bracket push it into the stack 
        {
            s.push(expr[i]);
        }
        else if(isClosingBracket(expr[i]))
        {
            while(!isOpeningBracket(s.top()))   // it will loop till s.top becomes opening bracket
            {
                res += s.top();             // pop and append to the res till you get opening bracket
                s.pop();
            }
            s.pop();        // remove opening bracket
        }
        else
        {    
            if(prefix)
            {
                while(!s.empty() && precedence(expr[i]) < precedence(s.top()))              // +
                {                                                                        // 
                    res += s.top();
                    s.pop();
                }
            }
            else 
            {   // s.empty() --> true when stack is empty 
                while(!s.empty() && precedence(expr[i]) <= precedence(s.top()))              // +
                {                                                                        // 
                    res += s.top();
                    s.pop();
                }
            }                                                          // + = 0
            
            
            s.push(expr[i]);    // push the lower precedence operator 
        }
        
    }


    while(!s.empty())
    {
        res += s.top();
        s.pop();
    }

    return res;
    
}


string infixToPrefix(string expr)
{
    
}


int main()
{
    
    
    // Algorithm: 
    
    // Scan the expression from left ot right
    // if you encounter an oprand then append it to result string 
    // if you encounter an opening bracket push it into the stack 
    // if you encounter an closing bracket pop from the stack and append it to the result string till you get opening bracket 
    // pop the opening bracket from the stack 
    // if you encounter an operator, then check the precedence of top of stack 
    // if precedence(operator) <= precedence(topOprerator) --> 
    // pop all the operators from the stack which has lesser or equal precedence than your operator and append it to the result string 
    // push(operator)
    
    // pop all the operators from the stack and append it to result string 
    // return result string 
    
    //              i 
    // a + ( b * c )      // result = "a b c * +"
    
    // a + ( b * c ) - (d / e)      // 
    //  a b c * + d e / - 
    
    // ( e / d ) - ( c * b ) + a        // 
    // e d / c b * a + - 
    // - + a * b c / d e    --> for prefix you need to check the condition as precedence(top) > precedence(expr[i)
    
    // Infix to Prefix
    // reverse the given infix expression
    // Make all the opening bracket as closing bracket and vice versa
    // Convert the reversed expression into the postfix
    // Again reverse the resulting expression
    // return the result 
    
    // a + (b * c)
    // ) c * b ( + a 
    // ( c * b ) + a
    //  c b * a +
    // + a * b c
    string expr, res;
    
    cout << "Enter the infix expression: ";
    
    getline(cin, expr);
    
    res = infixToPostfix(expr);
    
    cout << "Postfix Expression: " << res << endl;

    res = infixToPrefix(expr);
    
    cout << "Prefix Expression: " << res << endl;
    
    
    
    return 0;
}

