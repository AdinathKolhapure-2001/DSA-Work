#include <bits/stdc++.h>
using namespace std;


struct BST
{
    char data;
    BST* left;
    BST* right;
    
    BST();
    BST(char);
    void inorder(BST*);
    void preorder(BST*);
    void dsf(BST*);
};

BST :: BST(char data)
{
    this -> data = data;
    this -> left = NULL;
    this -> right = NULL;
}


void BST :: inorder(BST* root)
{
    if(root == NULL)
    {
        return;
    }
    
    inorder(root -> left);
    cout << root -> data << " --> ";
    inorder(root -> right);
}


void BST :: preorder(BST* root)
{
    if(root == NULL)
    {
        return;
    }
    
    cout << root -> data << " --> ";
    preorder(root -> left);
    preorder(root -> right);
}


void BST :: dsf(BST* root)
{
    if(!root)   
    {
        cout << "Error: BST is empty" << endl;
        return;
    }
    stack<BST*> s;
    s.push(root);
    
    while(!s.empty())
    {
        BST* top = s.top();
        cout << top -> data << " --> ";
        s.pop();
        if(top -> right)
        {
            s.push(top -> right);
        }
        if(top -> left)
        {
            s.push(top -> left);
        }
    }
}


int main()
{
    
    BST* a = new BST('A');
    BST* root = a;
    BST* b = new BST('B');
    BST* c = new BST('C');
    BST* d = new BST('D');
    BST* e = new BST('E');
    BST* f = new BST('F');
    
    a ->left = b;
    a -> right = c;
    b -> left = d;
    b -> right = e;
    c -> right = f;
    
    (*a).inorder(root);
    cout << "\n";
    (*a).preorder(root);
    cout << "\n";
    (*a).dsf(root);

    return 0;
}

