
#include <iostream>
#include <math.h>
#include <cmath>
using namespace std;

class Animation
{
  // int M1[3][3];
  // int P[3][1];
  float P1[3][1];
  // int M2[3][1];
public:
  void Translation (int, int, int, int);
  void Scaling (int, int, int, int, int, int);
  void Rotation (float, int, int, int, int);
  void Reflection (int, int, int);
  void display ();
};

void
Animation::Translation (int x, int y, int tx, int ty)
{
  int M1[3][3] = { 1, 0, tx,
    0, 1, ty,
    0, 0, 1
  };

  int P[3][1] = { x, y, 1 };

  // int M2[3][1]={tx,ty,1};
  // int P1[3][1];
  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 1; j++)
	{
	  P1[i][j] = 0;
	  for (int k = 0; k < 3; k++)
	    {
	      P1[i][j] += M1[i][k] * P[k][j];

	    }
	  // P1[i][j]+=M2[i][j];
	}
    }

}

void
Animation::Scaling (int x, int y, int sx, int sy, int xf = 0, int yf = 0)
{
  int M1[3][3] = { sx, 0, xf * (1 - sx),
    0, sy, yf * (1 - sy),
    0, 0, 1
  };
  int P[3][1] = { x, y, 1 };

  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 1; j++)
	{
	  P1[i][j] = 0;
	  for (int k = 0; k < 3; k++)
	    {
	      P1[i][j] += M1[i][k] * P[k][j];

	    }
	  // P1[i][j]+=M2[i][j];
	}
    }

}

void
Animation::Rotation (float theta, int x, int y, int xr = 0, int yr = 0)
{
  theta = (M_PI / 180) * theta;
  // cout<<cos(theta)<<endl;
  float M1[3][3] =
    { cos (theta), -sin (theta), xr * (1 - cos (theta)) + yr * sin (theta),
    sin (theta), cos (theta), yr * (1 - cos (theta)) - xr * sin (theta),
    0, 0, 1
  };
  int P[3][1] = { x, y, 1 };

  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 1; j++)
	{
	  P1[i][j] = 0;
	  for (int k = 0; k < 3; k++)
	    {
	      P1[i][j] += M1[i][k] * P[k][j];

	    }
	  // P1[i][j]+=M2[i][j];
	}
    }
}

void
Animation::display ()
{
  //Matrix format
  /*for(int i=0;i<3;i++)
     {
     for(int j=0;j<1;j++)
     {
     // P1[i][j]+=M2[i][j];
     cout<<P1[i][j]<<"\t";
     }
     cout<<"\n";
     } */

  float x = P1[0][0];
  float y = P1[1][0];
  cout << x << "\t" << y << endl;
}

void
Animation::Reflection (int x, int y, int r)
{
  int M1[3][3];
  if (r == 1)
    {
      int M1[3][3] = { 1, 0, 0,
	0, -1, 0,
	0, 0, 1
      };

    }
  else if (r == 2)
    {
      int M1[3][3] = { -1, 0, 0,
	0, 1, 0,
	0, 0, 1
      };
    }

  else if (r == 3)
    {
      int M1[3][3] = { -1, 0, 0,
	0, -1, 0,
	0, 0, 1
      };

    }
  else if (r == 4)
    {
      int M1[3][3] = { 0, 1, 0,
	1, 0, 0,
	0, 0, 1
      };

    }
  else if (r == 5)
    {
      int M1[3][3] = { 0, -1, 0,
	-1, 0, 0,
	0, 0, 1
      };
    }
  int P[3][1] = { x,
    y,
    1
  };

  for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 1; j++)
	{
	  P1[i][j] = 0;
	  for (int k = 0; k < 3; k++)
	    {
	      P1[i][j] += M1[i][k] * P[k][j];

	    }
	  // P1[i][j]+=M2[i][j];
	}
    }

}

int
main ()
{
  // cout<<cos((M_PI/180)*60)<<endl;
  Animation A1, A2, A3, A4;

//   A2.Scaling (20, 30, 2, 3);
//   A2.display ();
//   A3.Rotation (60, 10, 10, 20, 30);
//   A3.display ();
  int ch, x, y, tx, ty, sx, sy, xf, yf, xr, yr, np, r;
  float theta;

  while (ch != 5)
    {
      cout << "\n---------Menu---------" << endl << "1.Translation" << endl <<
	"2.Scaling" << endl << "3.Rotation" << endl << "4.Reflection" << endl
	<< "5.Exit" << endl;
      cout << "\nEnter your choice: ";
      cin >> ch;

      switch (ch)
	{
	case 1:
	  {
	    cout << "Enter number of points: ";
	    cin >> np;
	    float points[np];
	    cout << "Enter the values of tx and ty: ";
	    cin >> tx >> ty;
	    for (int i = 0; i < 2 * np; i += 2)
	      {
		cout << "Enter the " << (i + 2) / 2 << " point: ";
		cin >> points[i] >> points[i + 1];

	      }
	    cout << "\nTranslated points are: " << endl << "x\ty" << endl;

	    for (int i = 0; i < 2 * np; i += 2)
	      {
		A1.Translation (points[i], points[i + 1], tx, ty);
		A1.display ();
	      }

	    break;
	  }
	case 2:
	  {
	    cout << "Enter number of points: ";
	    cin >> np;
	    float points[np];
	    cout << "Enter the values of sx and sy: ";
	    cin >> sx >> sy;
	    cout << "Enter the values of xf and yf: ";
	    cin >> xf >> yf;
	    for (int i = 0; i < 2 * np; i += 2)
	      {
		cout << "Enter the " << (i + 2) / 2 << " point: ";
		cin >> points[i] >> points[i + 1];

	      }
	    cout << "\nScaled points are: " << endl << "x\ty" << endl;

	    for (int i = 0; i < 2 * np; i += 2)
	      {
		A2.Scaling (points[i], points[i + 1], sx, sy, xf, yf);
		A2.display ();
	      }

	    break;
	  }
	case 3:
	  {
	    cout << "Enter number of points: ";
	    cin >> np;
	    float points[np];
	    cout << "Enter the values of theta in degrees: ";
	    cin >> theta;
	    cout << "Enter the values of xr and yr: ";
	    cin >> xr >> yr;
	    for (int i = 0; i < 2 * np; i += 2)
	      {
		cout << "Enter the " << (i + 2) / 2 << " point: ";
		cin >> points[i] >> points[i + 1];

	      }
	    cout << "\nRotated points are: " << endl << "x\ty" << endl;

	    for (int i = 0; i < 2 * np; i += 2)
	      {
		A3.Rotation (theta, points[i], points[i + 1], xr, yr);
		A3.display ();
	      }

	    break;
	  }
	case 4:
	  {
	    cout << "1.Along x axis" << endl << "2.Along y axis" << endl <<
	      "3.Along origin" << endl << "4.Along line y=x" << endl <<
	      "5.Along line y=-x" << endl;
	    cout << "Enter your choice: ";
	    cin >> ch;
	    switch (ch)
	      {
	      case 1:
		r = 1;

		break;
	      case 2:
		r = 2;
		break;
	      case 3:
		r = 3;
		break;
	      case 4:
		r = 4;
		break;
	      case 5:
		r = 5;
		break;
	      default:
		cout << "Enter valid choice" << endl;
	      }
	    cout << "Enter number of points: ";
	    cin >> np;
	    float points[np];
	    for (int i = 0; i < 2 * np; i += 2)
	      {
		cout << "Enter the " << (i + 2) / 2 << " point: ";
		cin >> points[i] >> points[i + 1];

	      }
	    cout << "\nReflected points are: " << endl << "x\ty" << endl;

	    for (int i = 0; i < 2 * np; i += 2)
	      {
		A3.Reflection (points[i], points[i + 1], r);
		A3.display ();
	      }
	    break;
	  }
	case 5:
	  exit (0);
	  break;

	default:
	  cout << "\nEnter Valid Choice" << endl;
	}
    }

}
