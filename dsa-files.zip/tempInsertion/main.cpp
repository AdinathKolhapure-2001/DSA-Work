#include <iostream>

using namespace std;

/*


    for -> 1 to n - 1
    {
        temp = arr[i]
        
        for j -> i - 1 to 0
        {
            if(arr[j] > arr[i])
            {
                arr[i] = arr[j];
            }
            else
            {
                break;
            }
        }
        
        
        arr[++j] = temp;
        
    }
    

*/


void insertionSort(int arr[], int size)
{

    int i, j, temp;
    
    for(i = 1; i < size; i++)
    {
        temp = arr[i];
        
        for(j = i - 1; j >= 0; j--)
        {
            if(arr[j] > temp)
            {
                arr[j + 1] = arr[j];
            }
            else
            {
                break;
            }
        }
        
        
        arr[++j] = temp;
        
    }
}


// void foo(int *arr)  // arr = Address of first num
// {
//     int size = sizeof(arr) / sizeof(int);
    
//     cout << "Size in foo: " << size << endl;
//     cout << "Hello" << endl;
// }

// void bar(int n)  // n = &num  
// {
// //     cout << "Address stored at *n int bar: "<< n << endl;
//     n++;
//     cout << "Num in bar: " << n << endl;

//     // return n;
// }


int main()
{
   
   
    int arr[] = {7, 2, 1, 3, 8}; 
    
    int size = sizeof(arr) / sizeof(arr[0]);
    
    insertionSort(arr, size);
    
    // cout << arr << endl;
    // cout << &arr[0] << endl;
    
    // foo(arr);
    // cout << "Size in main: " << size << endl;
    
    // int num = 5;
    // cout << "Address of num in main: "<< &num << endl;
    // num = bar(num);
    // cout << "Num in main: " << num << endl;
    // int num = 8;
    // cout << "Size of num: " << sizeof(num) << endl;
    // int *p = &num;
    // cout << "Size of pointer: " << sizeof(p) << endl;
    
    // cout << "division: " << sizeof(p) / sizeof(num) << endl;
    
    for(int i : arr)    cout << i << " | ";    
    
    // sorted  | un
    //         |  3, 7, 9, 8, 10
    //           j    
    //        temp = 3
    
    
    
    return 0;
}

