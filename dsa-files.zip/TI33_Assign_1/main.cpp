#include <iostream>

using namespace std;

// 1. You will be given an integer ‘n’. You need to print all the prime numbers less than or
// equal to n in the ascending order.
// Note: If there are no primes less than or equal to ‘n’ then print “There are no prime
// numbers less than n”.

// Example:
// Input: 10 (Value of n)
// Output: 2 3 5 7 11 13 17 19


void primeTillN(int n) {
    int arr[n+1] = {0};
    int num = 2;
    while(num*num <= n) {
        if(arr[num] == 0) {
            for(int i = num*num; i <= n; i+=num) {
                arr[i] = 1;
            }
        }
        num++;
    }
    
    cout << "\nPrime numbers till " << n << endl;
    for(int i = 2; i <= n; i++) {
        if(arr[i] == 0) cout << i << " ";
    }
    cout << "\n";
}




// 2. Given an integer ‘N’, print the corresponding Numeric Inverted Half Pyramid pattern
// for ‘N’.
// Example:
// Input: 4 (Value of N)
// Output:
// 1 2 3 4
// 1 2 3
// 12
// 1
// Problem Constraints: 1<=N<=100
// NOTE: There should be no extra spaces after last integer and before first integer in any
// row and all integers in any row in the pattern are space separated.


void invertedHalfPyramid(int n) {
    for(int i = 0; i < n; i++) {
        for(int j = 1; j <= n - i; j++) {
            cout << j << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}




// 3. Write a program to input T numbers (N) from user and find reverse of the given
// number.
// Input: T (number of test cases)
// N (integer number)

// Example:
// Input:
// 3
// 1234
// 1200
// 102
// Output:
// 4321
// 21
// 201


int reverseNum(int num) {
    int rev = 0;
    while(num) {
        rev = num % 10 + rev * 10;
        num /= 10;
    }
    return rev;
}




// 4. Given an integer ‘N’, print the corresponding star pattern for ‘N’.
// Example:
// Input: 4 (Value of N)
// Output:
//     *
//    ***
//   *****
//  *******
// *********


void starTriangle(int n) {
    for(int i = 0; i <= n; i++) {
        for(int j = 0; j < n - i; j++)
            cout << " ";
        for(int k = 0; k < (2*i+1); k++)
            cout << "*";
        cout << "\n";
    }
    cout << "\n";
}

int main()
{
    int n, T;
    
    //  Program_1
    cout << "Enter the value of n: ";
    cin >> n;
    primeTillN(n);
    
    
    //  Program_2
    cout << "\nEnter the value of n: ";
    cin >> n;
    invertedHalfPyramid(n);
    
    
    //  Program_3
    cout << "\nEnter the value of T: ";
    cin >> T;
    int testCases[T];
    cout << "Enter the numbers: " << endl;
    for(int i = 0; i < T; i++) {
        cin >> testCases[i];
    }
    cout << "Reverse of the given numbers: " << endl;
    for(int num : testCases) {
        cout << reverseNum(num) << endl;
    }
    
    
    // Program_2
    cout << "\nEnter the value of n: ";
    cin >> n;
    starTriangle(n);
    

    return 0;
}