
import java.util.Scanner;

class matrix
{
    private int row, col;
    private int mat[][] = new int[5][5];
    
    public matrix()
    {
        // default constructor
    }
    
    public matrix(int row, int col)
    {
        this.row = row;
        this.col = col;
        
        for(int i = 0; i<row; i++)
        {
            for(int j = 0; j<col; j++)
            {
                System.out.print("Enter the element: ");
                mat[i][j] = Main.scan.nextInt();
            }
        }
    }
    
    
    public void add(matrix x, matrix y)
    {
        if(x.row != y.row || x.col != y.col)
        {
            System.out.println("\nDimentions are not compatible for addition");
            return;
        }
        row = x.row;
        col = x.col;
        
        System.out.println("\nAddition of two matrices is: ");
        
        for(int i = 0; i<row; i++)
        {
            for(int j = 0; j<col; j++)
            {
                mat[i][j] = x.mat[i][j] + y.mat[i][j];
            }
        }
    }
    
    
    public void mult(matrix x, matrix y)
    {
        if(x.col != y.row)
        {
            System.out.println("\nDimentions are not compatible for multiplication");
            return;
        }
        
        row = x.row;
        col = y.col;
        
        System.out.println("\nMultiplication of two matrices are: ");
        
        for(int i = 0; i<row; i++)
        {
            for(int j = 0; j<col; j++)
            {
                mat[i][j] = 0;
                
                for(int k = 0; k<x.col; k++)
                {
                    mat[i][j] += x.mat[i][k] * y.mat[k][j];
                }
            }
        }
        
        
    }
    
    
    public void transpose(matrix x)
    {
        row = x.col;
        col = x.row;
        
        for(int i = 0; i<row; i++)
        {
            for(int j = 0; j<col; j++)
            {
                mat[i][j] = x.mat[j][i];
            }
        }
    }
    
    
    public  void display()
    {
        for(int i = 0; i<row; i++)
        {
            for(int j = 0; j<col; j++)
            {
                System.out.print(mat[i][j]+"  ");
            }
            
            System.out.println();
        }
    }
    
}



public class Main
{
    public static Scanner scan = new Scanner(System.in);
    
	public static void main(String[] args) {
		
		int row, col;
		
		
		System.out.println("\nEnter the number of row`s and column`s: ");
		row = scan.nextInt();
		col = scan.nextInt();
		
		matrix m1 = new matrix(row,col);
		
		System.out.println("\nEnter the number of row`s and column`s: ");
		row = scan.nextInt();
		col = scan.nextInt();
		
		matrix m2 = new matrix(row,col);
		
		matrix m3 = new matrix();
		
		System.out.println("\nFirst matrix:");
		m1.display();
		
		System.out.println("\nSecond matrix: ");
		m2.display();
		
		m3.add(m1,m2);
		m3.display();
		
		m3.mult(m1,m2);
		m3.display();
		
		System.out.println("\nTranspose of first matrix is: ");
		m3.transpose(m1);
		m3.display();
		
		System.out.println("\nTranspose of second matrix is: ");
		m3.transpose(m2);
		m3.display();
	}
}
