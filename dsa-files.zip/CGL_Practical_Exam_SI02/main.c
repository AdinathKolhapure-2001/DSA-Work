
// SI-02
// Adinath Dnyanoba Kolhapure

// Problem Statement: implement cohen-sutherland line clipping algorithm


#include <stdio.h>


int xmin,xmax,ymin,ymax;        // globle variables
int code[4];                    // array to store code


struct LineClipping  // structure
{
    float x,y;
    int binary[4];
    
}p1,p2;


void check(struct LineClipping *p)
{
    
    for(int i = 0; i<4; i++)     // 0 0 0 0
    {
        p->binary[i] = 0;
    }
    
    
    if(p->x<xmin)               // Left
    {
      p->binary[3]=1;
    }
    
    if(p->x>xmax)               // Right
    {
      p->binary[2]=1;
    }
    
    
    if(p->y<ymin)               // Bottom
    {
      p->binary[1]=1;
    }
    
    if(p->y>ymax)               // Top
    {
      p->binary[0]=1;
    }
    
    
    printf("\nP: ");            // printing the code 
    for(int i=0;i<4;i++)
    {
        printf("%d",p->binary[i]);
    } 
   
   
  
}



void calculate(struct LineClipping *p)
{
    int i,flag;
    float x,y;

    for(i=0;i<4;i++)
     {
        if(p->binary[i]==0)
         {
           flag=0;
         }
         
        else
        {
           flag=1;
           break;
        }
     }


    if(flag==1)
    {
        if(p->binary[3]==1)
        { 
            x=xmin;
        }
        
        if(p->binary[2]==1)
        {
            x=xmax;
        }

        if(p->binary[1]==1)
        { 
            y=ymin;
        }
        if(p->binary[0]==1)
        {
            y=ymax;
        }

        float m=(p2.y-p1.y)/(float)(p2.x-p1.x);             // slope calculation
        // printf("\n%f",m);
        
        if(p->binary[3]==1 || p->binary[2]==1)              // point lies either left side or right side of the window
        {
            y=p->y+m*(x-p->x);
        }
        else                                              // point lies either top or bottom of the window         
        {
            x=p->x+(y-p->y)/m;
        }
        
        p->x=x;
        p->y=y;  
        
    }
    
} 

void find()
{  
   int i;
   
   printf("\nNew points: ");
   calculate(&p1);
   printf("\np1->x\t\tp1->y");
   printf("\n%f\t%f",p1.x,p1.y);
   
   printf("\np2->x\t\tp2->y");
   calculate(&p2);
   printf("\n%f\t%f",p2.x,p2.y);
   
   check(&p1);
   check(&p2);

 
}


void test()
{
    int i,flag,flag1;
    
    for(i=0;i<4;i++)
    {
      if(p1.binary[i]==0 && p2.binary[i]==0)            // both p1 and p2 lies inside the window
      {
        flag=0;
      }
      else
      {
        flag=1;
        break;
      }
      
    }
    
    if(flag==0)
    {
        printf("\nLine Accepted");
        return;
    }
    else
    {
        for(i=0;i<4;i++)
        {
            code[i]=p1.binary[i]&&p2.binary[i];             // p1 AND p2
        } 
    
        for(i=0;i<4;i++)
        {
            if(code[i]==1)
            {
                flag1=0;
                break;
            }
            else
            {
                flag1=1;
            }
        } 
        
        if(flag1==0)
        {
            printf("\nLine Rejected");
        }
        else
        {
            printf("\nPartially accepeted");
            find();
        }
    }
    
    
}


 


int main()
{
     
    printf("\nEnter the xmin and ymin value of window: ");
    scanf("%d%d",&xmin,&ymin);
    printf("\nEnter the xmax and ymax value of window: ");
    scanf("%d%d",&xmax,&ymax);
    
    printf("\nEnter the x and y value of point p1: ");
    scanf("%f%f",&p1.x,&p1.y);
    
    printf("\nEnter the x and y value of point p2: ");
    scanf("%f%f",&p2.x,&p2.y);
     
    check(&p1);
    check(&p2);
    test();
 
}

