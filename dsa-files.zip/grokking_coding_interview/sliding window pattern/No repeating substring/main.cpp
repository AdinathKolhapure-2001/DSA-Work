#include <iostream>
#include<vector>
#include <unordered_map>

using namespace std;


class noRepeatSubstring {
    public:
    static int findLength(const string &str) {
        int windowStart = 0, maxLength = 0;
        unordered_map<char, int> mp;
        for(int windowEnd = 0; windowEnd < str.length(); windowEnd++) {
            mp[str[windowEnd]]++;
            while(mp[str[windowEnd]] > 1) {
                mp[str[windowStart]]--;
                if(mp[str[windowStart]] == 0) {
                    mp.erase(str[windowStart]);
                }
                windowStart++;
            }
            maxLength = max(maxLength, windowEnd - windowStart + 1);
        }
        return maxLength;
    }
};



// Time Complexity #
// The time complexity of the above algorithm will be 
// O(N) where ‘N’ is the number of characters in the input string.

// Space Complexity #
// The space complexity of the algorithm will be O(K) where 
// K is the number of distinct characters in the input string. 
// This also means K<=N, because in the worst case, the whole string might 
// not have any repeating character so the entire string will be added to the HashMap. 
// Having said that, since we can expect a fixed set of characters in the input 
// string (e.g., 26 for English letters), we can say that the algorithm runs in fixed space 
// O(1); in this case, we can use a fixed-size array instead of the HashMap.


int main()
{
    
    cout << "length of lingest substring: " 
         << noRepeatSubstring :: findLength("aabccbb") << endl;
         
    
    cout << "length of lingest substring: " 
         << noRepeatSubstring :: findLength("abbbb") << endl;
         
    cout << "length of lingest substring: " 
         << noRepeatSubstring :: findLength("abccde") << endl;
    
    return 0;
}
