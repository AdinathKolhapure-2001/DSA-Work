#include <iostream>
#include <unordered_map>

using namespace std;


class longestSubStringKDistinct {
    public:
    static int findLength(const string &str, int k) {
        int windowStart = 0, maxLength = 0;
        unordered_map<char, int> mp;
        for(int windowEnd = 0; windowEnd < str.length(); windowEnd++) {
            mp[str[windowEnd]]++;
            while(mp.size() > k) {
                mp[str[windowStart]]--;
                if(mp[str[windowStart]] == 0) {
                    mp.erase(str[windowStart]);
                }
                windowStart++;
            }
            maxLength = max(maxLength, windowEnd - windowStart + 1);
        }
        return maxLength;
    }
};



// Time Complexity #
// The time complexity of the above algorithm will be 
// O(N) where ‘N’ is the number of characters in the input string. 
// The outer for loop runs for all characters and the inner while loop 
// processes each character only once, therefore the time complexity 
// of the algorithm will be O(N+N) which is asymptotically equivalent to O(N).

// Space Complexity #
// The space complexity of the algorithm is 
// O(K), as we will be storing a maximum of ‘K+1’ characters in the HashMap.


int main()
{
    
    cout << "Lenght of longest substring of k distinct char: " 
         << longestSubStringKDistinct :: findLength("araaci", 2) << endl;
         
    cout << "Lenght of longest substring of k distinct char: " 
         << longestSubStringKDistinct :: findLength("araaci", 1) << endl;
         
    cout << "Lenght of longest substring of k distinct char: " 
         << longestSubStringKDistinct :: findLength("cbbebi", 3) << endl;
    
    return 0;
}