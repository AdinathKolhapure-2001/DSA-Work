#include <iostream>
#include <vector>
#include <limits>

using namespace std;

class minSizeSubArraySum {
    public:
    static int findMinSumArray(int S, const vector<int>& arr) {
        // int n = arr.size(), sum, p, minLength = numeric_limits<int>:: max();
        // for(int i = 0; i < n; i++) {
        //     for(int j = i; j < n; j++) {
        //         sum = 0, p = 0;
        //         for(int k = i; k <= j; k++) {
        //             sum += arr[k];
        //             if(sum >= S) {
        //                 minLength = min(minLength, j - i + 1);  // 2
        //                 p = 1;
        //             }
        //         }
        //         if(p) break;
        //     }
        // }
        // return minLength == numeric_limits<int>:: max() ? 0 : minLength;
        
        
        int windowStart = 0, windowSum = 0, minLength = numeric_limits<int>:: max();
        for(int windowEnd = 0; windowEnd < arr.size(); windowEnd++) {
            windowSum += arr[windowEnd];    // add the next element
            // shrink the window as small as possible until the 'windowSum is smaller than S'
            while(windowSum >= S) {
                minLength = min(minLength, windowEnd - windowStart + 1);
                windowSum -= arr[windowStart++];    // subtract the element going out of the window 
            }                                       // and slide the window ahead
        }
        return minLength == numeric_limits<int>:: max() ? 0 : minLength;
    }
};


// Time Complexity #
// The time complexity of the above algorithm will be O(N). 
// The outer for loop runs for all elements and the inner while loop 
// processes each element only once, therefore the time complexity of the algorithm will be 
// O(N+N) which is asymptotically equivalent to O(N).

// Space Complexity #
// The algorithm runs in constant space O(1).

int main() {

    cout << "Smallest subarray lenght: "                                
         << minSizeSubArraySum :: findMinSumArray(7, vector<int> {2, 1, 5, 2, 3, 2}) << endl;   // 2
         
    cout << "Smallest subarray lenght: " 
         << minSizeSubArraySum :: findMinSumArray(7, vector<int> {2, 1, 5, 2, 8}) << endl;      // 1

    cout << "Smallest subarray lenght: " 
         << minSizeSubArraySum :: findMinSumArray(8, vector<int> {3, 4, 1, 1, 6}) << endl;      // 3
         
    return 0;
}