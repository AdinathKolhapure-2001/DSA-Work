#include <bits/stdc++.h>

using namespace std;

bool isopening_bracket(char c){
    switch(c) {
            case '(':
                return true;
                break;
            case '[':
                return true;
                break;
            case '{':
                return true;
                break;
        }
    return false;
}


void insertAtBottom(stack<int>& s, int x) {
    if(s.empty()) {
        s.push(x);
        return;
    }
    int temp = s.top();
    s.pop();
    insertAtBottom(s, x);
    s.push(temp);
    
}



void reverseStack(stack<int>& s) {
    if(s.empty()) {
        return;
    }
    int temp = s.top();
    s.pop();
    reverseStack(s);
    insertAtBottom(s, temp);
    
}

void sortedinsert(stack<int>& s, int x) {
    if(s.empty() || s.top() <= x) {
        s.push(x);
        return;
    }
    int temp = s.top();
    s.pop();
    sortedinsert(s, x);
    s.push(temp);
}

void sortStack(stack<int>& s) {
    if(s.empty()) {
        return;
    }
    int temp = s.top();
    s.pop();
    sortStack(s);
    sortedinsert(s, temp);
    
}


int main()
{
    
    // reverse a string
    // stack<char> s;
    
    // string str = "hello";
    
    // for(char c : str) {
    //     s.push(c);
    // }
    
    // string rev_str = "";
    // while(!s.empty()) {
    //     rev_str += s.top();
    //     s.pop();
    // }
    
    // cout << "rev_str = " << rev_str;
    
    
    
    //delete middle element
    
    // stack<int> temp;
    // stack<int> s;
    // s.push(1);
    // s.push(2);
    // s.push(3);
    // s.push(4);
    // s.push(5);
    // s.push(6);

    // int count = 0;
    // int size = s.size();
    // if(size&1)
    // {
    //     while(!s.empty() && count != (size/2)) {    // c = 2    s = 1
    //     temp.push(s.top());
    //     s.pop();
    //     count++;
    //     }
    // }
    // else {
    //     while(!s.empty() && count != (size/2) - 1) {    // c = 2    s = 1
    //     temp.push(s.top());
    //     s.pop();
    //     count++;
    //     }
    // }
    
    // s.pop();
    // while(!temp.empty()) {
    //     s.push(temp.top());
    //     temp.pop();
    // }
    
    // while(!s.empty()) {
    //     cout << s.top() << " ";
    //     s.pop();
    // }
    
    
    // valid paranthesis
    // string para = "{[()[}}";
    
    // stack<char> s;
    // int flag = 1;
    // for(char c : para) {
    //     if(isopening_bracket(c)) {      //    c= )
    //         s.push(c);
    //     }
    //     else {
    //         char top;
    //         if(!s.empty())
    //             top = s.top();     // top = {
    //         else {
    //             flag = 0;
    //             break;
    //         }
    //         switch(c) {
    //             case ')':
    //                 if(top != '(')
    //                     flag = 0;
    //                 else s.pop();
    //                 break;
    //             case '}':
    //                 if(top != '{')
    //                     flag = 0;
    //                 else s.pop();
    //                 break;
    //             case ']':
    //                 if(top != '[')
    //                     flag = 0;
    //                 else s.pop();
    //                 break;
    //         }
            
    //     }
    //     if(flag == 0) break;
        
    // }
    
    // if(s.empty() && flag)
    //     cout << "valid";
    // else 
    //     cout << "invalid";
    
    
    
    
    // Insert element at the bottom of the stack
    
    // stack<int> s;
    // stack<int> temp;
    // s.push(7);
    // s.push(4);
    // s.push(1);
    // s.push(5);
    
    
    // int x = 9;
    // |    |      |  7  |
    // |    |      |  4  |
    // |    |      |  1  |
    // |    |      |  5  |
    // ------      ------
    
    
    
    // while(!s.empty()) {
    //     temp.push(s.top());
    //     s.pop();
    // }
    
    // s.push(x);
    
    // while(!temp.empty()) {
    //     s.push(temp.top());
    //     temp.pop();
    // }
    
    
    // while(!s.empty()) {
    //     cout << s.top() << " ";
    //     s.pop();
    // }
    
    // insertAtBottom(s, x);
    
    
    // while(!s.empty()) {
    //     cout << s.top() << " ";
    //     s.pop();
    // }
    
    
    
    
    // reverse stack using recursion
    
    
    
    // stack<int> s;
    // s.push(7);
    // s.push(4);
    // s.push(1);
    // s.push(5);
    
    // reverseStack(s);
    
    
    // while(!s.empty()) {
    //     cout << s.top() << " ";
    //     s.pop();
    // }
    
    
    
    // rough
    
    // vector<int> arr = {4, 7, 5, 2, 6, 1};
    
    // arr[i]  == *(arr + i) == *(i + arr)
    
    // sort(arr.begin(), arr.begin()+4);
    
    
    // for(int i: arr) {
    //     cout << i << " ";
    // }
    
    
    
    
    // sort stack
    
    
    stack<int> s;
    s.push(7);
    s.push(4);
    s.push(1);
    s.push(5);
    
    sortStack(s);
    
    while(!s.empty()) {
        cout << s.top() << " ";
        s.pop();
    }
    
    
    
    
    
    
    
    return 0;
}
