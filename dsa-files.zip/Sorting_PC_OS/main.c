#include<sys/types.h>
#include<unistd.h>
#include <stdio.h>

int main()
{
    pid_t child_pid;
    int n;
    
    printf("\nHow many numbers you wnat: ");
    scanf("%d",&n);
    int arr[n];
    
    
    for(int i = 0; i<n; i++)
    {
        scanf("%d",&arr[i]);
    }
    
    
    child_pid = fork();
    

    if(child_pid == 0)
    {   
        printf("\nThis is child proccess with id: %d",getpid());
        printf("\nMy parent proccess id is: %d",getppid());
        printf("\nThis is child proccess:");
        printf("\nData sorted in descending order:\n");
        
        int flag;
        for(int i = 0; i<n-1; i++)
        {   
            flag = 0;
            for(int j = 0; j<n-i-1;j++)
            {
                if(arr[j]<arr[j+1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    flag = 1;
            }
        }
        
        if(flag == 0)
            break;
    }
    
        for(int i = 0;i<n; i++)
        {
            printf("%d  ",arr[i]);
        }
        
        system("ps");
    }
    
    else
    {
        sleep(1);
        printf("\nThis is parent proccess with id: %d",getpid());
        printf("\nMy child proccess id is: %d",child_pid);
        printf("\nMy parent proccess id is: %d",getppid());
        printf("\nThis is parent proccess:");
        printf("\nData sorted in ascending order:\n");
        
        int flag;
        for(int i = 0; i<n-1; i++)
        {   
            flag = 0;
            for(int j = 0; j<n-i-1;j++)
            {
                if(arr[j]>arr[j+1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    flag = 1;
            }
        }
        if(flag == 0)
            break;
    }
    
        for(int i = 0;i<n; i++)
        {
            printf("%d  ",arr[i]);
        }
        
        system("ps");
    }
    
    
    
    return 0;
}





