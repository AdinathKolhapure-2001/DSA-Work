#include<sys/types.h>
#include<unistd.h>
#include <stdio.h>

int atoi(char*);

int main(int argc, char *argv[])
{
    pid_t child_pid;
    
    int n = argc - 1;
    
    int arr[argc - 1];
    
    for(int i = 1; i<argc; i++)
    {
        // arr[i-1] = *argv[i] - '0';
        arr[i-1] = atoi(argv[i]);
        // printf("\n%d",arr[i-1]);
    }
    
    
    child_pid = fork();
    

    if(child_pid == 0)
    {   
        printf("\n\nThis is child proccess with id: %d",getpid());
        printf("\nMy parent proccess id is: %d",getppid());
        printf("\nThis is child proccess:");
        printf("\nData sorted in descending order:\n");
        
        int flag;
        for(int i = 0; i<n-1; i++)
        {   
            flag = 0;
            for(int j = 0; j<n-i-1;j++)
            {
                if(arr[j]<arr[j+1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    flag = 1;
            }
        }
        
        if(flag == 0)
            break;
    }
    
        for(int i = 0;i<n; i++)
        {
            printf("%d  ",arr[i]);
        }
        
        // system("ps");
    }
    
    else
    {
        sleep(1);
        printf("\n\nThis is parent proccess with id: %d",getpid());
        printf("\nMy child proccess id is: %d",child_pid);
        printf("\nMy parent proccess id is: %d",getppid());
        printf("\nThis is parent proccess:");
        printf("\nData sorted in ascending order:\n");
        
        int flag;
        for(int i = 0; i<n-1; i++)
        {   
            flag = 0;
            for(int j = 0; j<n-i-1;j++)
            {
                if(arr[j]>arr[j+1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    flag = 1;
            }
        }
        if(flag == 0)
            break;
    }
    
        for(int i = 0;i<n; i++)
        {
            printf("%d  ",arr[i]);
        }
        
        // system("ps");
    }
    
    
    return 0;
}






