#include <iostream>

using namespace std;


struct linkedList {
    private:
        int data;
        linkedList* next;
    public:
        linkedList* create(int);
        linkedList* addLast(linkedList*, int);
        linkedList* reorderLL(linkedList*);
        linkedList* getMiddle(linkedList*);
        linkedList* reverse(linkedList*);
        void showList(linkedList*);
};

linkedList* linkedList :: create(int data) {
    linkedList* newNode = new linkedList;
    newNode -> data = data;
    newNode -> next = NULL;
    return newNode;
}

linkedList* linkedList :: addLast(linkedList* head, int data) {
    linkedList* newNode = create(data);
    if(head == NULL) {
        head = newNode;
    }
    else {
        linkedList* temp = head;
        while(temp -> next) {
            temp = temp -> next;
        }
        temp -> next = newNode;
    }

    return head;
}

void linkedList :: showList(linkedList* head) {
    if(head == NULL) {
        cout << "\nLinked list is empty" << endl;
        return;
    }
    while(head) {
        cout << head -> data << " --> ";
        head = head -> next;
    }
    cout << "NULL" << endl;
}

linkedList* linkedList :: getMiddle(linkedList* head) {
    linkedList* slow = head, *fast = head;
    while(fast && fast -> next) {
        slow = slow -> next;
        fast = fast -> next -> next;
    }
    return slow;
}


linkedList* linkedList :: reverse(linkedList* head) {
    linkedList* prev = NULL, *curr = head, *Next = NULL;
    while(curr) {
        Next = curr -> next;
        curr -> next = prev;
        prev = curr;
        curr = Next;
    }
    return prev;
}

linkedList* linkedList :: reorderLL(linkedList* head) {
    linkedList* middle = getMiddle(head);
    linkedList* secondHalfHead = reverse(middle);
    linkedList* Next1 = NULL, *Next2 = NULL, *temp = head;
        
    while(secondHalfHead -> next != NULL) {                       //               tn1    shn2
                                                                  // 10 --> 20 --> 30 --> 40 <-- 50 <-- 60
        Next1 = temp -> next;                                    //                      | --> NULL
        temp -> next = secondHalfHead;                          // 10 --> 60 --> 20 --> 50 --> 30 --> 40
        Next2 = secondHalfHead -> next;
        secondHalfHead -> next = Next1;
        temp = Next1;
        secondHalfHead = Next2;
    }
    return head;
}

int main() {

    linkedList* head = NULL;
    head = head -> addLast(head, 10);
    head = head -> addLast(head, 20);
    head = head -> addLast(head, 30);
    head = head -> addLast(head, 40);
    head = head -> addLast(head, 50);
    head = head -> addLast(head, 60);
    head = head -> addLast(head, 70);
    

    head -> showList(head);
    
    head = head -> reorderLL(head);
    
    head -> showList(head);

    return 0;
}