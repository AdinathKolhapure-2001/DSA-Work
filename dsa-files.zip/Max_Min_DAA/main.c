
#include <stdio.h>


int max(int arr[], int n)
{
    int Max = arr[0];
    
    for(int i = 1; i<n; i++)
    {
        if(arr[i]>Max)
        {
            Max = arr[i];
        }
        
    }
    
    return Max;
}


int min(int arr[], int n)
{
    int Min = arr[0];
    
    for(int i = 1; i<n; i++)
    {
        if(arr[i]<Min)
        {
            Min = arr[i];
        }
        
    }
    
    return Min;
}



int main()
{
    
    int n,i;
    
    printf("\nEnter the number of elements: ");
    scanf("%d",&n);
    int arr[n];
    
    for(i = 0; i<n; i++)
    {
        printf("\nEnter the element: ");
        scanf("%d",&arr[i]);
    }
    
    int Max = max(arr, n);
    int Min = min(arr, n);
    
    printf("\nMaximum element in given array is: %d",Max);
    printf("\nMinimum element in given array is: %d",Min);
    
    

    return 0;
}
