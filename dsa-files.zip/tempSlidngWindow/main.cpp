#include <iostream>

using namespace std;

int main()
{
    
    // Kadan's algo : max sum subarray 
    
    // {1, 2, 0, -3, 4, 0, -1, 2, -4}    --> nC2 + n = n * (n + 1) / 2 = 45
    
    // maxSum = 5;
    // {1, 2, 2, 4, 5, 6}
    
    // int k = 3;
    // int sum = 0;
    // int maxSum = 0;
    // int arr[] = {2, -1, -9, 4, 0, 1, -5, 2};  // 3  -1  1 
    
    // int size = sizeof(arr) / sizeof(arr[0]);
    
    // int sum;
    // for 0 -> size - 2;  // i = 2
    // sum = 0;
    // for i -> i + j;
    //     sum += arr[j];
    // maxSum = max(maxSum, sum);
    
    
    // for(int i = 0; i < size - 2; i++)       // O(n.k) --> O(n^2)
    // {
    //     sum = 0;
    //     for(int j = i; j < i + k; j++)
    //     {
    //         sum += arr[j];
    //     }
    //     maxSum = max(maxSum, sum);
    // }
    
    // cout << "Max sum subarray of length " << k << " = " << maxSum << endl;
    
    // for 0 --> k;
    //     sum += arr[i];
    // maxSum = max(maxSum, sum);  
    // for 1 --> size - 2;
    //     sum = sum - arr[i - 1] + arr[i + 2];
    
    // maxSum = max(maxSum, sum);
    
    // cout << "Max sum subarray of length " << k << " = " << maxSum << endl;
    
    
    
    // Sliding window technique 
    
    
    // for(int i = 0; i < k; i++)           // O(n) 
    // {
    //     sum += arr[i];
    // }
    
    // maxSum = max(maxSum, sum);
    
    // for(int i = k; i < size; i++)
    // {
    //     sum = sum - arr[i - k] + arr[i];
    //     maxSum = max(maxSum, sum);
    // }
    
    
    
    // cout << "Max sum subarray of length " << k << " = " << maxSum << endl;
    
    return 0;
}

