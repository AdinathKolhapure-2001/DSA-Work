import java.util.Scanner;

class complex
{
    private int real;
    private int img;
    
    
    public complex()
    {
        // default constructor
    }
    
    public complex(complex c)
    {
        real = c.real;
        img = c.img;
    }
    
    public complex(int real, int img)
    {
        this.real = real;
        this.img = img;
    }
    
    public void add(complex x, complex y)
    {
        real = x.real + y.real;
        img = x.img + y.img;
    }
    
    public void sub(complex x, complex y)
    {
        real = x.real - y.real;
        img = x.img - y.img;
    }
    
    public void mult(complex x, complex y)
    {
        real = (x.real*y.real)-(x.img*y.img);
        img = (x.real*y.img)+(y.real*x.img);
        
    }
    
    
    public void div(complex x, complex y)
    {
        int realNum = (x.real*y.real+x.img*y.img);
        int realDen = (y.real*y.real+y.img*y.img);
        int imgNum = (x.img*y.real-x.real*y.img);
        int imgDen = (y.real*y.real+y.img*y.img);
        
        System.out.println("\n( "+realNum+"/"+realDen+" )+"+"( "+imgNum+"/"+imgDen+" )i");
        
    }
    
    public void display()
    {
        System.out.println("\n( "+real+" )+"+"( "+img+" )i");
    }
}

public class Main
{   
    public static Scanner scan = new Scanner(System.in);  
    
	public static void main(String[] args) {
		
		int real;
		int img;
		
		System.out.println("Enter the first Complex number:");
		real = scan.nextInt();
		img = scan.nextInt();
		
		complex c1 = new complex(real,img);
		
		System.out.println("Enter the second Complex number:");
		real = scan.nextInt();
		img = scan.nextInt();
		
		complex c2 = new complex(real,img);
		
		complex c3 = new complex();
		
		System.out.println("\nAddition of complex number is: ");
		
		c3.add(c1,c2);
		
		c3.display();
		
		System.out.println("\nSubtraction of complex number is: ");
		
		c3.sub(c1,c2);
		
		c3.display();
		
		System.out.println("\nMultipication of complex numbers:\n");
        
        c3.mult(c1,c2);
        
        c3.display();
        
        
		System.out.println("\nDivision of complex numbers:\n");
        
        c3.div(c1,c2);
        
		
	}
}
